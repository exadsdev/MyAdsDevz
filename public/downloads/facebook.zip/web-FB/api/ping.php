<?php
// UTF-8 (NO BOM)
require __DIR__ . '/../admin/helpers.php';
header('Content-Type: application/json; charset=UTF-8');
echo json_encode([
  'ok' => true,
  'now' => gmdate('c'),
  'client_ip' => function_exists('client_ip') ? client_ip() : ($_SERVER['REMOTE_ADDR'] ?? 'n/a'),
]);
