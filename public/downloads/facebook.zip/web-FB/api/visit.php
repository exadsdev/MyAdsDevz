<?php
// UTF-8 (NO BOM) — บันทึก "เข้าหน้าเว็บ" กันซ้ำ IP 5 นาที + referrer + timestamp
require __DIR__ . '/../admin/helpers.php';

try {
  $data = read_db();

  $ip     = client_ip();
  $ua     = sanitize_text($_SERVER['HTTP_USER_AGENT'] ?? '');
  $ref    = sanitize_text($_SERVER['HTTP_REFERER'] ?? '');
  $nowIso = gmdate('c');
  $nowTs  = time();
  $window = 300; // 5 นาที

  $isDuplicate = false;
  if (!empty($data['metrics']['visits'])) {
    for ($i = count($data['metrics']['visits']) - 1; $i >= 0; $i--) {
      $row = $data['metrics']['visits'][$i];
      if (($row['ip'] ?? '') === $ip) {
        $lastTs = isset($row['ts']) ? (int)$row['ts'] : strtotime($row['at'] ?? 'now');
        if ($lastTs && ($nowTs - $lastTs) < $window) { $isDuplicate = true; }
        break;
      }
    }
  }

  if (!$isDuplicate) {
    $data['metrics']['visits'][] = [
      'ip'  => $ip,
      'ua'  => $ua,
      'ref' => $ref,
      'at'  => $nowIso,
      'ts'  => $nowTs,
    ];
    $data['metrics']['totals']['visits'] = (int)($data['metrics']['totals']['visits'] ?? 0) + 1;

    if (count($data['metrics']['visits']) > 5000) {
      $data['metrics']['visits'] = array_slice($data['metrics']['visits'], -5000);
    }
    write_db($data);
  }

  log_line("VISIT ok dup=" . ($isDuplicate?'1':'0') . " ip=$ip ref=" . ($ref?:'-'));
  header('Content-Type: application/json; charset=UTF-8');
  echo json_encode(['ok'=>true,'duplicate'=>$isDuplicate]);
} catch (Throwable $e) {
  log_line('VISIT error: '.$e->getMessage());
  http_response_code(500);
  header('Content-Type: application/json; charset=UTF-8');
  echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
}
