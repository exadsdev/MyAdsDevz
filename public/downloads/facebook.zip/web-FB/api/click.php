<?php
// UTF-8 (NO BOM) — บันทึก "คลิก" กันซ้ำ IP+target 10 วินาที
require __DIR__ . '/../admin/helpers.php';

try {
  // อ่าน target: 'button' หรือ 'image'
  $target = $_POST['target'] ?? $_GET['target'] ?? null;
  if ($target === null) {
    $raw = file_get_contents('php://input') ?: '';
    if ($raw !== '') {
      parse_str($raw, $arr);
      if (isset($arr['target'])) {
        $target = sanitize_text($arr['target'], 32);
      } else {
        $j = json_decode($raw, true);
        if (isset($j['target'])) $target = sanitize_text($j['target'], 32);
      }
    }
  }
  if (!$target) $target = 'button';

  $data   = read_db();
  $ip     = client_ip();
  $nowIso = gmdate('c');
  $nowTs  = time();

  // ✅ กันซ้ำ “เฉพาะคลิก” เหลือ 10 วินาที และผูกกับ target ด้วย
  $window = 10; // เปลี่ยนตามต้องการ (วินาที)

  $isDuplicate = false;
  if (!empty($data['metrics']['clicks'])) {
    for ($i = count($data['metrics']['clicks']) - 1; $i >= 0; $i--) {
      $row = $data['metrics']['clicks'][$i];
      if (($row['ip'] ?? '') === $ip && ($row['target'] ?? '') === $target) {
        $lastTs = isset($row['ts']) ? (int)$row['ts'] : strtotime($row['at'] ?? 'now');
        if ($lastTs && ($nowTs - $lastTs) < $window) { $isDuplicate = true; }
        break;
      }
    }
  }

  if (!$isDuplicate) {
    $data['metrics']['clicks'][] = [
      'ip'     => $ip,
      'target' => $target,
      'at'     => $nowIso,
      'ts'     => $nowTs,
    ];
    $data['metrics']['totals']['clicks'] = (int)($data['metrics']['totals']['clicks'] ?? 0) + 1;

    // limit ความยาว log
    if (count($data['metrics']['clicks']) > 5000) {
      $data['metrics']['clicks'] = array_slice($data['metrics']['clicks'], -5000);
    }
    write_db($data);
  }

  log_line("CLICK ok dup=" . ($isDuplicate?'1':'0') . " ip=$ip target=$target");
  header('Content-Type: application/json; charset=UTF-8');
  echo json_encode(['ok'=>true,'duplicate'=>$isDuplicate]);
} catch (Throwable $e) {
  log_line('CLICK error: '.$e->getMessage());
  http_response_code(500);
  header('Content-Type: application/json; charset=UTF-8');
  echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
}
