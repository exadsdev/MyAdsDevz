<?php
// UTF-8 (NO BOM)
require __DIR__ . '/../admin/helpers.php';

try {
  $db = read_db();
  $db['metrics']['visits'][] = [
    'ip'  => client_ip(),
    'ua'  => 'manual-visit',
    'ref' => '/api/manual_visit.php',
    'at'  => gmdate('c'),
    'ts'  => time(),
  ];
  $db['metrics']['totals']['visits'] = (int)($db['metrics']['totals']['visits'] ?? 0) + 1;
  write_db($db);
  log_line('MANUAL VISIT +1');
  header('Content-Type: text/plain; charset=UTF-8');
  echo "OK: visit +1";
} catch (Throwable $e) {
  http_response_code(500);
  echo "ERR: ".$e->getMessage();
}
