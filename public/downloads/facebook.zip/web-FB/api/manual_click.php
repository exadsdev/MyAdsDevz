<?php
// UTF-8 (NO BOM)
require __DIR__ . '/../admin/helpers.php';

try {
  $target = isset($_GET['target']) ? sanitize_text($_GET['target'], 32) : 'button';
  $db = read_db();
  $db['metrics']['clicks'][] = [
    'ip'     => client_ip(),
    'target' => $target,
    'at'     => gmdate('c'),
    'ts'     => time(),
  ];
  $db['metrics']['totals']['clicks'] = (int)($db['metrics']['totals']['clicks'] ?? 0) + 1;
  write_db($db);
  log_line('MANUAL CLICK +1 target='.$target);
  header('Content-Type: text/plain; charset=UTF-8');
  echo "OK: click +1 (target={$target})";
} catch (Throwable $e) {
  http_response_code(500);
  echo "ERR: ".$e->getMessage();
}
