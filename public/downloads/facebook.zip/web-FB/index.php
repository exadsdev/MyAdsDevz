<?php
// UTF-8 (NO BOM)
require __DIR__ . '/admin/helpers.php';

$data = read_db();
$activeIndex = ($data['active_index'] ?? '1') === '2' ? '2' : '1';

$target = $activeIndex === '2' ? __DIR__ . '/index2.php' : __DIR__ . '/index1.php';

// ถ้ามีไฟล์ที่เลือกอยู่ ให้ include ทันที
if (is_file($target)) {
  require $target;
  exit;
}

// ถ้าไฟล์ที่เลือกไม่มี ให้ fallback ไปอีกตัว
$fallback = $activeIndex === '2' ? __DIR__ . '/index1.php' : __DIR__ . '/index2.php';
if (is_file($fallback)) {
  require $fallback;
  exit;
}

// สุดท้าย: แจ้งเตือนหากไม่พบทั้งสองไฟล์
http_response_code(500);
?><!doctype html>
<html lang="th">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;padding:40px;color:#333}
    .box{max-width:720px;margin:auto;border:1px solid #eee;border-radius:12px;padding:24px;background:#fff}
    h1{margin-top:0}
    code{background:#f6f8fa;padding:.15rem .35rem;border-radius:6px}
  </style>
</head>
<body>
  <div class="box">
    <h1>ไม่พบไฟล์หน้าแรก</h1>
    <p>กรุณาสร้างไฟล์ <code>index1.php</code> หรือ <code>index2.php</code> ไว้ที่โฟลเดอร์เดียวกับไฟล์นี้ แล้วกลับมารีเฟรชอีกครั้ง</p>
  </div>
</body>
</html>
