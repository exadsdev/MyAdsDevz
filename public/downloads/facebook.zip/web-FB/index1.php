<?php
// UTF-8 (NO BOM)
require_once __DIR__ . '/admin/helpers.php';  // ← เปลี่ยนเป็น require_once
$c = cfg();

$UPLOAD_URL = $c['upload_url'] ?? '/uploads';
$API_VISIT  = $c['api_visit']  ?? '/api/visit.php';
$API_CLICK  = $c['api_click']  ?? '/api/click.php';

$data    = read_db();
$items   = is_array($data['items'] ?? null) ? $data['items'] : [];
$buttons = is_array($data['buttons'] ?? null) ? $data['buttons'] : [];
$bg      = $data['background'] ?? null;
$global  = (string)($data['global_link'] ?? '');
$fb_px   = trim((string)($data['facebook_pixel_id'] ?? ''));

$rows = array_values(array_filter($items, fn($x)=>($x['visible'] ?? true) === true));
usort($rows, fn($a,$b)=>strcmp((string)($b['created_at'] ?? ''),(string)($a['created_at'] ?? '')));
?>
<!doctype html>
<html lang="th">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Primary Meta Tags -->
<title>PG สล็อตเว็บตรง PG Slot สล็อตเว็บตรง แตกง่าย อันดับ 1 ของไทย</title>
<meta name="title" content="PG สล็อตเว็บตรง PG Slot สล็อตเว็บตรง แตกง่าย อันดับ 1 ของไทย" />
<meta name="description" content="เมื่อพูดถึงเกมสล็อตออนไลน์ที่คนไทยนิยมเล่นมากที่สุดในยุคนี้ หนึ่งในชื่อที่ถูกกล่าวถึงอย่างต่อเนื่องคือ PG Slot (พีจีสล็อต) ค่ายเกมจากต่างประเทศที่สร้างชื่อเสียงระดับโลก" />

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website" />
<meta property="og:url" content="https://myadsdevapp.com" />
<meta property="og:title" content="PG สล็อตเว็บตรง PG Slot สล็อตเว็บตรง แตกง่าย อันดับ 1 ของไทย" />
<meta property="og:description" content="เมื่อพูดถึงเกมสล็อตออนไลน์ที่คนไทยนิยมเล่นมากที่สุดในยุคนี้ หนึ่งในชื่อที่ถูกกล่าวถึงอย่างต่อเนื่องคือ PG Slot (พีจีสล็อต) ค่ายเกมจากต่างประเทศที่สร้างชื่อเสียงระดับโลก" />
<meta property="og:image" content="https://myadsdevapp.com/pg.webp" />

<!-- X (Twitter) -->
<meta property="twitter:card" content="summary_large_image" />
<meta property="twitter:url" content="https://myadsdevapp.com" />
<meta property="twitter:title" content="PG สล็อตเว็บตรง PG Slot สล็อตเว็บตรง แตกง่าย อันดับ 1 ของไทย" />
<meta property="twitter:description" content="เมื่อพูดถึงเกมสล็อตออนไลน์ที่คนไทยนิยมเล่นมากที่สุดในยุคนี้ หนึ่งในชื่อที่ถูกกล่าวถึงอย่างต่อเนื่องคือ PG Slot (พีจีสล็อต) ค่ายเกมจากต่างประเทศที่สร้างชื่อเสียงระดับโลก" />
<meta property="twitter:image" content="https://myadsdevapp.com/pg.webp" />

<link rel="shortcut icon" href="https://myadsdevapp.com/logo.png" type="image/x-icon">

<!-- Meta Tags Generated with https://metatags.io -->



  <?php if ($fb_px !== ''): ?>
  <!-- Facebook Pixel -->
  <script>
    !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
    n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
    n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
    t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}
    (window, document,'script','https://connect.facebook.net/en_US/fbevents.js');
    fbq('init','<?php echo htmlspecialchars($fb_px, ENT_QUOTES) ?>');
    fbq('track','PageView');
  </script>
  <noscript>
    <img height="1" width="1" style="display:none"
         src="https://www.facebook.com/tr?id=<?php echo htmlspecialchars($fb_px) ?>&ev=PageView&noscript=1"/>
  </noscript>
  <?php endif; ?>
  <style>
    :root { --gap: 0; }
    *{box-sizing:border-box}
    html,body{height:100%}
    body{margin:0;font:16px/1.5 system-ui,-apple-system,Segoe UI,Roboto}
    body.has-bg{
      background:#000 url("<?php echo htmlspecialchars($UPLOAD_URL) ?>/<?php echo isset($bg['filename']) ? htmlspecialchars($bg['filename']) : '' ?>") center/cover no-repeat fixed;
    }
    .main{min-height:100dvh; display:flex; flex-direction:column; align-items:center}
    .gallery{width:100%; max-width:600px; margin:0 auto}
    .image-wrap{margin:0; padding:0}
    .gallery-img{display:block; width:100%; height:auto; max-width:600px; margin:0 auto}
    @media (min-width:992px){ .gallery{max-width:480px} }
    .image-wrap + .image-wrap{margin-top:0}
    a.imglink{display:block; line-height:0}
    .btnbar{position:fixed; left:0; right:0; bottom:10px; display:flex; gap:8px; justify-content:center; z-index:10; padding:0 12px}
    .btn-pill{padding:12px 18px; border-radius:999px; text-decoration:none; font-weight:600; display:inline-block}
    .btn-web{background:#1a73e8; color:#fff}
    .btn-line{background:#06c755; color:#fff}
  </style>
</head>
<body class="<?php echo ($bg && !empty($bg['filename'])) ? 'has-bg' : '' ?>">
  <main class="main">
    <div id="btnbar" class="btnbar">
      <?php
        $two = array_slice($buttons, 0, 2);
        foreach ($two as $b) {
          $label  = htmlspecialchars((string)($b['label'] ?? 'Link'));
          $url    = htmlspecialchars((string)($b['url'] ?? '#'));
          $type   = (string)($b['type'] ?? 'website');
          $cls    = $type === 'line' ? 'btn-line' : 'btn-web';
          echo '<a class="btn-pill '.$cls.'" href="'.$url.'" target="_blank" rel="noopener" data-track="button">'.$label.'</a>';
        }
      ?>
    </div>

    <div id="gallery" class="gallery">
      <?php if (count($rows)):
        foreach ($rows as $it):
          $src = $UPLOAD_URL . '/' . rawurlencode((string)$it['filename']);
          $img = '<img src="'.htmlspecialchars($src).'" class="gallery-img" alt="" data-track="image">';
      ?>
        <div class="image-wrap">
          <?php if ($global !== ''): ?>
            <a class="imglink" href="<?php echo htmlspecialchars($global); ?>" target="_blank" rel="noopener" data-track="image-link">
              <?php echo $img; ?>
            </a>
          <?php else: echo $img; endif; ?>
        </div>
      <?php endforeach; endif; ?>
    </div>
  </main>

  <!-- visit fallback -->
  <img src="<?php echo htmlspecialchars($API_VISIT) ?>?fallback=1&ts=<?php echo time(); ?>" alt="" width="1" height="1" style="position:absolute;left:-9999px;top:-9999px;opacity:0">

  <script>
    const API_VISIT = "<?php echo htmlspecialchars($API_VISIT) ?>";
    const API_CLICK = "<?php echo htmlspecialchars($API_CLICK) ?>";
    fetch(API_VISIT, {method:'POST', keepalive:true}).catch(()=>{});
    function sendClick(target){
      const bodyStr = new URLSearchParams({target}).toString();
      let sent = false;
      try {
        const blob = new Blob([bodyStr], { type: 'application/x-www-form-urlencoded;charset=UTF-8' });
        sent = navigator.sendBeacon(API_CLICK, blob);
      } catch(e) {}
      if (!sent) {
        fetch(API_CLICK, {
          method:'POST',
          headers:{'Content-Type':'application/x-www-form-urlencoded'},
          body: bodyStr,
          keepalive:true
        }).catch(()=>{
          const i = new Image();
          i.src = API_CLICK + '?target=' + encodeURIComponent(target) + '&ts=' + Date.now();
        });
      }
    }
    document.querySelectorAll('a[data-track="button"]').forEach(a=>{
      a.addEventListener('click', ()=>sendClick('button'), {passive:true});
    });
    document.querySelectorAll('a[data-track="image-link"]').forEach(a=>{
      a.addEventListener('click', ()=>sendClick('image'), {passive:true});
    });
    document.querySelectorAll('img[data-track="image"]').forEach(im=>{
      im.addEventListener('click', ()=>sendClick('image'), {passive:true});
    });
  </script>
</body>
</html>
