<!DOCTYPE html>
<html lang="en-US">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="google-site-verification" content="iPTIPsnxngMFqEuA3bwXr43JSM7GO6cd1X6Ws5oHoJo" />

    <title>
        Gift Hampers, Baskets &amp; Flowers | Gift Delivery Across Thailand </title>
    <link rel="pingback" href="https://basketeer.com/xmlrpc.php" />
    <link rel="shortcut icon" href="https://basketeer.com/wp-content/themes/baskettheme/images/favicon.ico" />
    <link href="https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400;1,500&family=Montserrat:wght@100;200;300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css">
    <link rel="stylesheet" href="https://basketeer.com/wp-content/themes/baskettheme/css/external/select.min.css">
    <link rel="stylesheet" href="https://basketeer.com/wp-content/themes/baskettheme/css/external/woocommerce-general.css">
    <link rel="stylesheet" href="https://basketeer.com/wp-content/themes/baskettheme/css/external/ajax-search-for-woocommerce-min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.13/css/intlTelInput.css">
    <!-- <link rel="stylesheet" href="https://basketeer.com/wp-content/themes/baskettheme/css/includes/splide.min.css"> -->

    <!-- Google Tag Manager -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-MTK7BWQW');
    </script>
    <!-- End Google Tag Manager -->

    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-16480016740">
    </script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'AW-16480016740');
    </script>


    <meta property="fb:app_id" content="1300601905115255" />

    <!-- Meta Pixel Code (Existing) -->
    <script>
        ! function(f, b, e, v, n, t, s) {
            if (f.fbq) return;
            n = f.fbq = function() {
                n.callMethod ?
                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            };
            if (!f._fbq) f._fbq = n;
            n.push = n;
            n.loaded = !0;
            n.version = '2.0';
            n.queue = [];
            t = b.createElement(e);
            t.async = !0;
            t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s)
        }(window, document, 'script',
            'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '1224463775189932');
        fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=1224463775189932&ev=PageView&noscript=1"
/></noscript>
    <!-- End Meta Pixel Code -->

    <!-- Meta Pixel Code (New) -->
    <script>
        fbq('init', '645585424927345');
        fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=645585424927345&ev=PageView&noscript=1"
/></noscript>
    <!-- End Meta Pixel Code -->

    <script>
        document.documentElement.className = document.documentElement.className + ' yes-js js_active js'
    </script>
    <meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1' />
    <style>
        img:is([sizes="auto" i], [sizes^="auto," i]) {
            contain-intrinsic-size: 3000px 1500px
        }
    </style>
    <script>
        var adminBaseUrl = "https:\/\/basketeer.com\/wp-admin\/";
        // If the iframe loaded a frontend page (not wp-admin), open it in the main window
        var keywordsAllowed = ["", "elementor", "microthemer", "trp-edit-translation", "brizy-edit-iframe", "pagebuilder-edit-iframe", "oxygen", "dp_action=dfg_popup_fetch"];
        var keywordFound = false;
        try {
            if (window.parent.location.href.indexOf(adminBaseUrl) < 0 && window.parent.location.href !== window.location.href) {

                keywordsAllowed.forEach(function(keyword) {
                    if (keyword && (window.location.href.indexOf(keyword) > -1 || window.parent.location.href.indexOf(keyword) > -1)) {
                        keywordFound = true;
                    }
                });
                // Redirect if it is an url
                if (!keywordFound && window.location.href.indexOf('http') > -1) {
                    window.parent.location.href = window.location.href;
                }
            }
        } finally {

        }
    </script>
    <link rel="alternate" hreflang="en" href="https://basketeer.com/" />
    <link rel="alternate" hreflang="th" href="https://basketeer.com/th/" />

    <!-- Google Tag Manager for WordPress by gtm4wp.com -->
    <script data-cfasync="false" data-pagespeed-no-defer>
        var gtm4wp_datalayer_name = "dataLayer";
        var dataLayer = dataLayer || [];
        const gtm4wp_use_sku_instead = false;
        const gtm4wp_currency = 'THB';
        const gtm4wp_product_per_impression = 10;
        const gtm4wp_clear_ecommerce = false;
        const gtm4wp_datalayer_max_timeout = 2000;
    </script>
    <!-- End Google Tag Manager for WordPress by gtm4wp.com -->
    <!-- This site is optimized with the Yoast SEO Premium plugin v24.3 (Yoast SEO v26.1.1) - https://yoast.com/wordpress/plugins/seo/ -->
    <meta name="description" content="Hampers, elegantly presented gift baskets, and flowers for all occasions, delivery across Thailand. Create your own special gifts now." />
    <link rel="canonical" href="https://basketeer.com/" />
    <meta property="og:locale" content="en_US" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="Home" />
    <meta property="og:description" content="Hampers, elegantly presented gift baskets, and flowers for all occasions, delivery across Thailand. Create your own special gifts now." />
    <meta property="og:url" content="https://basketeer.com/" />
    <meta property="og:site_name" content="Basketeer - The Art Of Giving" />
    <meta property="article:publisher" content="https://www.facebook.com/basketeer.thailand/" />
    <meta property="article:modified_time" content="2025-10-21T07:37:10+00:00" />
    <meta property="og:image" content="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/21102725/GIFT-DESIGN-SERVICE_2560x856_Pixel-1.jpg" />
    <meta property="og:image:width" content="1920" />
    <meta property="og:image:height" content="642" />
    <meta property="og:image:type" content="image/jpeg" />
    <meta name="twitter:card" content="summary_large_image" />
    <script type="application/ld+json" class="yoast-schema-graph">
        {
            "@context": "https://schema.org",
            "@graph": [{
                "@type": "WebPage",
                "@id": "https://basketeer.com/",
                "url": "https://basketeer.com/",
                "name": "Gift Hampers, Baskets & Flowers | Gift Delivery Across Thailand",
                "isPartOf": {
                    "@id": "https://basketeer.com/#website"
                },
                "about": {
                    "@id": "https://basketeer.com/#organization"
                },
                "primaryImageOfPage": {
                    "@id": "https://basketeer.com/#primaryimage"
                },
                "image": {
                    "@id": "https://basketeer.com/#primaryimage"
                },
                "thumbnailUrl": "https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/21102725/GIFT-DESIGN-SERVICE_2560x856_Pixel-1.jpg",
                "datePublished": "2019-02-12T02:47:14+00:00",
                "dateModified": "2025-10-21T07:37:10+00:00",
                "description": "Hampers, elegantly presented gift baskets, and flowers for all occasions, delivery across Thailand. Create your own special gifts now.",
                "breadcrumb": {
                    "@id": "https://basketeer.com/#breadcrumb"
                },
                "inLanguage": "en-US",
                "potentialAction": [{
                    "@type": "ReadAction",
                    "target": ["https://basketeer.com/"]
                }]
            }, {
                "@type": "ImageObject",
                "inLanguage": "en-US",
                "@id": "https://basketeer.com/#primaryimage",
                "url": "https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/21102725/GIFT-DESIGN-SERVICE_2560x856_Pixel-1.jpg",
                "contentUrl": "https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/21102725/GIFT-DESIGN-SERVICE_2560x856_Pixel-1.jpg",
                "width": 1920,
                "height": 642,
                "caption": "A woman in an apron arranges a bouquet of yellow and white flowers on a table with various colourful floral arrangements. The text reads \"Gift Design Service\" on a beige background."
            }, {
                "@type": "BreadcrumbList",
                "@id": "https://basketeer.com/#breadcrumb",
                "itemListElement": [{
                    "@type": "ListItem",
                    "position": 1,
                    "name": "Home"
                }]
            }, {
                "@type": "WebSite",
                "@id": "https://basketeer.com/#website",
                "url": "https://basketeer.com/",
                "name": "Basketeer - The Art Of Giving",
                "description": "The Art Of Giving",
                "publisher": {
                    "@id": "https://basketeer.com/#organization"
                },
                "potentialAction": [{
                    "@type": "SearchAction",
                    "target": {
                        "@type": "EntryPoint",
                        "urlTemplate": "https://basketeer.com/?s={search_term_string}"
                    },
                    "query-input": {
                        "@type": "PropertyValueSpecification",
                        "valueRequired": true,
                        "valueName": "search_term_string"
                    }
                }],
                "inLanguage": "en-US"
            }, {
                "@type": "Organization",
                "@id": "https://basketeer.com/#organization",
                "name": "Basketeer (Thailand) Co., Ltd.",
                "url": "https://basketeer.com/",
                "logo": {
                    "@type": "ImageObject",
                    "inLanguage": "en-US",
                    "@id": "https://basketeer.com/#/schema/logo/image/",
                    "url": "https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/07/30110120/basketeer-logo-600.png",
                    "contentUrl": "https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/07/30110120/basketeer-logo-600.png",
                    "width": 622,
                    "height": 135,
                    "caption": "Basketeer (Thailand) Co., Ltd."
                },
                "image": {
                    "@id": "https://basketeer.com/#/schema/logo/image/"
                },
                "sameAs": ["https://www.facebook.com/basketeer.thailand/", "https://www.instagram.com/basketeer_thailand/"]
            }]
        }
    </script>
    <meta name="google-site-verification" content="GvRJ0pw90zO7TuF_7Tmvbt2aM4_NBXVpPtOFjOp8BaE" />
    <meta name="p:domain_verify" content="a1781ff9d6dc192df29ed389b1a48d62" />
    <!-- / Yoast SEO Premium plugin. -->


    <link rel='dns-prefetch' href='//cdn.jsdelivr.net' />
    <link rel='dns-prefetch' href='//use.fontawesome.com' />
    <style id='classic-theme-styles-inline-css' type='text/css'>
        /*! This file is auto-generated */

        .wp-block-button__link {
            color: #fff;
            background-color: #32373c;
            border-radius: 9999px;
            box-shadow: none;
            text-decoration: none;
            padding: calc(.667em + 2px) calc(1.333em + 2px);
            font-size: 1.125em
        }

        .wp-block-file__button {
            background: #32373c;
            color: #fff;
            text-decoration: none
        }
    </style>
    <link rel='stylesheet' id='jquery-selectBox-css' href='https://basketeer.com/wp-content/plugins/yith-woocommerce-wishlist/assets/css/jquery.selectBox.css?ver=1.2.0' type='text/css' media='all' />
    <link rel='stylesheet' id='woocommerce_prettyPhoto_css-css' href='//basketeer.com/wp-content/plugins/woocommerce/assets/css/prettyPhoto.css?ver=3.1.6' type='text/css' media='all' />
    <link rel='stylesheet' id='yith-wcwl-main-css' href='https://basketeer.com/wp-content/plugins/yith-woocommerce-wishlist/assets/css/style.css?ver=4.9.0' type='text/css' media='all' />
    <style id='yith-wcwl-main-inline-css' type='text/css'>
        :root {
            --color-add-to-wishlist-background: #333333;
            --color-add-to-wishlist-text: #FFFFFF;
            --color-add-to-wishlist-border: #333333;
            --color-add-to-wishlist-background-hover: #333333;
            --color-add-to-wishlist-text-hover: #FFFFFF;
            --color-add-to-wishlist-border-hover: #333333;
            --rounded-corners-radius: 16px;
            --color-add-to-cart-background: #333333;
            --color-add-to-cart-text: #FFFFFF;
            --color-add-to-cart-border: #333333;
            --color-add-to-cart-background-hover: #4F4F4F;
            --color-add-to-cart-text-hover: #FFFFFF;
            --color-add-to-cart-border-hover: #4F4F4F;
            --add-to-cart-rounded-corners-radius: 16px;
            --color-button-style-1-background: #333333;
            --color-button-style-1-text: #FFFFFF;
            --color-button-style-1-border: #333333;
            --color-button-style-1-background-hover: #4F4F4F;
            --color-button-style-1-text-hover: #FFFFFF;
            --color-button-style-1-border-hover: #4F4F4F;
            --color-button-style-2-background: #333333;
            --color-button-style-2-text: #FFFFFF;
            --color-button-style-2-border: #333333;
            --color-button-style-2-background-hover: #4F4F4F;
            --color-button-style-2-text-hover: #FFFFFF;
            --color-button-style-2-border-hover: #4F4F4F;
            --color-wishlist-table-background: #FFFFFF;
            --color-wishlist-table-text: #6d6c6c;
            --color-wishlist-table-border: #FFFFFF;
            --color-headers-background: #F4F4F4;
            --color-share-button-color: #FFFFFF;
            --color-share-button-color-hover: #FFFFFF;
            --color-fb-button-background: #39599E;
            --color-fb-button-background-hover: #595A5A;
            --color-tw-button-background: #45AFE2;
            --color-tw-button-background-hover: #595A5A;
            --color-pr-button-background: #AB2E31;
            --color-pr-button-background-hover: #595A5A;
            --color-em-button-background: #FBB102;
            --color-em-button-background-hover: #595A5A;
            --color-wa-button-background: #00A901;
            --color-wa-button-background-hover: #595A5A;
            --feedback-duration: 3s
        }

        :root {
            --color-add-to-wishlist-background: #333333;
            --color-add-to-wishlist-text: #FFFFFF;
            --color-add-to-wishlist-border: #333333;
            --color-add-to-wishlist-background-hover: #333333;
            --color-add-to-wishlist-text-hover: #FFFFFF;
            --color-add-to-wishlist-border-hover: #333333;
            --rounded-corners-radius: 16px;
            --color-add-to-cart-background: #333333;
            --color-add-to-cart-text: #FFFFFF;
            --color-add-to-cart-border: #333333;
            --color-add-to-cart-background-hover: #4F4F4F;
            --color-add-to-cart-text-hover: #FFFFFF;
            --color-add-to-cart-border-hover: #4F4F4F;
            --add-to-cart-rounded-corners-radius: 16px;
            --color-button-style-1-background: #333333;
            --color-button-style-1-text: #FFFFFF;
            --color-button-style-1-border: #333333;
            --color-button-style-1-background-hover: #4F4F4F;
            --color-button-style-1-text-hover: #FFFFFF;
            --color-button-style-1-border-hover: #4F4F4F;
            --color-button-style-2-background: #333333;
            --color-button-style-2-text: #FFFFFF;
            --color-button-style-2-border: #333333;
            --color-button-style-2-background-hover: #4F4F4F;
            --color-button-style-2-text-hover: #FFFFFF;
            --color-button-style-2-border-hover: #4F4F4F;
            --color-wishlist-table-background: #FFFFFF;
            --color-wishlist-table-text: #6d6c6c;
            --color-wishlist-table-border: #FFFFFF;
            --color-headers-background: #F4F4F4;
            --color-share-button-color: #FFFFFF;
            --color-share-button-color-hover: #FFFFFF;
            --color-fb-button-background: #39599E;
            --color-fb-button-background-hover: #595A5A;
            --color-tw-button-background: #45AFE2;
            --color-tw-button-background-hover: #595A5A;
            --color-pr-button-background: #AB2E31;
            --color-pr-button-background-hover: #595A5A;
            --color-em-button-background: #FBB102;
            --color-em-button-background-hover: #595A5A;
            --color-wa-button-background: #00A901;
            --color-wa-button-background-hover: #595A5A;
            --feedback-duration: 3s
        }
    </style>
    <style id='font-awesome-svg-styles-default-inline-css' type='text/css'>
        .svg-inline--fa {
            display: inline-block;
            height: 1em;
            overflow: visible;
            vertical-align: -.125em;
        }
    </style>
    <link rel='stylesheet' id='font-awesome-svg-styles-css' href='https://basketeer.com/wp-content/uploads/font-awesome/v6.7.2/css/svg-with-js.css' type='text/css' media='all' />
    <style id='font-awesome-svg-styles-inline-css' type='text/css'>
        .wp-block-font-awesome-icon svg::before,
        .wp-rich-text-font-awesome-icon svg::before {
            content: unset;
        }
    </style>
    <style id='global-styles-inline-css' type='text/css'>
        :root {
            --wp--preset--aspect-ratio--square: 1;
            --wp--preset--aspect-ratio--4-3: 4/3;
            --wp--preset--aspect-ratio--3-4: 3/4;
            --wp--preset--aspect-ratio--3-2: 3/2;
            --wp--preset--aspect-ratio--2-3: 2/3;
            --wp--preset--aspect-ratio--16-9: 16/9;
            --wp--preset--aspect-ratio--9-16: 9/16;
            --wp--preset--color--black: #000000;
            --wp--preset--color--cyan-bluish-gray: #abb8c3;
            --wp--preset--color--white: #ffffff;
            --wp--preset--color--pale-pink: #f78da7;
            --wp--preset--color--vivid-red: #cf2e2e;
            --wp--preset--color--luminous-vivid-orange: #ff6900;
            --wp--preset--color--luminous-vivid-amber: #fcb900;
            --wp--preset--color--light-green-cyan: #7bdcb5;
            --wp--preset--color--vivid-green-cyan: #00d084;
            --wp--preset--color--pale-cyan-blue: #8ed1fc;
            --wp--preset--color--vivid-cyan-blue: #0693e3;
            --wp--preset--color--vivid-purple: #9b51e0;
            --wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg, rgba(6, 147, 227, 1) 0%, rgb(155, 81, 224) 100%);
            --wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg, rgb(122, 220, 180) 0%, rgb(0, 208, 130) 100%);
            --wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg, rgba(252, 185, 0, 1) 0%, rgba(255, 105, 0, 1) 100%);
            --wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg, rgba(255, 105, 0, 1) 0%, rgb(207, 46, 46) 100%);
            --wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg, rgb(238, 238, 238) 0%, rgb(169, 184, 195) 100%);
            --wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg, rgb(74, 234, 220) 0%, rgb(151, 120, 209) 20%, rgb(207, 42, 186) 40%, rgb(238, 44, 130) 60%, rgb(251, 105, 98) 80%, rgb(254, 248, 76) 100%);
            --wp--preset--gradient--blush-light-purple: linear-gradient(135deg, rgb(255, 206, 236) 0%, rgb(152, 150, 240) 100%);
            --wp--preset--gradient--blush-bordeaux: linear-gradient(135deg, rgb(254, 205, 165) 0%, rgb(254, 45, 45) 50%, rgb(107, 0, 62) 100%);
            --wp--preset--gradient--luminous-dusk: linear-gradient(135deg, rgb(255, 203, 112) 0%, rgb(199, 81, 192) 50%, rgb(65, 88, 208) 100%);
            --wp--preset--gradient--pale-ocean: linear-gradient(135deg, rgb(255, 245, 203) 0%, rgb(182, 227, 212) 50%, rgb(51, 167, 181) 100%);
            --wp--preset--gradient--electric-grass: linear-gradient(135deg, rgb(202, 248, 128) 0%, rgb(113, 206, 126) 100%);
            --wp--preset--gradient--midnight: linear-gradient(135deg, rgb(2, 3, 129) 0%, rgb(40, 116, 252) 100%);
            --wp--preset--font-size--small: 13px;
            --wp--preset--font-size--medium: 20px;
            --wp--preset--font-size--large: 36px;
            --wp--preset--font-size--x-large: 42px;
            --wp--preset--font-family--inter: "Inter", sans-serif;
            --wp--preset--font-family--cardo: Cardo;
            --wp--preset--spacing--20: 0.44rem;
            --wp--preset--spacing--30: 0.67rem;
            --wp--preset--spacing--40: 1rem;
            --wp--preset--spacing--50: 1.5rem;
            --wp--preset--spacing--60: 2.25rem;
            --wp--preset--spacing--70: 3.38rem;
            --wp--preset--spacing--80: 5.06rem;
            --wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);
            --wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);
            --wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);
            --wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);
            --wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);
        }

        :where(.is-layout-flex) {
            gap: 0.5em;
        }

        :where(.is-layout-grid) {
            gap: 0.5em;
        }

        body .is-layout-flex {
            display: flex;
        }

        .is-layout-flex {
            flex-wrap: wrap;
            align-items: center;
        }

        .is-layout-flex> :is(*, div) {
            margin: 0;
        }

        body .is-layout-grid {
            display: grid;
        }

        .is-layout-grid> :is(*, div) {
            margin: 0;
        }

        :where(.wp-block-columns.is-layout-flex) {
            gap: 2em;
        }

        :where(.wp-block-columns.is-layout-grid) {
            gap: 2em;
        }

        :where(.wp-block-post-template.is-layout-flex) {
            gap: 1.25em;
        }

        :where(.wp-block-post-template.is-layout-grid) {
            gap: 1.25em;
        }

        .has-black-color {
            color: var(--wp--preset--color--black) !important;
        }

        .has-cyan-bluish-gray-color {
            color: var(--wp--preset--color--cyan-bluish-gray) !important;
        }

        .has-white-color {
            color: var(--wp--preset--color--white) !important;
        }

        .has-pale-pink-color {
            color: var(--wp--preset--color--pale-pink) !important;
        }

        .has-vivid-red-color {
            color: var(--wp--preset--color--vivid-red) !important;
        }

        .has-luminous-vivid-orange-color {
            color: var(--wp--preset--color--luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-amber-color {
            color: var(--wp--preset--color--luminous-vivid-amber) !important;
        }

        .has-light-green-cyan-color {
            color: var(--wp--preset--color--light-green-cyan) !important;
        }

        .has-vivid-green-cyan-color {
            color: var(--wp--preset--color--vivid-green-cyan) !important;
        }

        .has-pale-cyan-blue-color {
            color: var(--wp--preset--color--pale-cyan-blue) !important;
        }

        .has-vivid-cyan-blue-color {
            color: var(--wp--preset--color--vivid-cyan-blue) !important;
        }

        .has-vivid-purple-color {
            color: var(--wp--preset--color--vivid-purple) !important;
        }

        .has-black-background-color {
            background-color: var(--wp--preset--color--black) !important;
        }

        .has-cyan-bluish-gray-background-color {
            background-color: var(--wp--preset--color--cyan-bluish-gray) !important;
        }

        .has-white-background-color {
            background-color: var(--wp--preset--color--white) !important;
        }

        .has-pale-pink-background-color {
            background-color: var(--wp--preset--color--pale-pink) !important;
        }

        .has-vivid-red-background-color {
            background-color: var(--wp--preset--color--vivid-red) !important;
        }

        .has-luminous-vivid-orange-background-color {
            background-color: var(--wp--preset--color--luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-amber-background-color {
            background-color: var(--wp--preset--color--luminous-vivid-amber) !important;
        }

        .has-light-green-cyan-background-color {
            background-color: var(--wp--preset--color--light-green-cyan) !important;
        }

        .has-vivid-green-cyan-background-color {
            background-color: var(--wp--preset--color--vivid-green-cyan) !important;
        }

        .has-pale-cyan-blue-background-color {
            background-color: var(--wp--preset--color--pale-cyan-blue) !important;
        }

        .has-vivid-cyan-blue-background-color {
            background-color: var(--wp--preset--color--vivid-cyan-blue) !important;
        }

        .has-vivid-purple-background-color {
            background-color: var(--wp--preset--color--vivid-purple) !important;
        }

        .has-black-border-color {
            border-color: var(--wp--preset--color--black) !important;
        }

        .has-cyan-bluish-gray-border-color {
            border-color: var(--wp--preset--color--cyan-bluish-gray) !important;
        }

        .has-white-border-color {
            border-color: var(--wp--preset--color--white) !important;
        }

        .has-pale-pink-border-color {
            border-color: var(--wp--preset--color--pale-pink) !important;
        }

        .has-vivid-red-border-color {
            border-color: var(--wp--preset--color--vivid-red) !important;
        }

        .has-luminous-vivid-orange-border-color {
            border-color: var(--wp--preset--color--luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-amber-border-color {
            border-color: var(--wp--preset--color--luminous-vivid-amber) !important;
        }

        .has-light-green-cyan-border-color {
            border-color: var(--wp--preset--color--light-green-cyan) !important;
        }

        .has-vivid-green-cyan-border-color {
            border-color: var(--wp--preset--color--vivid-green-cyan) !important;
        }

        .has-pale-cyan-blue-border-color {
            border-color: var(--wp--preset--color--pale-cyan-blue) !important;
        }

        .has-vivid-cyan-blue-border-color {
            border-color: var(--wp--preset--color--vivid-cyan-blue) !important;
        }

        .has-vivid-purple-border-color {
            border-color: var(--wp--preset--color--vivid-purple) !important;
        }

        .has-vivid-cyan-blue-to-vivid-purple-gradient-background {
            background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;
        }

        .has-light-green-cyan-to-vivid-green-cyan-gradient-background {
            background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;
        }

        .has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background {
            background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-orange-to-vivid-red-gradient-background {
            background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;
        }

        .has-very-light-gray-to-cyan-bluish-gray-gradient-background {
            background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;
        }

        .has-cool-to-warm-spectrum-gradient-background {
            background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;
        }

        .has-blush-light-purple-gradient-background {
            background: var(--wp--preset--gradient--blush-light-purple) !important;
        }

        .has-blush-bordeaux-gradient-background {
            background: var(--wp--preset--gradient--blush-bordeaux) !important;
        }

        .has-luminous-dusk-gradient-background {
            background: var(--wp--preset--gradient--luminous-dusk) !important;
        }

        .has-pale-ocean-gradient-background {
            background: var(--wp--preset--gradient--pale-ocean) !important;
        }

        .has-electric-grass-gradient-background {
            background: var(--wp--preset--gradient--electric-grass) !important;
        }

        .has-midnight-gradient-background {
            background: var(--wp--preset--gradient--midnight) !important;
        }

        .has-small-font-size {
            font-size: var(--wp--preset--font-size--small) !important;
        }

        .has-medium-font-size {
            font-size: var(--wp--preset--font-size--medium) !important;
        }

        .has-large-font-size {
            font-size: var(--wp--preset--font-size--large) !important;
        }

        .has-x-large-font-size {
            font-size: var(--wp--preset--font-size--x-large) !important;
        }

        :where(.wp-block-post-template.is-layout-flex) {
            gap: 1.25em;
        }

        :where(.wp-block-post-template.is-layout-grid) {
            gap: 1.25em;
        }

        :where(.wp-block-columns.is-layout-flex) {
            gap: 2em;
        }

        :where(.wp-block-columns.is-layout-grid) {
            gap: 2em;
        }

        :root :where(.wp-block-pullquote) {
            font-size: 1.5em;
            line-height: 1.6;
        }
    </style>
    <style id='age-gate-custom-inline-css' type='text/css'>
        :root {
            --ag-background-color: rgba(0, 0, 0, 0.4);
            --ag-background-image-position: center center;
            --ag-background-image-opacity: 1;
            --ag-form-background: rgba(255, 255, 255, 1);
            --ag-text-color: #000000;
            --ag-blur: 5px;
        }
    </style>
    <link rel='stylesheet' id='age-gate-css' href='https://basketeer.com/wp-content/plugins/age-gate/dist/main.css?ver=3.7.1' type='text/css' media='all' />
    <style id='age-gate-options-inline-css' type='text/css'>
        :root {
            --ag-background-color: rgba(0, 0, 0, 0.4);
            --ag-background-image-position: center center;
            --ag-background-image-opacity: 1;
            --ag-form-background: rgba(255, 255, 255, 1);
            --ag-text-color: #000000;
            --ag-blur: 5px;
        }
    </style>
    <link rel='stylesheet' id='basketeer-plugin-css-css' href='https://basketeer.com/wp-content/plugins/basketeer/assets/basketeer-plugin.css?ver=1.0.27' type='text/css' media='all' />
    <link rel='stylesheet' id='dnd-upload-cf7-css' href='https://basketeer.com/wp-content/plugins/drag-and-drop-multiple-file-upload-contact-form-7/assets/css/dnd-upload-cf7.css?ver=1.3.9.1' type='text/css' media='all' />
    <link rel='stylesheet' id='contact-form-7-css' href='https://basketeer.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=6.1.2' type='text/css' media='all' />
    <link rel='stylesheet' id='magniimage-css-css' href='https://basketeer.com/wp-content/plugins/magni-image-flip-for-woocommerce/assets/css/magniimage.css?ver=6.8.3' type='text/css' media='all' />
    <style id='magniimage-css-inline-css' type='text/css'>
        .imgsliderdots span.cycle-pager-active {
            color: #100e0e;
        }

        .imgflipdots span.cycle-pager-active {
            color: #100e0e;
        }

        .imgfadedots span.cycle-pager-active {
            color: #100e0e;
        }

        .imgsliderdots span {
            color: #b2b2ad;
        }

        .imgflipdots span {
            color: #b2b2ad;
        }

        .imgfadedots span {
            color: #b2b2ad;
        }

        .imgsliderdots {
            text-align: left;
            left: 5px;
            top: -15px;
        }

        .imgflipdots {
            text-align: left;
            left: 5px;
            top: -15px;
        }

        .imgfadedots {
            text-align: left;
            left: 5px;
            top: -15px;
        }
    </style>
    <link rel='stylesheet' id='bodhi-svgs-attachment-css' href='https://basketeer.com/wp-content/plugins/svg-support/css/svgs-attachment.css' type='text/css' media='all' />
    <link rel='stylesheet' id='tp-product-image-flipper-for-woocommerce-css' href='https://basketeer.com/wp-content/plugins/tp-product-image-flipper-for-woocommerce/css/tp-product-image-flipper-for-woocommerce.css?ver=6.8.3' type='text/css' media='all' />
    <link rel='stylesheet' id='woof-css' href='https://basketeer.com/wp-content/plugins/woocommerce-products-filter/css/front.css?ver=1.3.7.1' type='text/css' media='all' />
    <style id='woof-inline-css' type='text/css'>
        .woof_products_top_panel li span,
        .woof_products_top_panel2 li span {
            background: url(https://eadn-wc04-9792563.nxedge.io/wp-content/plugins/woocommerce-products-filter/img/delete.png);
            background-size: 14px 14px;
            background-repeat: no-repeat;
            background-position: right;
        }

        .woof_childs_list_opener span.woof_is_closed {
            background: url(https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/toggle-up.svg);
        }

        .woof_childs_list_opener span.woof_is_opened {
            background: url(https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/toggle-up.svg);
        }

        .woof_edit_view {
            display: none;
        }
    </style>
    <link rel='stylesheet' id='woof_by_author_html_items-css' href='https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/by_author/css/by_author.css?ver=1.3.7.1' type='text/css' media='all' />
    <link rel='stylesheet' id='woof_by_featured_html_items-css' href='https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/by_featured/css/by_featured.css?ver=1.3.7.1' type='text/css' media='all' />
    <link rel='stylesheet' id='woof_by_instock_html_items-css' href='https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/by_instock/css/by_instock.css?ver=1.3.7.1' type='text/css' media='all' />
    <link rel='stylesheet' id='woof_by_onsales_html_items-css' href='https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/by_onsales/css/by_onsales.css?ver=1.3.7.1' type='text/css' media='all' />
    <link rel='stylesheet' id='woof_by_text_html_items-css' href='https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/by_text/assets/css/front.css?ver=1.3.7.1' type='text/css' media='all' />
    <link rel='stylesheet' id='woof_label_html_items-css' href='https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/label/css/html_types/label.css?ver=1.3.7.1' type='text/css' media='all' />
    <link rel='stylesheet' id='woof_select_radio_check_html_items-css' href='https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/select_radio_check/css/html_types/select_radio_check.css?ver=1.3.7.1' type='text/css' media='all' />
    <link rel='stylesheet' id='woof_sd_html_items_checkbox-css' href='https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/smart_designer/css/elements/checkbox.css?ver=1.3.7.1' type='text/css' media='all' />
    <link rel='stylesheet' id='woof_sd_html_items_radio-css' href='https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/smart_designer/css/elements/radio.css?ver=1.3.7.1' type='text/css' media='all' />
    <link rel='stylesheet' id='woof_sd_html_items_switcher-css' href='https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/smart_designer/css/elements/switcher.css?ver=1.3.7.1' type='text/css' media='all' />
    <link rel='stylesheet' id='woof_sd_html_items_color-css' href='https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/smart_designer/css/elements/color.css?ver=1.3.7.1' type='text/css' media='all' />
    <link rel='stylesheet' id='woof_sd_html_items_tooltip-css' href='https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/smart_designer/css/tooltip.css?ver=1.3.7.1' type='text/css' media='all' />
    <link rel='stylesheet' id='woof_sd_html_items_front-css' href='https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/smart_designer/css/front.css?ver=1.3.7.1' type='text/css' media='all' />
    <link rel='stylesheet' id='woof-switcher23-css' href='https://basketeer.com/wp-content/plugins/woocommerce-products-filter/css/switcher.css?ver=1.3.7.1' type='text/css' media='all' />
    <link rel='stylesheet' id='woocommerce-layout-css' href='https://basketeer.com/wp-content/plugins/woocommerce/assets/css/woocommerce-layout.css?ver=9.5.1' type='text/css' media='all' />
    <link rel='stylesheet' id='woocommerce-smallscreen-css' href='https://basketeer.com/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen.css?ver=9.5.1' type='text/css' media='only screen and (max-width: 768px)' />
    <style id='woocommerce-inline-inline-css' type='text/css'>
        .woocommerce form .form-row .required {
            visibility: visible;
        }
    </style>
    <link rel='stylesheet' id='bootstrap_icons-css' href='https://basketeer.com/wp-content/themes/baskettheme/css/includes/main.css?ver=2025100909' type='text/css' media='all' />
    <link rel='stylesheet' id='bootstrap-css' href='https://basketeer.com/wp-content/themes/baskettheme/css/bootstrap/bootstrap.css?ver=5.2.3' type='text/css' media='all' />
    <link rel='stylesheet' id='screen-css' href='https://basketeer.com/wp-content/themes/baskettheme/style.css?ver=1.0.3.202509081524' type='text/css' media='screen' />
    <link rel='stylesheet' id='custom-fonts-css' href='https://basketeer.com/wp-content/themes/baskettheme/css/admin/custom-fonts.css?ver=1.0' type='text/css' media='all' />
    <link rel='stylesheet' id='splide-css-css' href='https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/css/splide.min.css?ver=4.1.4' type='text/css' media='all' />
    <link rel='stylesheet' id='font-autenshany-css-css' href='https://basketeer.com/wp-content/themes/baskettheme/fonts/autenshany.css?ver=202510081343' type='text/css' media='all' />
    <link rel='stylesheet' id='font-stixgeneral-regular-css-css' href='https://basketeer.com/wp-content/themes/baskettheme/fonts/stixgeneral-regular.css?ver=202510081343' type='text/css' media='all' />
    <link rel='stylesheet' id='style-th-css' href='https://basketeer.com/wp-content/themes/baskettheme/style-th.css?ver=202510081343' type='text/css' media='all' />
    <link rel='stylesheet' id='style-product-css' href='https://basketeer.com/wp-content/themes/baskettheme/style-product.css?ver=202510081343' type='text/css' media='all' />
    <link rel='stylesheet' id='style-blog-css' href='https://basketeer.com/wp-content/themes/baskettheme/style-blog.css?ver=202510081343' type='text/css' media='all' />
    <link rel='stylesheet' id='bootstrap-icons-css' href='https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css?ver=1.11.3' type='text/css' media='all' />
    <link rel='stylesheet' id='font-awesome-official-css' href='https://use.fontawesome.com/releases/v6.7.2/css/all.css' type='text/css' media='all' integrity="sha384-nRgPTkuX86pH8yjPJUAFuASXQSSl2/bBUiNV47vSYpKFxHJhbcrGnmlYpYJMeD7a" crossorigin="anonymous"
    />
    <link rel='stylesheet' id='wp-pagenavi-css' href='https://basketeer.com/wp-content/plugins/wp-pagenavi/pagenavi-css.css?ver=2.70' type='text/css' media='all' />
    <link rel='stylesheet' id='chaty-front-css-css' href='https://basketeer.com/wp-content/plugins/chaty/css/chaty-front.min.css?ver=3.4.81712882197' type='text/css' media='all' />
    <link rel='stylesheet' id='charlotte-caslon-css' href='https://basketeer.com/wp-content/themes/baskettheme/fonts/charlotte-caslon-font-pack/charlotte-fonts.css' type='text/css' media='all' />
    <link rel='stylesheet' id='font-awesome-official-v4shim-css' href='https://use.fontawesome.com/releases/v6.7.2/css/v4-shims.css' type='text/css' media='all' integrity="sha384-npPMK6zwqNmU3qyCCxEcWJkLBNYxEFM1nGgSoAWuCCXqVVz0cvwKEMfyTNkOxM2N" crossorigin="anonymous"
    />
    <script type="text/javascript" id="cookie-law-info-js-extra">
        /* <![CDATA[ */
        var _ckyConfig = {
            "_ipData": [],
            "_assetsURL": "https:\/\/basketeer.com\/wp-content\/plugins\/cookie-law-info\/lite\/frontend\/images\/",
            "_publicURL": "https:\/\/basketeer.com",
            "_expiry": "365",
            "_categories": [{
                "name": "Necessary",
                "slug": "necessary",
                "isNecessary": true,
                "ccpaDoNotSell": true,
                "cookies": [],
                "active": true,
                "defaultConsent": {
                    "gdpr": true,
                    "ccpa": true
                }
            }, {
                "name": "Functional",
                "slug": "functional",
                "isNecessary": false,
                "ccpaDoNotSell": true,
                "cookies": [],
                "active": true,
                "defaultConsent": {
                    "gdpr": false,
                    "ccpa": false
                }
            }, {
                "name": "Analytics",
                "slug": "analytics",
                "isNecessary": false,
                "ccpaDoNotSell": true,
                "cookies": [],
                "active": true,
                "defaultConsent": {
                    "gdpr": false,
                    "ccpa": false
                }
            }, {
                "name": "Performance",
                "slug": "performance",
                "isNecessary": false,
                "ccpaDoNotSell": true,
                "cookies": [],
                "active": true,
                "defaultConsent": {
                    "gdpr": false,
                    "ccpa": false
                }
            }, {
                "name": "Advertisement",
                "slug": "advertisement",
                "isNecessary": false,
                "ccpaDoNotSell": true,
                "cookies": [],
                "active": true,
                "defaultConsent": {
                    "gdpr": false,
                    "ccpa": false
                }
            }],
            "_activeLaw": "gdpr",
            "_rootDomain": "",
            "_block": "1",
            "_showBanner": "1",
            "_bannerConfig": {
                "settings": {
                    "type": "banner",
                    "preferenceCenterType": "popup",
                    "position": "bottom",
                    "applicableLaw": "gdpr"
                },
                "behaviours": {
                    "reloadBannerOnAccept": false,
                    "loadAnalyticsByDefault": false,
                    "animations": {
                        "onLoad": "animate",
                        "onHide": "sticky"
                    }
                },
                "config": {
                    "revisitConsent": {
                        "status": true,
                        "tag": "revisit-consent",
                        "position": "bottom-left",
                        "meta": {
                            "url": "#"
                        },
                        "styles": {
                            "background-color": "#c09a5c"
                        },
                        "elements": {
                            "title": {
                                "type": "text",
                                "tag": "revisit-consent-title",
                                "status": true,
                                "styles": {
                                    "color": "#0056a7"
                                }
                            }
                        }
                    },
                    "preferenceCenter": {
                        "toggle": {
                            "status": true,
                            "tag": "detail-category-toggle",
                            "type": "toggle",
                            "states": {
                                "active": {
                                    "styles": {
                                        "background-color": "#1863DC"
                                    }
                                },
                                "inactive": {
                                    "styles": {
                                        "background-color": "#D0D5D2"
                                    }
                                }
                            }
                        }
                    },
                    "categoryPreview": {
                        "status": false,
                        "toggle": {
                            "status": true,
                            "tag": "detail-category-preview-toggle",
                            "type": "toggle",
                            "states": {
                                "active": {
                                    "styles": {
                                        "background-color": "#1863DC"
                                    }
                                },
                                "inactive": {
                                    "styles": {
                                        "background-color": "#D0D5D2"
                                    }
                                }
                            }
                        }
                    },
                    "videoPlaceholder": {
                        "status": true,
                        "styles": {
                            "background-color": "#000000",
                            "border-color": "#000000",
                            "color": "#ffffff"
                        }
                    },
                    "readMore": {
                        "status": false,
                        "tag": "readmore-button",
                        "type": "link",
                        "meta": {
                            "noFollow": true,
                            "newTab": true
                        },
                        "styles": {
                            "color": "#c09a5c",
                            "background-color": "transparent",
                            "border-color": "transparent"
                        }
                    },
                    "auditTable": {
                        "status": true
                    },
                    "optOption": {
                        "status": true,
                        "toggle": {
                            "status": true,
                            "tag": "optout-option-toggle",
                            "type": "toggle",
                            "states": {
                                "active": {
                                    "styles": {
                                        "background-color": "#1863dc"
                                    }
                                },
                                "inactive": {
                                    "styles": {
                                        "background-color": "#FFFFFF"
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "_version": "3.3.5",
            "_logConsent": "1",
            "_tags": [{
                "tag": "accept-button",
                "styles": {
                    "color": "#FFFFFF",
                    "background-color": "#c09a5c",
                    "border-color": "#c09a5c"
                }
            }, {
                "tag": "reject-button",
                "styles": {
                    "color": "#c09a5c",
                    "background-color": "transparent",
                    "border-color": "#c09a5c"
                }
            }, {
                "tag": "settings-button",
                "styles": {
                    "color": "#c09a5c",
                    "background-color": "transparent",
                    "border-color": "#c09a5c"
                }
            }, {
                "tag": "readmore-button",
                "styles": {
                    "color": "#c09a5c",
                    "background-color": "transparent",
                    "border-color": "transparent"
                }
            }, {
                "tag": "donotsell-button",
                "styles": {
                    "color": "#1863DC",
                    "background-color": "transparent",
                    "border-color": "transparent"
                }
            }, {
                "tag": "accept-button",
                "styles": {
                    "color": "#FFFFFF",
                    "background-color": "#c09a5c",
                    "border-color": "#c09a5c"
                }
            }, {
                "tag": "revisit-consent",
                "styles": {
                    "background-color": "#c09a5c"
                }
            }],
            "_shortCodes": [{
                "key": "cky_readmore",
                "content": "<a href=\"#\" class=\"cky-policy\" aria-label=\"Cookie Policy\" target=\"_blank\" rel=\"noopener\" data-cky-tag=\"readmore-button\">Cookie Policy<\/a>",
                "tag": "readmore-button",
                "status": false,
                "attributes": {
                    "rel": "nofollow",
                    "target": "_blank"
                }
            }, {
                "key": "cky_show_desc",
                "content": "<button class=\"cky-show-desc-btn\" data-cky-tag=\"show-desc-button\" aria-label=\"Show more\">Show more<\/button>",
                "tag": "show-desc-button",
                "status": true,
                "attributes": []
            }, {
                "key": "cky_hide_desc",
                "content": "<button class=\"cky-show-desc-btn\" data-cky-tag=\"hide-desc-button\" aria-label=\"Show less\">Show less<\/button>",
                "tag": "hide-desc-button",
                "status": true,
                "attributes": []
            }, {
                "key": "cky_category_toggle_label",
                "content": "[cky_{{status}}_category_label] [cky_preference_{{category_slug}}_title]",
                "tag": "",
                "status": true,
                "attributes": []
            }, {
                "key": "cky_enable_category_label",
                "content": "Enable",
                "tag": "",
                "status": true,
                "attributes": []
            }, {
                "key": "cky_disable_category_label",
                "content": "Disable",
                "tag": "",
                "status": true,
                "attributes": []
            }, {
                "key": "cky_video_placeholder",
                "content": "<div class=\"video-placeholder-normal\" data-cky-tag=\"video-placeholder\" id=\"[UNIQUEID]\"><p class=\"video-placeholder-text-normal\" data-cky-tag=\"placeholder-title\">Please accept cookies to access this content<\/p><\/div>",
                "tag": "",
                "status": true,
                "attributes": []
            }, {
                "key": "cky_enable_optout_label",
                "content": "Enable",
                "tag": "",
                "status": true,
                "attributes": []
            }, {
                "key": "cky_disable_optout_label",
                "content": "Disable",
                "tag": "",
                "status": true,
                "attributes": []
            }, {
                "key": "cky_optout_toggle_label",
                "content": "[cky_{{status}}_optout_label] [cky_optout_option_title]",
                "tag": "",
                "status": true,
                "attributes": []
            }, {
                "key": "cky_optout_option_title",
                "content": "Do Not Sell or Share My Personal Information",
                "tag": "",
                "status": true,
                "attributes": []
            }, {
                "key": "cky_optout_close_label",
                "content": "Close",
                "tag": "",
                "status": true,
                "attributes": []
            }, {
                "key": "cky_preference_close_label",
                "content": "Close",
                "tag": "",
                "status": true,
                "attributes": []
            }],
            "_rtl": "",
            "_language": "en",
            "_providersToBlock": []
        };
        var _ckyStyles = {
            "css": ".cky-overlay{background: #000000; opacity: 0.4; position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 99999999;}.cky-hide{display: none;}.cky-btn-revisit-wrapper{display: flex; align-items: center; justify-content: center; background: #0056a7; width: 45px; height: 45px; border-radius: 50%; position: fixed; z-index: 999999; cursor: pointer;}.cky-revisit-bottom-left{bottom: 15px; left: 15px;}.cky-revisit-bottom-right{bottom: 15px; right: 15px;}.cky-btn-revisit-wrapper .cky-btn-revisit{display: flex; align-items: center; justify-content: center; background: none; border: none; cursor: pointer; position: relative; margin: 0; padding: 0;}.cky-btn-revisit-wrapper .cky-btn-revisit img{max-width: fit-content; margin: 0; height: 30px; width: 30px;}.cky-revisit-bottom-left:hover::before{content: attr(data-tooltip); position: absolute; background: #4e4b66; color: #ffffff; left: calc(100% + 7px); font-size: 12px; line-height: 16px; width: max-content; padding: 4px 8px; border-radius: 4px;}.cky-revisit-bottom-left:hover::after{position: absolute; content: \"\"; border: 5px solid transparent; left: calc(100% + 2px); border-left-width: 0; border-right-color: #4e4b66;}.cky-revisit-bottom-right:hover::before{content: attr(data-tooltip); position: absolute; background: #4e4b66; color: #ffffff; right: calc(100% + 7px); font-size: 12px; line-height: 16px; width: max-content; padding: 4px 8px; border-radius: 4px;}.cky-revisit-bottom-right:hover::after{position: absolute; content: \"\"; border: 5px solid transparent; right: calc(100% + 2px); border-right-width: 0; border-left-color: #4e4b66;}.cky-revisit-hide{display: none;}.cky-consent-container{position: fixed; width: 100%; box-sizing: border-box; z-index: 9999999;}.cky-consent-container .cky-consent-bar{background: #ffffff; border: 1px solid; padding: 16.5px 24px; box-shadow: 0 -1px 10px 0 #acabab4d;}.cky-banner-bottom{bottom: 0; left: 0;}.cky-banner-top{top: 0; left: 0;}.cky-custom-brand-logo-wrapper .cky-custom-brand-logo{width: 100px; height: auto; margin: 0 0 12px 0;}.cky-notice .cky-title{color: #212121; font-weight: 700; font-size: 18px; line-height: 24px; margin: 0 0 12px 0;}.cky-notice-group{display: flex; justify-content: space-between; align-items: center; font-size: 14px; line-height: 24px; font-weight: 400;}.cky-notice-des *,.cky-preference-content-wrapper *,.cky-accordion-header-des *,.cky-gpc-wrapper .cky-gpc-desc *{font-size: 14px;}.cky-notice-des{color: #212121; font-size: 14px; line-height: 24px; font-weight: 400;}.cky-notice-des img{height: 25px; width: 25px;}.cky-consent-bar .cky-notice-des p,.cky-gpc-wrapper .cky-gpc-desc p,.cky-preference-body-wrapper .cky-preference-content-wrapper p,.cky-accordion-header-wrapper .cky-accordion-header-des p,.cky-cookie-des-table li div:last-child p{color: inherit; margin-top: 0; overflow-wrap: break-word;}.cky-notice-des P:last-child,.cky-preference-content-wrapper p:last-child,.cky-cookie-des-table li div:last-child p:last-child,.cky-gpc-wrapper .cky-gpc-desc p:last-child{margin-bottom: 0;}.cky-notice-des a.cky-policy,.cky-notice-des button.cky-policy{font-size: 14px; color: #1863dc; white-space: nowrap; cursor: pointer; background: transparent; border: 1px solid; text-decoration: underline;}.cky-notice-des button.cky-policy{padding: 0;}.cky-notice-des a.cky-policy:focus-visible,.cky-notice-des button.cky-policy:focus-visible,.cky-preference-content-wrapper .cky-show-desc-btn:focus-visible,.cky-accordion-header .cky-accordion-btn:focus-visible,.cky-preference-header .cky-btn-close:focus-visible,.cky-switch input[type=\"checkbox\"]:focus-visible,.cky-footer-wrapper a:focus-visible,.cky-btn:focus-visible{outline: 2px solid #1863dc; outline-offset: 2px;}.cky-btn:focus:not(:focus-visible),.cky-accordion-header .cky-accordion-btn:focus:not(:focus-visible),.cky-preference-content-wrapper .cky-show-desc-btn:focus:not(:focus-visible),.cky-btn-revisit-wrapper .cky-btn-revisit:focus:not(:focus-visible),.cky-preference-header .cky-btn-close:focus:not(:focus-visible),.cky-consent-bar .cky-banner-btn-close:focus:not(:focus-visible){outline: 0;}button.cky-show-desc-btn:not(:hover):not(:active){color: #1863dc; background: transparent;}button.cky-accordion-btn:not(:hover):not(:active),button.cky-banner-btn-close:not(:hover):not(:active),button.cky-btn-close:not(:hover):not(:active),button.cky-btn-revisit:not(:hover):not(:active){background: transparent;}.cky-consent-bar button:hover,.cky-modal.cky-modal-open button:hover,.cky-consent-bar button:focus,.cky-modal.cky-modal-open button:focus{text-decoration: none;}.cky-notice-btn-wrapper{display: flex; justify-content: center; align-items: center; margin-left: 15px;}.cky-notice-btn-wrapper .cky-btn{text-shadow: none; box-shadow: none;}.cky-btn{font-size: 14px; font-family: inherit; line-height: 24px; padding: 8px 27px; font-weight: 500; margin: 0 8px 0 0; border-radius: 2px; white-space: nowrap; cursor: pointer; text-align: center; text-transform: none; min-height: 0;}.cky-btn:hover{opacity: 0.8;}.cky-btn-customize{color: #1863dc; background: transparent; border: 2px solid #1863dc;}.cky-btn-reject{color: #1863dc; background: transparent; border: 2px solid #1863dc;}.cky-btn-accept{background: #1863dc; color: #ffffff; border: 2px solid #1863dc;}.cky-btn:last-child{margin-right: 0;}@media (max-width: 768px){.cky-notice-group{display: block;}.cky-notice-btn-wrapper{margin-left: 0;}.cky-notice-btn-wrapper .cky-btn{flex: auto; max-width: 100%; margin-top: 10px; white-space: unset;}}@media (max-width: 576px){.cky-notice-btn-wrapper{flex-direction: column;}.cky-custom-brand-logo-wrapper, .cky-notice .cky-title, .cky-notice-des, .cky-notice-btn-wrapper{padding: 0 28px;}.cky-consent-container .cky-consent-bar{padding: 16.5px 0;}.cky-notice-des{max-height: 40vh; overflow-y: scroll;}.cky-notice-btn-wrapper .cky-btn{width: 100%; padding: 8px; margin-right: 0;}.cky-notice-btn-wrapper .cky-btn-accept{order: 1;}.cky-notice-btn-wrapper .cky-btn-reject{order: 3;}.cky-notice-btn-wrapper .cky-btn-customize{order: 2;}}@media (max-width: 425px){.cky-custom-brand-logo-wrapper, .cky-notice .cky-title, .cky-notice-des, .cky-notice-btn-wrapper{padding: 0 24px;}.cky-notice-btn-wrapper{flex-direction: column;}.cky-btn{width: 100%; margin: 10px 0 0 0;}.cky-notice-btn-wrapper .cky-btn-customize{order: 2;}.cky-notice-btn-wrapper .cky-btn-reject{order: 3;}.cky-notice-btn-wrapper .cky-btn-accept{order: 1; margin-top: 16px;}}@media (max-width: 352px){.cky-notice .cky-title{font-size: 16px;}.cky-notice-des *{font-size: 12px;}.cky-notice-des, .cky-btn{font-size: 12px;}}.cky-modal.cky-modal-open{display: flex; visibility: visible; -webkit-transform: translate(-50%, -50%); -moz-transform: translate(-50%, -50%); -ms-transform: translate(-50%, -50%); -o-transform: translate(-50%, -50%); transform: translate(-50%, -50%); top: 50%; left: 50%; transition: all 1s ease;}.cky-modal{box-shadow: 0 32px 68px rgba(0, 0, 0, 0.3); margin: 0 auto; position: fixed; max-width: 100%; background: #ffffff; top: 50%; box-sizing: border-box; border-radius: 6px; z-index: 999999999; color: #212121; -webkit-transform: translate(-50%, 100%); -moz-transform: translate(-50%, 100%); -ms-transform: translate(-50%, 100%); -o-transform: translate(-50%, 100%); transform: translate(-50%, 100%); visibility: hidden; transition: all 0s ease;}.cky-preference-center{max-height: 79vh; overflow: hidden; width: 845px; overflow: hidden; flex: 1 1 0; display: flex; flex-direction: column; border-radius: 6px;}.cky-preference-header{display: flex; align-items: center; justify-content: space-between; padding: 22px 24px; border-bottom: 1px solid;}.cky-preference-header .cky-preference-title{font-size: 18px; font-weight: 700; line-height: 24px;}.cky-preference-header .cky-btn-close{margin: 0; cursor: pointer; vertical-align: middle; padding: 0; background: none; border: none; width: auto; height: auto; min-height: 0; line-height: 0; text-shadow: none; box-shadow: none;}.cky-preference-header .cky-btn-close img{margin: 0; height: 10px; width: 10px;}.cky-preference-body-wrapper{padding: 0 24px; flex: 1; overflow: auto; box-sizing: border-box;}.cky-preference-content-wrapper,.cky-gpc-wrapper .cky-gpc-desc{font-size: 14px; line-height: 24px; font-weight: 400; padding: 12px 0;}.cky-preference-content-wrapper{border-bottom: 1px solid;}.cky-preference-content-wrapper img{height: 25px; width: 25px;}.cky-preference-content-wrapper .cky-show-desc-btn{font-size: 14px; font-family: inherit; color: #1863dc; text-decoration: none; line-height: 24px; padding: 0; margin: 0; white-space: nowrap; cursor: pointer; background: transparent; border-color: transparent; text-transform: none; min-height: 0; text-shadow: none; box-shadow: none;}.cky-accordion-wrapper{margin-bottom: 10px;}.cky-accordion{border-bottom: 1px solid;}.cky-accordion:last-child{border-bottom: none;}.cky-accordion .cky-accordion-item{display: flex; margin-top: 10px;}.cky-accordion .cky-accordion-body{display: none;}.cky-accordion.cky-accordion-active .cky-accordion-body{display: block; padding: 0 22px; margin-bottom: 16px;}.cky-accordion-header-wrapper{cursor: pointer; width: 100%;}.cky-accordion-item .cky-accordion-header{display: flex; justify-content: space-between; align-items: center;}.cky-accordion-header .cky-accordion-btn{font-size: 16px; font-family: inherit; color: #212121; line-height: 24px; background: none; border: none; font-weight: 700; padding: 0; margin: 0; cursor: pointer; text-transform: none; min-height: 0; text-shadow: none; box-shadow: none;}.cky-accordion-header .cky-always-active{color: #008000; font-weight: 600; line-height: 24px; font-size: 14px;}.cky-accordion-header-des{font-size: 14px; line-height: 24px; margin: 10px 0 16px 0;}.cky-accordion-chevron{margin-right: 22px; position: relative; cursor: pointer;}.cky-accordion-chevron-hide{display: none;}.cky-accordion .cky-accordion-chevron i::before{content: \"\"; position: absolute; border-right: 1.4px solid; border-bottom: 1.4px solid; border-color: inherit; height: 6px; width: 6px; -webkit-transform: rotate(-45deg); -moz-transform: rotate(-45deg); -ms-transform: rotate(-45deg); -o-transform: rotate(-45deg); transform: rotate(-45deg); transition: all 0.2s ease-in-out; top: 8px;}.cky-accordion.cky-accordion-active .cky-accordion-chevron i::before{-webkit-transform: rotate(45deg); -moz-transform: rotate(45deg); -ms-transform: rotate(45deg); -o-transform: rotate(45deg); transform: rotate(45deg);}.cky-audit-table{background: #f4f4f4; border-radius: 6px;}.cky-audit-table .cky-empty-cookies-text{color: inherit; font-size: 12px; line-height: 24px; margin: 0; padding: 10px;}.cky-audit-table .cky-cookie-des-table{font-size: 12px; line-height: 24px; font-weight: normal; padding: 15px 10px; border-bottom: 1px solid; border-bottom-color: inherit; margin: 0;}.cky-audit-table .cky-cookie-des-table:last-child{border-bottom: none;}.cky-audit-table .cky-cookie-des-table li{list-style-type: none; display: flex; padding: 3px 0;}.cky-audit-table .cky-cookie-des-table li:first-child{padding-top: 0;}.cky-cookie-des-table li div:first-child{width: 100px; font-weight: 600; word-break: break-word; word-wrap: break-word;}.cky-cookie-des-table li div:last-child{flex: 1; word-break: break-word; word-wrap: break-word; margin-left: 8px;}.cky-footer-shadow{display: block; width: 100%; height: 40px; background: linear-gradient(180deg, rgba(255, 255, 255, 0) 0%, #ffffff 100%); position: absolute; bottom: calc(100% - 1px);}.cky-footer-wrapper{position: relative;}.cky-prefrence-btn-wrapper{display: flex; flex-wrap: wrap; align-items: center; justify-content: center; padding: 22px 24px; border-top: 1px solid;}.cky-prefrence-btn-wrapper .cky-btn{flex: auto; max-width: 100%; text-shadow: none; box-shadow: none;}.cky-btn-preferences{color: #1863dc; background: transparent; border: 2px solid #1863dc;}.cky-preference-header,.cky-preference-body-wrapper,.cky-preference-content-wrapper,.cky-accordion-wrapper,.cky-accordion,.cky-accordion-wrapper,.cky-footer-wrapper,.cky-prefrence-btn-wrapper{border-color: inherit;}@media (max-width: 845px){.cky-modal{max-width: calc(100% - 16px);}}@media (max-width: 576px){.cky-modal{max-width: 100%;}.cky-preference-center{max-height: 100vh;}.cky-prefrence-btn-wrapper{flex-direction: column;}.cky-accordion.cky-accordion-active .cky-accordion-body{padding-right: 0;}.cky-prefrence-btn-wrapper .cky-btn{width: 100%; margin: 10px 0 0 0;}.cky-prefrence-btn-wrapper .cky-btn-reject{order: 3;}.cky-prefrence-btn-wrapper .cky-btn-accept{order: 1; margin-top: 0;}.cky-prefrence-btn-wrapper .cky-btn-preferences{order: 2;}}@media (max-width: 425px){.cky-accordion-chevron{margin-right: 15px;}.cky-notice-btn-wrapper{margin-top: 0;}.cky-accordion.cky-accordion-active .cky-accordion-body{padding: 0 15px;}}@media (max-width: 352px){.cky-preference-header .cky-preference-title{font-size: 16px;}.cky-preference-header{padding: 16px 24px;}.cky-preference-content-wrapper *, .cky-accordion-header-des *{font-size: 12px;}.cky-preference-content-wrapper, .cky-preference-content-wrapper .cky-show-more, .cky-accordion-header .cky-always-active, .cky-accordion-header-des, .cky-preference-content-wrapper .cky-show-desc-btn, .cky-notice-des a.cky-policy{font-size: 12px;}.cky-accordion-header .cky-accordion-btn{font-size: 14px;}}.cky-switch{display: flex;}.cky-switch input[type=\"checkbox\"]{position: relative; width: 44px; height: 24px; margin: 0; background: #d0d5d2; -webkit-appearance: none; border-radius: 50px; cursor: pointer; outline: 0; border: none; top: 0;}.cky-switch input[type=\"checkbox\"]:checked{background: #1863dc;}.cky-switch input[type=\"checkbox\"]:before{position: absolute; content: \"\"; height: 20px; width: 20px; left: 2px; bottom: 2px; border-radius: 50%; background-color: white; -webkit-transition: 0.4s; transition: 0.4s; margin: 0;}.cky-switch input[type=\"checkbox\"]:after{display: none;}.cky-switch input[type=\"checkbox\"]:checked:before{-webkit-transform: translateX(20px); -ms-transform: translateX(20px); transform: translateX(20px);}@media (max-width: 425px){.cky-switch input[type=\"checkbox\"]{width: 38px; height: 21px;}.cky-switch input[type=\"checkbox\"]:before{height: 17px; width: 17px;}.cky-switch input[type=\"checkbox\"]:checked:before{-webkit-transform: translateX(17px); -ms-transform: translateX(17px); transform: translateX(17px);}}.cky-consent-bar .cky-banner-btn-close{position: absolute; right: 9px; top: 5px; background: none; border: none; cursor: pointer; padding: 0; margin: 0; min-height: 0; line-height: 0; height: auto; width: auto; text-shadow: none; box-shadow: none;}.cky-consent-bar .cky-banner-btn-close img{height: 9px; width: 9px; margin: 0;}.cky-notice-btn-wrapper .cky-btn-do-not-sell{font-size: 14px; line-height: 24px; padding: 6px 0; margin: 0; font-weight: 500; background: none; border-radius: 2px; border: none; cursor: pointer; text-align: left; color: #1863dc; background: transparent; border-color: transparent; box-shadow: none; text-shadow: none;}.cky-consent-bar .cky-banner-btn-close:focus-visible,.cky-notice-btn-wrapper .cky-btn-do-not-sell:focus-visible,.cky-opt-out-btn-wrapper .cky-btn:focus-visible,.cky-opt-out-checkbox-wrapper input[type=\"checkbox\"].cky-opt-out-checkbox:focus-visible{outline: 2px solid #1863dc; outline-offset: 2px;}@media (max-width: 768px){.cky-notice-btn-wrapper{margin-left: 0; margin-top: 10px; justify-content: left;}.cky-notice-btn-wrapper .cky-btn-do-not-sell{padding: 0;}}@media (max-width: 352px){.cky-notice-btn-wrapper .cky-btn-do-not-sell, .cky-notice-des a.cky-policy{font-size: 12px;}}.cky-opt-out-wrapper{padding: 12px 0;}.cky-opt-out-wrapper .cky-opt-out-checkbox-wrapper{display: flex; align-items: center;}.cky-opt-out-checkbox-wrapper .cky-opt-out-checkbox-label{font-size: 16px; font-weight: 700; line-height: 24px; margin: 0 0 0 12px; cursor: pointer;}.cky-opt-out-checkbox-wrapper input[type=\"checkbox\"].cky-opt-out-checkbox{background-color: #ffffff; border: 1px solid black; width: 20px; height: 18.5px; margin: 0; -webkit-appearance: none; position: relative; display: flex; align-items: center; justify-content: center; border-radius: 2px; cursor: pointer;}.cky-opt-out-checkbox-wrapper input[type=\"checkbox\"].cky-opt-out-checkbox:checked{background-color: #1863dc; border: none;}.cky-opt-out-checkbox-wrapper input[type=\"checkbox\"].cky-opt-out-checkbox:checked::after{left: 6px; bottom: 4px; width: 7px; height: 13px; border: solid #ffffff; border-width: 0 3px 3px 0; border-radius: 2px; -webkit-transform: rotate(45deg); -ms-transform: rotate(45deg); transform: rotate(45deg); content: \"\"; position: absolute; box-sizing: border-box;}.cky-opt-out-checkbox-wrapper.cky-disabled .cky-opt-out-checkbox-label,.cky-opt-out-checkbox-wrapper.cky-disabled input[type=\"checkbox\"].cky-opt-out-checkbox{cursor: no-drop;}.cky-gpc-wrapper{margin: 0 0 0 32px;}.cky-footer-wrapper .cky-opt-out-btn-wrapper{display: flex; flex-wrap: wrap; align-items: center; justify-content: center; padding: 22px 24px;}.cky-opt-out-btn-wrapper .cky-btn{flex: auto; max-width: 100%; text-shadow: none; box-shadow: none;}.cky-opt-out-btn-wrapper .cky-btn-cancel{border: 1px solid #dedfe0; background: transparent; color: #858585;}.cky-opt-out-btn-wrapper .cky-btn-confirm{background: #1863dc; color: #ffffff; border: 1px solid #1863dc;}@media (max-width: 352px){.cky-opt-out-checkbox-wrapper .cky-opt-out-checkbox-label{font-size: 14px;}.cky-gpc-wrapper .cky-gpc-desc, .cky-gpc-wrapper .cky-gpc-desc *{font-size: 12px;}.cky-opt-out-checkbox-wrapper input[type=\"checkbox\"].cky-opt-out-checkbox{width: 16px; height: 16px;}.cky-opt-out-checkbox-wrapper input[type=\"checkbox\"].cky-opt-out-checkbox:checked::after{left: 5px; bottom: 4px; width: 3px; height: 9px;}.cky-gpc-wrapper{margin: 0 0 0 28px;}}.video-placeholder-youtube{background-size: 100% 100%; background-position: center; background-repeat: no-repeat; background-color: #b2b0b059; position: relative; display: flex; align-items: center; justify-content: center; max-width: 100%;}.video-placeholder-text-youtube{text-align: center; align-items: center; padding: 10px 16px; background-color: #000000cc; color: #ffffff; border: 1px solid; border-radius: 2px; cursor: pointer;}.video-placeholder-normal{background-image: url(\"\/\/eadn-wc04-9792563.nxedge.io\/wp-content\/plugins\/cookie-law-info\/lite\/frontend\/images\/placeholder.svg\"); background-size: 80px; background-position: center; background-repeat: no-repeat; background-color: #b2b0b059; position: relative; display: flex; align-items: flex-end; justify-content: center; max-width: 100%;}.video-placeholder-text-normal{align-items: center; padding: 10px 16px; text-align: center; border: 1px solid; border-radius: 2px; cursor: pointer;}.cky-rtl{direction: rtl; text-align: right;}.cky-rtl .cky-banner-btn-close{left: 9px; right: auto;}.cky-rtl .cky-notice-btn-wrapper .cky-btn:last-child{margin-right: 8px;}.cky-rtl .cky-notice-btn-wrapper .cky-btn:first-child{margin-right: 0;}.cky-rtl .cky-notice-btn-wrapper{margin-left: 0; margin-right: 15px;}.cky-rtl .cky-prefrence-btn-wrapper .cky-btn{margin-right: 8px;}.cky-rtl .cky-prefrence-btn-wrapper .cky-btn:first-child{margin-right: 0;}.cky-rtl .cky-accordion .cky-accordion-chevron i::before{border: none; border-left: 1.4px solid; border-top: 1.4px solid; left: 12px;}.cky-rtl .cky-accordion.cky-accordion-active .cky-accordion-chevron i::before{-webkit-transform: rotate(-135deg); -moz-transform: rotate(-135deg); -ms-transform: rotate(-135deg); -o-transform: rotate(-135deg); transform: rotate(-135deg);}@media (max-width: 768px){.cky-rtl .cky-notice-btn-wrapper{margin-right: 0;}}@media (max-width: 576px){.cky-rtl .cky-notice-btn-wrapper .cky-btn:last-child{margin-right: 0;}.cky-rtl .cky-prefrence-btn-wrapper .cky-btn{margin-right: 0;}.cky-rtl .cky-accordion.cky-accordion-active .cky-accordion-body{padding: 0 22px 0 0;}}@media (max-width: 425px){.cky-rtl .cky-accordion.cky-accordion-active .cky-accordion-body{padding: 0 15px 0 0;}}.cky-rtl .cky-opt-out-btn-wrapper .cky-btn{margin-right: 12px;}.cky-rtl .cky-opt-out-btn-wrapper .cky-btn:first-child{margin-right: 0;}.cky-rtl .cky-opt-out-checkbox-wrapper .cky-opt-out-checkbox-label{margin: 0 12px 0 0;}"
        };
        /* ]]> */
    </script>
    <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/cookie-law-info/lite/frontend/js/script.min.js?ver=3.3.5" id="cookie-law-info-js"></script>
    <script type="text/javascript" src="https://basketeer.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
    <script type="text/javascript" src="https://basketeer.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
    <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/miniorange-login-openid/includes/js/mo_openid_jquery.cookie.min.js?ver=6.8.3" id="js-cookie-script-js"></script>
    <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/miniorange-login-openid/includes/js/mo-openid-social_login.js?ver=6.8.3" id="mo-social-login-script-js"></script>
    <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/svg-support/vendor/DOMPurify/DOMPurify.min.js?ver=2.5.8" id="bodhi-dompurify-library-js"></script>
    <script type="text/javascript" id="woof-husky-js-extra">
        /* <![CDATA[ */
        var woof_husky_txt = {
            "ajax_url": "https:\/\/basketeer.com\/wp-admin\/admin-ajax.php",
            "plugin_uri": "https:\/\/basketeer.com\/wp-content\/plugins\/woocommerce-products-filter\/ext\/by_text\/",
            "loader": "https:\/\/eadn-wc04-9792563.nxedge.io\/wp-content\/plugins\/woocommerce-products-filter\/ext\/by_text\/assets\/img\/ajax-loader.gif",
            "not_found": "Nothing found!",
            "prev": "Prev",
            "next": "Next",
            "site_link": "https:\/\/basketeer.com",
            "default_data": {
                "placeholder": "Quick Search Product...",
                "behavior": "title_or_content_or_excerpt",
                "search_by_full_word": "0",
                "autocomplete": 1,
                "how_to_open_links": "0",
                "taxonomy_compatibility": "0",
                "sku_compatibility": "1",
                "custom_fields": "",
                "search_desc_variant": "0",
                "view_text_length": "10",
                "min_symbols": "3",
                "max_posts": "10",
                "image": "",
                "notes_for_customer": "",
                "template": "",
                "max_open_height": "300",
                "page": 0
            }
        };
        /* ]]> */
    </script>
    <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/by_text/assets/js/husky.js?ver=1.3.7.1" id="woof-husky-js"></script>
    <script type="text/javascript" id="print-invoices-packing-slip-labels-for-woocommerce_public-js-extra">
        /* <![CDATA[ */
        var wf_pklist_params_public = {
            "show_document_preview": "No",
            "document_access_type": "logged_in",
            "is_user_logged_in": "",
            "msgs": {
                "invoice_number_prompt_free_order": "\u2018Generate invoice for free orders\u2019 is disabled in Invoice settings > Advanced. You are attempting to generate invoice for this free order. Proceed?",
                "creditnote_number_prompt": "Refund in this order seems not having credit number yet. Do you want to manually generate one ?",
                "invoice_number_prompt_no_from_addr": "Please fill the `from address` in the plugin's general settings.",
                "invoice_title_prompt": "Invoice",
                "invoice_number_prompt": "number has not been generated yet. Do you want to manually generate one ?",
                "pop_dont_show_again": false,
                "request_error": "Request error.",
                "error_loading_data": "Error loading data.",
                "min_value_error": "minimum value should be",
                "generating_document_text": "Generating document...",
                "new_tab_open_error": "Failed to open new tab. Please check your browser settings."
            }
        };
        /* ]]> */
    </script>
    <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/print-invoices-packing-slip-labels-for-woocommerce/public/js/wf-woocommerce-packing-list-public.js?ver=4.8.4" id="print-invoices-packing-slip-labels-for-woocommerce_public-js"></script>
    <script type="text/javascript" id="bodhi_svg_inline-js-extra">
        /* <![CDATA[ */
        var svgSettings = {
            "skipNested": ""
        };
        /* ]]> */
    </script>
    <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/svg-support/js/min/svgs-inline-min.js" id="bodhi_svg_inline-js"></script>
    <script type="text/javascript" id="bodhi_svg_inline-js-after">
        /* <![CDATA[ */
        cssTarget = {
            "Bodhi": "img.style-svg",
            "ForceInlineSVG": "style-svg"
        };
        ForceInlineSVGActive = "false";
        frontSanitizationEnabled = "on";
        /* ]]> */
    </script>
    <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.7.0-wc.9.5.1" id="jquery-blockui-js" data-wp-strategy="defer"></script>
    <script type="text/javascript" id="wc-add-to-cart-js-extra">
        /* <![CDATA[ */
        var wc_add_to_cart_params = {
            "ajax_url": "\/wp-admin\/admin-ajax.php",
            "wc_ajax_url": "\/?wc-ajax=%%endpoint%%",
            "i18n_view_cart": "View cart",
            "cart_url": "https:\/\/basketeer.com\/cart\/",
            "is_cart": "",
            "cart_redirect_after_add": "no",
            "gt_translate_keys": ["i18n_view_cart", {
                "key": "cart_url",
                "format": "url"
            }]
        };
        /* ]]> */
    </script>
    <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=9.5.1" id="wc-add-to-cart-js" defer="defer" data-wp-strategy="defer"></script>
    <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4-wc.9.5.1" id="js-cookie-js" defer="defer" data-wp-strategy="defer"></script>
    <script type="text/javascript" id="woocommerce-js-extra">
        /* <![CDATA[ */
        var woocommerce_params = {
            "ajax_url": "\/wp-admin\/admin-ajax.php",
            "wc_ajax_url": "\/?wc-ajax=%%endpoint%%"
        };
        /* ]]> */
    </script>
    <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=9.5.1" id="woocommerce-js" defer="defer" data-wp-strategy="defer"></script>
    <script>
        window.wc_ga_pro = {};

        window.wc_ga_pro.ajax_url = 'https://basketeer.com/wp-admin/admin-ajax.php';

        window.wc_ga_pro.available_gateways = {
            "chaiport": "Credit Cards \/ Wallets \/ Bank Transfer \/ Mobile Banking \/ PayPal"
        };

        // interpolate json by replacing placeholders with variables
        window.wc_ga_pro.interpolate_json = function(object, variables) {

            if (!variables) {
                return object;
            }

            var j = JSON.stringify(object);

            for (var k in variables) {
                j = j.split('{$' + k + '}').join(variables[k]);
            }

            return JSON.parse(j);
        };

        // return the title for a payment gateway
        window.wc_ga_pro.get_payment_method_title = function(payment_method) {
            return window.wc_ga_pro.available_gateways[payment_method] || payment_method;
        };

        // check if an email is valid
        window.wc_ga_pro.is_valid_email = function(email) {
            return /[^\s@]+@[^\s@]+\.[^\s@]+/.test(email);
        };
    </script>
    <!-- Start WooCommerce Google Analytics Pro -->
    <script>
        (function(i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function() {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date();
            a = s.createElement(o),
                m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
        })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');
        ga('create', 'UA-196526788-1', {
            "cookieDomain": "auto"
        });
        ga('set', 'forceSSL', true);
        ga('set', 'anonymizeIp', true);
        ga('require', 'displayfeatures');
        ga('require', 'linkid');
        ga('require', 'ec');


        (function() {

            // trigger an event the old-fashioned way to avoid a jQuery dependency and still support IE
            var event = document.createEvent('Event');

            event.initEvent('wc_google_analytics_pro_loaded', true, true);

            document.dispatchEvent(event);
        })();
    </script>
    <!-- end WooCommerce Google Analytics Pro -->
    <link rel="https://api.w.org/" href="https://basketeer.com/wp-json/" />
    <link rel="alternate" title="JSON" type="application/json" href="https://basketeer.com/wp-json/wp/v2/pages/2266" />
    <link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://basketeer.com/xmlrpc.php?rsd" />

    <link rel='shortlink' href='https://basketeer.com/' />
    <link rel="alternate" title="oEmbed (JSON)" type="application/json+oembed" href="https://basketeer.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fbasketeer.com%2F" />
    <link rel="alternate" title="oEmbed (XML)" type="text/xml+oembed" href="https://basketeer.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fbasketeer.com%2F&#038;format=xml" />
    <style id="cky-style-inline">
        [data-cky-tag] {
            visibility: hidden;
        }
    </style>
    <!-- start Simple Custom CSS and JS -->
    <style type="text/css">
        .dgwt-wcas-search-wrapp {
            margin: 0 !important;
        }
    </style>
    <!-- end Simple Custom CSS and JS -->

    <!-- This website runs the Product Feed PRO for WooCommerce by AdTribes.io plugin - version woocommercesea_option_installed_version -->
    <meta name="ti-site-data" content="eyJyIjoiMToxMSE3OjM2ITMwOjE3MSIsIm8iOiJodHRwczpcL1wvYmFza2V0ZWVyLmNvbVwvd3AtYWRtaW5cL2FkbWluLWFqYXgucGhwP2FjdGlvbj10aV9vbmxpbmVfdXNlcnNfZ29vZ2xlJnA9JTJGIn0=" />
    <!-- Google Tag Manager for WordPress by gtm4wp.com -->
    <!-- GTM Container placement set to automatic -->
    <script data-cfasync="false" data-pagespeed-no-defer>
        var dataLayer_content = {
            "pagePostType": "frontpage",
            "pagePostType2": "single-page",
            "pagePostAuthor": "nash",
            "cartContent": {
                "totals": {
                    "applied_coupons": [],
                    "discount_total": 0,
                    "subtotal": 0,
                    "total": 0
                },
                "items": []
            }
        };
        dataLayer.push(dataLayer_content);
    </script>
    <script data-cfasync="false" data-pagespeed-no-defer>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                '//www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-MTK7BWQW');
    </script>
    <!-- End Google Tag Manager for WordPress by gtm4wp.com -->
    <style>
        .dgwt-wcas-ico-magnifier,
        .dgwt-wcas-ico-magnifier-handler {
            max-width: 20px
        }

        .dgwt-wcas-search-wrapp {
            max-width: 400px
        }

        .dgwt-wcas-search-wrapp .dgwt-wcas-sf-wrapp .dgwt-wcas-search-submit::before {}

        .dgwt-wcas-search-wrapp .dgwt-wcas-sf-wrapp .dgwt-wcas-search-submit:hover::before,
        .dgwt-wcas-search-wrapp .dgwt-wcas-sf-wrapp .dgwt-wcas-search-submit:focus::before {}

        .dgwt-wcas-search-wrapp .dgwt-wcas-sf-wrapp .dgwt-wcas-search-submit,
        .dgwt-wcas-om-bar .dgwt-wcas-om-return {
            color: #0a0a0a
        }

        .dgwt-wcas-search-wrapp .dgwt-wcas-ico-magnifier,
        .dgwt-wcas-search-wrapp .dgwt-wcas-sf-wrapp .dgwt-wcas-search-submit svg path,
        .dgwt-wcas-om-bar .dgwt-wcas-om-return svg path {
            fill: #0a0a0a
        }

        .dgwt-wcas-search-icon {
            color: #5e5e5e
        }

        .dgwt-wcas-search-icon path {
            fill: #5e5e5e
        }
    </style>
    <style>
        /* Custom Header Style (ACF) */

        .topBar,
        .topBarMobile,
        .features {
            background-color: #C09A5C !important;
        }

        .mainHeaderbarRight a img {
            content: url('https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/08/Full-Logo.svg');
            width: revert-layer;
        }
    </style>
    <noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
    <style class='wp-fonts-local' type='text/css'>
        @font-face {
            font-family: Inter;
            font-style: normal;
            font-weight: 300 900;
            font-display: fallback;
            src: url('https://basketeer.com/wp-content/plugins/woocommerce/assets/fonts/Inter-VariableFont_slnt,wght.woff2') format('woff2');
            font-stretch: normal;
        }

        @font-face {
            font-family: Cardo;
            font-style: normal;
            font-weight: 400;
            font-display: fallback;
            src: url('https://basketeer.com/wp-content/plugins/woocommerce/assets/fonts/cardo_normal_400.woff2') format('woff2');
        }
    </style>
    <link rel="icon" href="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/05094703/cropped-site_icon_bkt-32x32.png" sizes="32x32" />
    <link rel="icon" href="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/05094703/cropped-site_icon_bkt-192x192.png" sizes="192x192" />
    <link rel="apple-touch-icon" href="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/05094703/cropped-site_icon_bkt-180x180.png" />
    <meta name="msapplication-TileImage" content="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/05094703/cropped-site_icon_bkt-270x270.png" />
    <style type="text/css" id="wp-custom-css">
        .wc_payment_methods.payment_methods.methods li label img:nth-of-type(2) {
            display: none;
        }

        .preloader {
            display: none !important;
        }
    </style>
    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "WebPage",
            "name": "Gift Hampers, Baskets &amp; Flowers | Gift Delivery Across Thailand",
            "url": "https://basketeer.com/"
        }
    </script>
    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "Organization",
            "name": "Basketeer",
            "url": "https://basketeer.com/",
            "logo": {
                "@type": "ImageObject",
                "url": "https://eadn-wc04-9792563.nxedge.io/wp-content/uploads/2025/08/basketeer-logo.png"
            },
            "sameAs": ["https://www.facebook.com/BasketeerThailand", "https://www.instagram.com/basketeer_thailand/"],
            "contactPoint": [{
                "@type": "ContactPoint",
                "telephone": "+66-2-026-3626",
                "contactType": "customer support",
                "areaServed": "TH",
                "availableLanguage": ["en", "th"]
            }]
        }
    </script>
    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "Organization",
            "name": "Basketeer",
            "url": "https://basketeer.com/",
            "logo": {
                "@type": "ImageObject",
                "url": "https://eadn-wc04-9792563.nxedge.io/wp-content/uploads/2025/08/basketeer-logo.png"
            },
            "sameAs": ["https://www.facebook.com/BasketeerThailand", "https://www.instagram.com/basketeer_thailand/"],
            "contactPoint": [{
                "@type": "ContactPoint",
                "telephone": "+66-2-026-3626",
                "contactType": "customer support",
                "areaServed": "TH",
                "availableLanguage": ["en", "th"]
            }]
        }
    </script>
    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "WebSite",
            "url": "https://basketeer.com/",
            "name": "Basketeer – The Art of Giving",
            "potentialAction": {
                "@type": "SearchAction",
                "target": "https://basketeer.com/?s={search_term_string}",
                "query-input": "required name=search_term_string"
            }
        }
    </script>
    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "LocalBusiness",
            "name": "Basketeer",
            "url": "https://basketeer.com/",
            "image": "https://eadn-wc04-9792563.nxedge.io/wp-content/uploads/2025/08/basketeer-logo.png",
            "logo": "https://eadn-wc04-9792563.nxedge.io/wp-content/uploads/2025/08/basketeer-logo.png",
            "address": {
                "@type": "PostalAddress",
                "addressLocality": "Bangkok",
                "addressCountry": "TH"
            },
            "areaServed": "Bangkok Metropolitan Region",
            "telephone": "+66-2-026-3626",
            "openingHours": "Mo-Su 08:00-20:00",
            "sameAs": ["https://www.facebook.com/BasketeerThailand", "https://www.instagram.com/basketeer_thailand/"]
        }
    </script>
    <!-- Cookie Consent by https://www.cookiewow.com -->
    <!--<script type="text/javascript" src="https://cookiecdn.com/cwc.js"></script> <script id="cookieWow" type="text/javascript" src="https://cookiecdn.com/configs/WCsG8kPk9mchgyxdGDxAcpgw" data-cwcid="WCsG8kPk9mchgyxdGDxAcpgw"></script>-->
</head>

<body class="home wp-singular page-template page-template-home-layout-2 page-template-home-layout-2-php page page-id-2266 wp-theme-baskettheme theme-baskettheme woocommerce-no-js woo-variation-swatches wvs-behavior-blur wvs-theme-baskettheme wvs-mobile wvs-show-label wvs-tooltip">
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MTK7BWQW"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->
    <!-- Preloader -->
    <div class="preloader">
        <div class="container-fluid">
            <div class="spinner">
                <span class="ball-1"></span>
                <span class="ball-2"></span>
                <span class="ball-3"></span>
                <span class="ball-4"></span>
            </div>
        </div>
    </div>
    <header>


        <section class="topBar d-none d-md-block d-lg-block d-xl-block" style="background:#C09A5C">
            <div class="container-fluid">
                <div class="topBarInfo">
                    <div class=" d-flex flex-nowrap justify-content-between align-items-center">
                        <div class="topBarInfoRight col-6 d-flex align-items-centerter px-0">
                            <div class="mailtop d-flex align-items-center">
                                <img width="16" height="16" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/phoneCall.svg" alt="phoneCall">
                                <a class="text-muted" href="tel:02-821-5042">02-821-5042</a>
                            </div>
                            <div class="phoneTop d-flex align-items-center">
                                <img width="18" height="18" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/12/11165013/lineicondan-01.png" alt="Line">
                                <a class="text-muted" href="https://lin.ee/nWMNxvK" target="_blank">Line @basketeer</a>
                            </div>
                        </div>
                        <div class="topBarInfoLeft col-6 d-flex justify-content-end align-items-center px-0">
                            <!-- <a class="text-muted" href="#" style="font-weight:400;font-size: 12px;">
                            Our Service
                        </a> -->
                            <div class="btn-group dropdown d-fex align-items-center">
                                <a class="text-muted" data-bs-reference="parent" data-bs-toggle="dropdown" aria-expanded="false" style="font-weight:400;font-size: 12px;">
                                Our Services
                                <svg viewBox="0 0 6 5" stroke-width="1" stroke="white" fill="none" height="5" width="6" class="dropdownIcon dropdown-toggle" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M0.5 1L3 3.5L5.5 1" stroke="white"></path>
                                </svg>
                            </a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="/gift-design-service/">Gift Design Services</a></li>
                                </ul>
                            </div>
                            <div class="btn-group dropdown d-fex align-items-center">
                                <a class="text-muted" data-bs-reference="parent" aria-expanded="false" style="font-weight:400;font-size: 12px;" data-bs-toggle="dropdown">Customer Services
                                <svg viewBox="0 0 6 5" stroke-width="1" stroke="white" fill="none" height="5" width="6" class="dropdownIcon dropdown-toggle" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M0.5 1L3 3.5L5.5 1" stroke="white"></path>
                                </svg>
                            </a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="/promotions/">Promotions</a></li>
                                    <li><a class="dropdown-item" href="/how-to-pay/">How to Pay</a></li>
                                    <li><a class="dropdown-item" href="/how-to-order/">How to Order</a></li>
                                    <li><a class="dropdown-item" href="/payment-notification/">Notify the payment</a></li>
                                    <li><a class="dropdown-item" href="/delivery-service/">Delivery Services</a></li>
                                    <li><a class="dropdown-item" href="/track-your-order/">Track Your Order</a></li>
                                    <li><a class="dropdown-item" href="/faqs/">FAQs</a></li>
                                </ul>
                            </div>
                            <div class="languageTop d-none d-xl-flex align-item-center">
                                <div class="gtranslate_wrapper" id="gt-wrapper-34366255"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="topBarMobile d-md-none d-lg-none d-xl-none" style="background:#C09A5C">
            <div class="container-fluid">
                <div class="topBarInfo">
                    <div class="d-flex flex-nowrap justify-content-around align-items-center">
                        <div class="topBarInfoRight d-flex align-items-centerter px-0">
                            <div class="mailtop d-flex align-item-center">
                                <img width="16" height="16" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/phoneCall.svg" alt="phoneCall">
                                <a class="text-muted" href="tel:02-821-5042">02-821-5042</a>
                            </div>
                            <div class="phoneTop d-flex align-item-center">
                                <img width="18" height="18" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/12/11165013/lineicondan-01.png" alt="Line">
                                <a class="text-muted" href="https://lin.ee/nWMNxvK" target="_blank">Line @basketeer</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="offcanvasNavbar d-xl-none">
            <nav class="navbar navbar-light" aria-label="Light offcanvas navbar">
                <div class="container-fluid">
                    <div class="mainHeaderbarMobile col-3 d-flex justify-content-start align-items-center text-start">
                        <div class="" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbarLight" aria-controls="offcanvasNavbarLight">
                            <span class="navbar-toggler-icon"></span>
                        </div>
                        <div class="dgwt-wcas-search-wrapp dgwt-wcas-has-submit woocommerce dgwt-wcas-style-pirx-compact dgwt-wcas-style-pirx js-dgwt-wcas-layout-icon-flexible dgwt-wcas-layout-icon-flexible js-dgwt-wcas-mobile-overlay-enabled">
                            <svg class="dgwt-wcas-loader-circular dgwt-wcas-icon-preloader" viewBox="25 25 50 50">
					<circle class="dgwt-wcas-loader-circular-path" cx="50" cy="50" r="20" fill="none"
						 stroke-miterlimit="10"/>
				</svg>
                            <a href="#" class="dgwt-wcas-search-icon js-dgwt-wcas-search-icon-handler" aria-label="Open search bar">				<svg class="dgwt-wcas-ico-magnifier-handler" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18">
					<path  d=" M 16.722523,17.901412 C 16.572585,17.825208 15.36088,16.670476 14.029846,15.33534 L 11.609782,12.907819 11.01926,13.29667 C 8.7613237,14.783493 5.6172703,14.768302 3.332423,13.259528 -0.07366363,11.010358 -1.0146502,6.5989684 1.1898146,3.2148776
						  1.5505179,2.6611594 2.4056498,1.7447266 2.9644271,1.3130497 3.4423015,0.94387379 4.3921825,0.48568469 5.1732652,0.2475835 5.886299,0.03022609 6.1341883,0 7.2037391,0 8.2732897,0 8.521179,0.03022609 9.234213,0.2475835 c 0.781083,0.23810119 1.730962,0.69629029 2.208837,1.0654662
						  0.532501,0.4113763 1.39922,1.3400096 1.760153,1.8858877 1.520655,2.2998531 1.599025,5.3023778 0.199549,7.6451086 -0.208076,0.348322 -0.393306,0.668209 -0.411622,0.710863 -0.01831,0.04265 1.065556,1.18264 2.408603,2.533307 1.343046,1.350666 2.486621,2.574792 2.541278,2.720279 0.282475,0.7519
						  -0.503089,1.456506 -1.218488,1.092917 z M 8.4027892,12.475062 C 9.434946,12.25579 10.131043,11.855461 10.99416,10.984753 11.554519,10.419467 11.842507,10.042366 12.062078,9.5863882 12.794223,8.0659672 12.793657,6.2652398 12.060578,4.756293 11.680383,3.9737304 10.453587,2.7178427
						  9.730569,2.3710306 8.6921295,1.8729196 8.3992147,1.807606 7.2037567,1.807606 6.0082984,1.807606 5.7153841,1.87292 4.6769446,2.3710306 3.9539263,2.7178427 2.7271301,3.9737304 2.3469352,4.756293 1.6138384,6.2652398 1.6132726,8.0659672 2.3454252,9.5863882 c 0.4167354,0.8654208 1.5978784,2.0575608
						  2.4443766,2.4671358 1.0971012,0.530827 2.3890403,0.681561 3.6130134,0.421538 z
					"/>
				</svg>
				</a>
                            <div class="dgwt-wcas-search-icon-arrow"></div>
                            <form class="dgwt-wcas-search-form" role="search" action="https://basketeer.com/" method="get">
                                <div class="dgwt-wcas-sf-wrapp">
                                    <label class="screen-reader-text" for="dgwt-wcas-search-input-1">Products search</label>

                                    <input id="dgwt-wcas-search-input-1" type="search" class="dgwt-wcas-search-input" name="s" value="" placeholder="Search..." autocomplete="off" />
                                    <div class="dgwt-wcas-preloader"></div>

                                    <div class="dgwt-wcas-voice-search"></div>

                                    <button type="submit" aria-label="Search" class="dgwt-wcas-search-submit">				<svg class="dgwt-wcas-ico-magnifier" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18">
					<path  d=" M 16.722523,17.901412 C 16.572585,17.825208 15.36088,16.670476 14.029846,15.33534 L 11.609782,12.907819 11.01926,13.29667 C 8.7613237,14.783493 5.6172703,14.768302 3.332423,13.259528 -0.07366363,11.010358 -1.0146502,6.5989684 1.1898146,3.2148776
						  1.5505179,2.6611594 2.4056498,1.7447266 2.9644271,1.3130497 3.4423015,0.94387379 4.3921825,0.48568469 5.1732652,0.2475835 5.886299,0.03022609 6.1341883,0 7.2037391,0 8.2732897,0 8.521179,0.03022609 9.234213,0.2475835 c 0.781083,0.23810119 1.730962,0.69629029 2.208837,1.0654662
						  0.532501,0.4113763 1.39922,1.3400096 1.760153,1.8858877 1.520655,2.2998531 1.599025,5.3023778 0.199549,7.6451086 -0.208076,0.348322 -0.393306,0.668209 -0.411622,0.710863 -0.01831,0.04265 1.065556,1.18264 2.408603,2.533307 1.343046,1.350666 2.486621,2.574792 2.541278,2.720279 0.282475,0.7519
						  -0.503089,1.456506 -1.218488,1.092917 z M 8.4027892,12.475062 C 9.434946,12.25579 10.131043,11.855461 10.99416,10.984753 11.554519,10.419467 11.842507,10.042366 12.062078,9.5863882 12.794223,8.0659672 12.793657,6.2652398 12.060578,4.756293 11.680383,3.9737304 10.453587,2.7178427
						  9.730569,2.3710306 8.6921295,1.8729196 8.3992147,1.807606 7.2037567,1.807606 6.0082984,1.807606 5.7153841,1.87292 4.6769446,2.3710306 3.9539263,2.7178427 2.7271301,3.9737304 2.3469352,4.756293 1.6138384,6.2652398 1.6132726,8.0659672 2.3454252,9.5863882 c 0.4167354,0.8654208 1.5978784,2.0575608
						  2.4443766,2.4671358 1.0971012,0.530827 2.3890403,0.681561 3.6130134,0.421538 z
					"/>
				</svg>
				</button>

                                    <input type="hidden" name="post_type" value="product" />
                                    <input type="hidden" name="dgwt_wcas" value="1" />


                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="offcanvas offcanvas-start mobileMenu" tabindex="-1" id="offcanvasNavbarLight" aria-labelledby="offcanvasNavbarLightLabel">
                        <div class="offcanvas-header">
                            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                            <div>
                                <div class="profileBar">
                                    <img width="21px" height="21px" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/user-mobile-icon.svg" alt="user-mobile">

                                    <a class="text " href="https://basketeer.com/login">Login</a> / <a class="text " href="https://basketeer.com/register">Register</a>

                                </div>
                                <a href="https://basketeer.com/my-account/wishlists/" class="wishList">
                                <img width="22px" height="19px" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/wishlist-mobile-icon.svg" alt="wishlist">
                                <span id="wishlist-count" class="wishlist-count"></span>
                            </a>
                            </div>
                        </div>
                        <div class="offcanvas-body">
                            <!-- Tabs navs -->
                            <ul class="nav nav-tabs nav-fill" id="ex1" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link active" id="ex2-tab-1" data-bs-toggle="tab" href="#ex2-tabs-1" role="tab" aria-controls="ex2-tabs-1" aria-selected="true">Categories</a>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link" id="ex2-tab-2" data-bs-toggle="tab" href="#ex2-tabs-2" role="tab" aria-controls="ex2-tabs-2" aria-selected="false">Services</a>
                                </li>
                            </ul>
                            <!-- Tabs navs -->

                            <!-- Tabs content -->
                            <div class="tab-content" id="ex2-content">
                                <div class="tab-pane fade show active" id="ex2-tabs-1" role="tabpanel" aria-labelledby="ex2-tab-1">

                                    <div class="accordion" id="myAccordion">
                                        <div class="accordion-item ">
                                            <h2 class="accordion-header" id="headingOne">
                                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                                Gifts & Promos
                                            </button>
                                            </h2>
                                            <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#myAccordion">
                                                <div class="accordion-body">
                                                    <div>
                                                        <div class="subNavTitle">Favorite Gifts</div>
                                                        <div class="subNavItems">
                                                            <a href="https://basketeer.com/product-category/gift-baskets/thai-new-year-songkran/">Songkran Collection</a>
                                                            <a href="https://basketeer.com/product-category/fruit-baskets/thai-tropical-fruits/">Summer Collection</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/gift-for-her/">Gifts for Her</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/gift-for-him/">Gifts for Him</a>
                                                        </div>

                                                        <div class="subNavTitle">Special Occasions</div>
                                                        <div class="subNavItems">
                                                            <a href="https://basketeer.com/product-category/gift-baskets/birthday-gifts/">Birthday Gifts</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/birthday-cakes/">Birthday Cakes</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/surprise-gifts/">Surprise Gifts</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/get-well-soon-gift-baskets/">Get Well Soon</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/all-bouquet-flowers/">Flower Bouquets</a>
                                                        </div>
                                                        <div class="subNavTitle">
                                                            <img src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/06173455/discount-coupon-voucher-shopping-ticket-promo-code-gift-card-be3a63.svg" alt="Promotions Icon" style="width: 16px; height: 14px; margin-right: 6px; vertical-align: middle;">                                                            Promotions
                                                        </div>
                                                        <div class="subNavItems">
                                                            <a href="https://basketeer.com/promotions/">View All Promotions</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item ">
                                            <h2 class="accordion-header" id="headingTwo">
                                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                                Gift Baskets
                                            </button>
                                            </h2>
                                            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#myAccordion">
                                                <div class="accordion-body">
                                                    <div>
                                                        <div class="subNavTitle" style="margin-bottom: 20px;"><a href="https://basketeer.com/product-category/gift-baskets/">View All Gift Baskets</a></div>
                                                        <div class="subNavTitle">Shop By Collections</div>

                                                        <div class="subNavItems">
                                                            <a href="https://basketeer.com/product-category/gift-baskets/gift-basket-best-sellers/">Best Sellers</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/luxury-collection/">Luxury Collection</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/food-beverage/">Food & Beverage</a>
                                                            <a href="https://basketeer.com/product-category/wine-gifts/" rel="nofollow" style="display:flex;align-items:center;gap:4px;">Celebratory Drinks<span style="font-size:11px;color:#a0a0a0;">Log in required</span></a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/picnic-hampers/">Picnic Hampers</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/health-wellness/">Health & Wellness</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/gift-bag-collection/">Gift Bags</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/gift-box-collection/">Gift Boxes</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/gift-for-him/">Gifts for Him</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/gift-for-her/">Gifts for Her</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/gifts-for-kids/">Gifts for Kids</a>

                                                        </div>

                                                        <div class="subNavTitle">Shop By Occasions</div>
                                                        <div class="subNavItems">
                                                            <a href="https://basketeer.com/product-category/gift-baskets/birthday-gifts/">Birthday Gifts</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/surprise-gifts/">Surprise Gifts</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/congratulations/">Congratulations</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/thank-you/">Thank you</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/get-well-soon-gift-baskets/">Get Well Soon</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/new-borns/">New Borns</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/anniversary-gifts/">Anniversary Gifts</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/christmas/">Christmas & New Year</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/chinese-new-year/">Chinese New Year</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/valentiness-day/">Valentine's Day</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/mothers-day-gift-baskets/">Mother's Day</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/st-patricks-day/">St. Patricks Day</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/new-home-gifts/">New Home Gifts</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/the-moon-festival/">The Moon Festival</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/thai-new-year-songkran/">Thai New Year - Songkran</a>
                                                        </div>
                                                        <div class="subNavTitle">Shop By Product</div>
                                                        <div class="subNavItems">
                                                            <!-- <a href="https://basketeer.com/product-category/gift-baskets/celebratory-drinks-gift-baskets/" rel="nofollow">Celebratory Drinks Basket</a> -->
                                                            <a href="https://basketeer.com/product-category/gift-baskets/doitung-doikham-gift-baskets/">Doitung & Doikham Gift Baskets</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/birdnests-gift-baskets/">Birdnests Gift Baskets</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/spa-aroma-products/">Spa & Aroma Products</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/cheese-gift-baskets/">Cheese Gift Baskets</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/dired-fruits-nuts-baskets/">Dired Fruits & Nuts Baskets</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/chocolates-sweets-baskets/">Chocolates & Sweets Baskets</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/tea-coffee-collection/">Tea & Coffee Collection</a>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item ">
                                            <h2 class="accordion-header" id="headingThree">
                                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseTwo">
                                                Fruit Baskets
                                            </button>
                                            </h2>
                                            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#myAccordion">
                                                <div class="accordion-body">
                                                    <div>
                                                        <div class="subNavTitle" style="margin-bottom: 20px;"><a href="https://basketeer.com/product-category/fruit-baskets/">View All Fruit Baskets</a></div>

                                                        <div class="subNavTitle">Shop By Design</div>
                                                        <div class="subNavItems">
                                                            <a href="https://basketeer.com/product-category/fruit-baskets/best-sellers/">Best Sellers</a>
                                                            <a href="https://basketeer.com/product-category/fruit-baskets/classic-fruit-baskets/">Classic Fruit Baskets</a>
                                                            <a href="https://basketeer.com/product-category/fruit-baskets/luxury-premium-fruits/">Luxury & Premium Fruits </a>
                                                            <a href="https://basketeer.com/product-category/fruit-baskets/fruit-flowers/">Fruit & Flowers </a>
                                                            <a href="https://basketeer.com/product-category/fruit-baskets/get-well-soon-fruit-baskets/">Get Well Soon Fruits</a>
                                                            <a href="https://basketeer.com/product-category/fruit-baskets/the-fruit-box-fruit-baskets/">The Fruit Box</a>
                                                            <a href="https://basketeer.com/product-category/fruit-baskets/heart-shaped-fruit-boxes/">Heart Shaped Fruit Boxes</a>
                                                            <a href="https://basketeer.com/product-category/fruit-baskets/birthday-fruits/">Birthday Fruits</a>
                                                            <a href="https://basketeer.com/product-category/fruit-baskets/fruit-for-mom/">Fruits for Mum</a>
                                                            <a href="https://basketeer.com/product-category/fruit-baskets/thank-you-fruits/">Thank You Fruits</a>
                                                            <a href="https://basketeer.com/product-category/fruit-baskets/congratulation-fruits/">Congratulations Fruits</a>
                                                        </div>
                                                        <div class="subNavTitle">Shop By Fruit Type</div>
                                                        <div class="subNavItems">
                                                            <a href="https://basketeer.com/product-category/fruit-baskets/oranges/">Oranges</a>
                                                            <a href="https://basketeer.com/product-category/fruit-baskets/apples/">Apples</a>
                                                            <a href="https://basketeer.com/product-category/fruit-baskets/berries-fruits/">Berries</a>
                                                            <a href="https://basketeer.com/product-category/fruit-baskets/grapes/">Grapes</a>
                                                            <a href="https://basketeer.com/product-category/fruit-baskets/thai-tropical-fruits/">Thai Summer Fruit Baskets</a>
                                                        </div>
                                                        <div class="subNavTitle">Shop By Mixed Set</div>
                                                        <div class="subNavItems">
                                                            <a href="https://basketeer.com/product-category/fruit-baskets/fruits-with-cheeses/">Fruits with Cheeses</a>
                                                            <a href="https://basketeer.com/product-category/fruit-baskets/fruits-with-healthy-products/">Fruits with Healthy Products</a>
                                                            <a href="https://basketeer.com/product-category/fruit-baskets/fruits-with-birdsnests/">Fruits with Birdsnests</a>
                                                            <a href="https://basketeer.com/product-category/fruit-baskets/fruits-with-premium-products/">Fruits with Premium Products </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item ">
                                            <h2 class="accordion-header" id="headingNine">
                                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
                                                Combo Gifts
                                            </button>
                                            </h2>
                                            <div id="collapseNine" class="accordion-collapse collapse" aria-labelledby="headingNine" data-bs-parent="#myAccordion">
                                                <div class="accordion-body">
                                                    <div>

                                                        <div class="subNavTitle" style="margin-bottom: 20px;"><a href="https://basketeer.com/product-category/combo-gifts/">View All Combo Gifts</a></div>


                                                        <div class="subNavTitle">Birthday Combos</div>
                                                        <div class="subNavItems">
                                                            <a href="https://basketeer.com/product-category/combo-gifts/best-sellers-birthday-combos/">Best Sellers</a>
                                                            <!--  <a href="https://basketeer.com/product-category/combo-gifts/cakes-with-celebratory-drinks/" rel="nofollow">Cakes with Celebratory Drinks</a> -->
                                                            <a href="https://basketeer.com/product-category/combo-gifts/cake-with-flower-balloons/">Cakes with Flowers & Balloons</a>
                                                            <a href="https://basketeer.com/product-category/combo-gifts/cakes-with-flowers/">Cakes with Flowers</a>
                                                            <a href="https://basketeer.com/product-category/combo-gifts/cake-with-balloons/">Cakes with Balloons</a>
                                                            <a href="https://basketeer.com/product-category/combo-gifts/cake-with-soft-toys/">Cake with Soft Toys</a>
                                                        </div>
                                                        <div class="subNavTitle">Congratulations Combo</div>
                                                        <div class="subNavItems">
                                                            <a href="https://basketeer.com/product-category/combo-gifts/flowers-with-balloons/">Flowers with Balloons</a>
                                                            <a href="https://basketeer.com/product-category/combo-gifts/flowers-with-soft-toys/">Flowers with Soft Toys</a>
                                                            <a href="https://basketeer.com/product-category/combo-gifts/flowers-with-balloons-soft-toys/">Flowers with Balloons & Soft toys</a>
                                                            <a href="https://basketeer.com/product-category/combo-gifts/balloons-with-chocolates/">Balloons with Chocolates</a>
                                                            <a href="https://basketeer.com/product-category/combo-gifts/balloon-with-soft-toys/">Balloons with Soft Toys</a>
                                                            <!-- <a href="https://basketeer.com/product-category/combo-gifts/flowers-with-celebratory-drinks/" rel="nofollow">Flowers with Combo Drinks</a> -->
                                                            <!-- <a href="https://basketeer.com/product-category/combo-gifts/flowers-with-celebratory-drinks-balloons/" rel="nofollow">Flowers with Combo Drinks & Balloons</a> -->
                                                            <!-- <a href="https://basketeer.com/product-category/combo-gifts/celebratory-drinks-with-flowers-congrat-flowers/" rel="nofollow">Combo Drinks with Flowers</a> -->
                                                            <!-- <a href="https://basketeer.com/product-category/combo-gifts/celebratory-drinks-with-chocolates-balloons/" rel="nofollow">Combo Drinks with Chocolates & Balloons</a> -->
                                                            <!-- <a href="https://basketeer.com/product-category/combo-gifts/celebratory-drinks-with-chocolates/" rel="nofollow">Combo Drinks with Chocolates</a> -->
                                                            <!-- <a href="https://basketeer.com/product-category/combo-gifts/celebratory-drinks-with-flower-chocolates/" rel="nofollow">Combo Drinks with Flowers & Chocolates</a> -->
                                                            <!-- <a href="https://basketeer.com/product-category/combo-gifts/celebratory-drinks-with-orchid-plants/" rel="nofollow">Combo Drinks with Orchid Plants</a> -->
                                                            <!-- <a href="https://basketeer.com/product-category/combo-gifts/celebratory-drinks-with-balloons/" rel="nofollow">Combo Drinks with Balloons</a> -->
                                                        </div>

                                                        <div class="subNavTitle">Get Well Soon Combo</div>
                                                        <div class="subNavItems">
                                                            <a href="https://basketeer.com/product-category/combo-gifts/fruit-baskets-with-flowers/">Fruit Baskets with Flowers</a>
                                                            <a href="https://basketeer.com/product-category/combo-gifts/fruit-baskets-with-balloons/">Fruit Baskets with Balloons</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Commenting out the Celebratory Drinks section -->
                                        <!-- End of commented section -->
                                        <div class="accordion-item ">
                                            <h2 class="accordion-header" id="headingFive">
                                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseTwo">
                                                Charlotte Bakery
                                            </button>
                                            </h2>
                                            <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#myAccordion">
                                                <div class="accordion-body">
                                                    <div>
                                                        <div class="subNavTitle" style="margin-bottom: 20px;"><a href="https://basketeer.com/product-category/bakery-gifts/">View All Charlotte Bakery</a></div>
                                                        <div class="subNavTitle">Shop by Bakery Type</div>
                                                        <div class="subNavItems">
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/best-sellers-bakery-gifts/">Best Sellers</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/signature-bakery/">Singature Cakes</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/same-day-cakes/">Same Day Cakes</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/custom-cakes/">Custom Cakes</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/classic-cakes/">Classic Cakes</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/layer-cakes/">Layer Cakes</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/2-tier-cakes/">2 Tier Cakes</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/letter-cakes/">Letter Cakes</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/mini-cake-bakery-gifts/">Mini Cakes</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/cupcake-bakery-gifts/">Cupcakes</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/pies-tarts/">Pies & Tarts</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/chocolate-truffles/">Truffles & Praline</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/brownies-cookies/">Brownies & Cookies</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/macarons/">Macarons</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/chocolate-covered-strawberries/">Choco Covered Strawberries</a>
                                                        </div>
                                                        <div class="subNavTitle">Shop By Occasion</div>
                                                        <div class="subNavItems">
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/summer-bakery/">Summer Bakery</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/birthday-cakes/">Birthday Cakes</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/birthday-bakery/">Birthday Bakery</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/christmas-bakery/">Christmas Bakery</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/halloween-bakery/">Halloween Bakery</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/mothers-day-bakery-gifts/">Mother's Day</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/valentines-day-bakery-gifts/">Valentine's Day</a>
                                                        </div>
                                                        <div class="subNavTitle">Shop By Recipient</div>
                                                        <div class="subNavItems">
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/shop-for-men/">Shop for Men</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/shop-for-women/">Shop for Women</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/shop-for-kids/">Shop for Kids</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/shop-for-friends/">Shop for Friends</a>
                                                        </div>
                                                        <div class="subNavTitle">Shop by Bakery Flavors</div>
                                                        <div class="subNavItems">
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/cheese-cakes/">Cheese Cakes</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/chocolate-flavors/">Chocolate Flavors</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/vanilla-flavors/">Vanilla Flavors</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/strawberry-flavors/">Strawberry Flavors</a>
                                                            <a href="https://basketeer.com/product-category/bakery-gifts/fruity-flavors/">Fruity Flavors</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item ">
                                            <h2 class="accordion-header" id="headingSix">
                                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseTwo">
                                                Flowers by Basketeer
                                            </button>
                                            </h2>
                                            <div id="collapseSix" class="accordion-collapse collapse" aria-labelledby="headingSix" data-bs-parent="#myAccordion">
                                                <div class="accordion-body">
                                                    <div>

                                                        <div class="subNavTitle" style="margin-bottom: 20px;"><a href="https://basketeer.com/product-category/flower-gifts/">All Flowers by Basketeer</a></div>

                                                        <div class="subNavTitle">Shop by Occasions</div>
                                                        <div class="subNavItems">
                                                            <a href="https://basketeer.com/product-category/flower-gifts/best-seller/">Best Sellers</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/congratulations-flowers/">Congratulations Flowers</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/birthday-flowers/">Birthday Flowers</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/romantic-flowers-for-her/">Romantic Flowers for Her</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/flowers-for-him/">Flowers for Him</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/get-well-soon-flower-gifts/">Get Well Soon Flowers</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/flower-for-funeral/">Flowers for Funerals</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/graduation-flowers/">Graduation Flowers</a>
                                                            <a href="https://basketeer.com/product-category/gift-baskets/valentines-day/">Valentine's Day</a>
                                                            <!-- Fix Link Here -->
                                                        </div>
                                                        <div class="subNavTitle">Shop by Design Type</div>

                                                        <div class="subNavItems">
                                                            <a href="https://basketeer.com/product-category/flower-gifts/mini-bouquets/">Small Bouquets</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/all-bouquet-flowers/">All Premuim Bouquets</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/flowers-in-vases/">Flowers in Vases</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/flowers-in-baskets/">Flowers in Baskets</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/flowers-in-boxes/">Flowers in Boxes</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/mini-flowers-in-vases/">Mini Flowers in Vases</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/luxury-flowers/">Luxury Flowers</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/luxury-british-designs/">Luxury British Designs</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/plant-gifts/">Plant Gifts</a>
                                                        </div>
                                                        <div class="subNavTitle">Dried & Artificial Flowers</div>
                                                        <div class="subNavItems">
                                                            <a href="https://basketeer.com/product-category/flower-gifts/all-artificial-flowers/">View All Artificial</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/potted-orchids/">Potted Orchids</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/artificial-flower-vases/">Artificial Flower Vases</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/dried-and-preserved-flowers/">Dried & Preserved Flowers</a>
                                                        </div>
                                                        <div class="subNavTitle">Shop by Recipeints</div>
                                                        <div class="subNavItems">
                                                            <a href="https://basketeer.com/product-category/flower-gifts/flowers-for-women/">Flowers for Women</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/flowers-for-men/">Flowers for Men</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/flowers-for-mum/">Flowers For Mum </a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/flowers-for-friends/">Flowers for Friends</a>
                                                        </div>

                                                        <div class="subNavTitle">Shop by Flower Type</div>
                                                        <div class="subNavItems">
                                                            <a href="https://basketeer.com/product-category/flower-gifts/roses/">Roses</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/lillys/">Lillys</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/sunflowers/">Sunflowers</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/hydrangeas/">Hydrangeas</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/orchids/">Orchids</a>
                                                            <a href="https://basketeer.com/product-category/flower-gifts/tulips/">Tulips</a>
                                                        </div>


                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item ">
                                            <h2 class="accordion-header" id="headingSeven">
                                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSeven" aria-expanded="false" aria-controls="collapseTwo">
                                                Balloon Gifts
                                            </button>
                                            </h2>
                                            <div id="collapseSeven" class="accordion-collapse collapse" aria-labelledby="headingSeven" data-bs-parent="#myAccordion">
                                                <div class="accordion-body">
                                                    <div>
                                                        <div class="subNavTitle" style="margin-bottom: 20px;"><a href="https://basketeer.com/product-category/balloon-gifts/">View All Balloon Gifts</a></div>

                                                        <div class="subNavTitle">Shop by Design</div>
                                                        <div class="subNavItems">
                                                            <a href="https://basketeer.com/product-category/balloon-gifts/best-selling-balloons/">Best Selling Balloons</a>
                                                            <a href="https://basketeer.com/product-category/balloon-gifts/single-balloons/">Single Balloons</a>
                                                            <a href="https://basketeer.com/product-category/balloon-gifts/set-of-balloons/">Set of Balloons</a>
                                                            <a href="https://basketeer.com/product-category/balloon-gifts/balloons-for-lovers/">Balloons for lovers</a>
                                                            <a href="https://basketeer.com/product-category/balloon-gifts/balloons-for-him/">Balloons for Him</a>
                                                            <a href="https://basketeer.com/product-category/balloon-gifts/balloons-for-her/">Balloons for Her</a>
                                                            <a href="https://basketeer.com/product-category/balloon-gifts/balloons-for-kids/">Balloons for Kids</a>
                                                        </div>
                                                        <div class="subNavTitle">Shop by Occasions</div>
                                                        <div class="subNavItems">
                                                            <a href="https://basketeer.com/product-category/balloon-gifts/birthday-balloons/">Birthday Balloons</a>
                                                            <a href="https://basketeer.com/product-category/balloon-gifts/new-baby-born-balloon/">New Born Baby Balloons</a>
                                                            <a href="https://basketeer.com/product-category/balloon-gifts/get-well-soon-balloons/">Get Well Soon Balloons</a>
                                                            <a href="https://basketeer.com/product-category/balloon-gifts/kids-birthday-balloons/">Kids Birthday Balloons</a>

                                                        </div>
                                                        <div class="subNavTitle">Balloons By Color Tone</div>
                                                        <div class="subNavItems">
                                                            <a href="https://basketeer.com/product-category/balloon-gifts/pink-tone-balloons/">Pink and Rose Gold Tone Balloons</a>
                                                            <a href="https://basketeer.com/product-category/balloon-gifts/gold-and-yellow-tones-balloons/">Gold and Yellow Tone Balloons</a>
                                                            <a href="https://basketeer.com/product-category/balloon-gifts/red-and-orange-tones-balloons/">Red and Orange Tone Balloons</a>
                                                            <a href="https://basketeer.com/product-category/balloon-gifts/black-tone-balloon/">Black Tone Balloons</a>
                                                            <a href="https://basketeer.com/product-category/balloon-gifts/pastell-balloons/">Pastell Balloons</a>
                                                            <a href="https://basketeer.com/product-category/balloon-gifts/blue-tone-balloons/">Blue Tone Balloons</a>
                                                            <a href="https://basketeer.com/product-category/balloon-gifts/bronze-tones-balloons/">Bronze Tone Balloons</a>
                                                            <a href="https://basketeer.com/product-category/balloon-gifts/cream-white-tones-balloons/">Cream and White Tone Balloons</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header" id="headingKidsBabies">
                                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseKidsBabies" aria-expanded="false" aria-controls="collapseKidsBabies">
            Kids & Babies
        </button>
                                            </h2>
                                            <div id="collapseKidsBabies" class="accordion-collapse collapse" aria-labelledby="headingKidsBabies" data-bs-parent="#myAccordion">
                                                <div class="accordion-body">
                                                    <div class="subNavTitle" style="margin-bottom: 20px;"><a href="https://basketeer.com/product-category/kids-and-babies/">View All Kids & Babies</a></div>
                                                    <div class="subNavTitle">New Born Gifts</div>
                                                    <div class="subNavItems">
                                                        <a href="https://basketeer.com/product-category/kids-and-babies/new-born-gift-baskets-hampers/">New Born Gift Baskets & Hampers</a>
                                                        <a href="https://basketeer.com/product-category/kids-and-babies/babies-cuddly-toys/">Babies Cuddly Toys</a>
                                                        <a href="https://basketeer.com/product-category/kids-and-babies/personalised-baby-gifts/">Personalised Baby Gifts</a>
                                                        <a href="https://basketeer.com/product-category/kids-and-babies/welcome-baby-balloons/">Welcome Baby Balloons</a>
                                                    </div>
                                                    <div class="subNavTitle">Kids Gifts</div>
                                                    <div class="subNavItems">
                                                        <a href="https://basketeer.com/product-category/kids-and-babies/kids-birthday-cakes/">Kids Birthday Cakes</a>
                                                        <a href="https://basketeer.com/product-category/kids-and-babies/kids-birthday-balloons/">Kids Birthday Balloons</a>
                                                        <a href="https://basketeer.com/product-category/kids-and-babies/kids-birthday-gift-baskets/">Kids Birthday Gift Baskets</a>
                                                        <a href="https://basketeer.com/product-category/kids-and-babies/kids-soft-toys/">Kids Soft Toys</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item ">
                                            <h2 class="accordion-header" id="headingSeven">
                                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapsepro" aria-expanded="false" aria-controls="collapsepro">
                                                Our Products
                                            </button>
                                            </h2>
                                            <div id="collapsepro" class="accordion-collapse collapse" aria-labelledby="headingSeven" data-bs-parent="#myAccordion">
                                                <div class="accordion-body">
                                                    <div>

                                                        <div class="subNavTitle" style="margin-bottom: 20px;"><a href="https://basketeer.com/product-category/our-products/">View All Our Products</a></div>


                                                        <div class="subNavItems">
                                                            <!-- <a href="https://basketeer.com/product-category/our-productscelebratory-drinks-list/" rel="nofollow">Celebratory Drinks List</a> -->
                                                            <a href="https://basketeer.com/product-category/our-products/empty-baskets/">Empty Baskets</a>
                                                            <a href="https://basketeer.com/product-category/our-products/teddy-bears-soft-toys/">Teddy Bears & Soft Toys</a>
                                                            <a href="https://basketeer.com/product-category/our-products/vase/">Vases</a>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item ">
                                            <h2 class="accordion-header" id="headingeigth">

                                                <a class="navText nav-link" href="https://basketeer.com/corporate-gift-baskets/">Corporate Gift Baskets</a>
                                            </h2>
                                        </div>
                                    </div>
                                    <div class="quickNav">
                                        <div class="accordion-button" type="button">
                                            <a href="https://basketeer.com/product-category/gift-baskets/gift-for-her/">Gifts For Her</a>
                                            <div>
                                                <img width="32px" height="22px" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/10/13165549/gift-for-her-1.png" alt="gifts for her">
                                            </div>
                                        </div>
                                        <div class="accordion-button" type="button">
                                            <a href="https://basketeer.com/product-category/gift-baskets/gift-for-him/">Gifts For Him</a>
                                            <div>
                                                <img width="32px" height="22px" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/10/13165557/gift-for-him-1.png" alt="gifts for him">
                                            </div>
                                        </div>
                                        <div class="accordion-button" type="button">
                                            <a href="https://basketeer.com/product-category/gift-baskets/surprise-gifts/">Surprise Gifts</a>
                                            <div>
                                                <img width="24px" height="24px" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/surprise-gift-icon.svg" alt="Surprise Gifts">
                                            </div>
                                        </div>
                                        <div class="accordion-button" type="button">
                                            <a href="https://basketeer.com/product-category/bakery-gifts/cakes/">Cakes</a>
                                            <div>
                                                <img width="21px" height="20px" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/cake-icon.svg" alt="Cakes">
                                            </div>
                                        </div>
                                        <div class="accordion-button" type="button">
                                            <a href="https://basketeer.com/product-category/combo-gifts/best-sellers/">Birthday Gifts</a>
                                            <div>
                                                <img width="19px" height="20px" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/gift-icon.svg" alt="Birthday Gifts">
                                            </div>
                                        </div>
                                        <div class="accordion-button" type="button">
                                            <a href="https://basketeer.com/product-category/combo-gifts/">Combo Gifts</a>
                                            <div>
                                                <img width="32px" height="18px" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/10/13165531/combo-gifts.png" alt="Combo Gifts">
                                            </div>
                                        </div>

                                        <div class="accordion-button" type="button">
                                            <a href="https://basketeer.com/product-category/gift-baskets//new-borns/">New Born</a>
                                            <div>
                                                <img width="32px" height="20px" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/baby-cloth-icon.svg" alt="New Born">
                                            </div>
                                        </div>


                                        <div class="accordion-button" type="button">
                                            <a href="https://basketeer.com/product-category/gift-baskets/get-well-soon/">Get Well Soon Gifts</a>
                                            <div>
                                                <img width="32px" height="22px" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/10/13165539/get-well-soon-1.png" alt="Get Well Soon Gifts">
                                            </div>
                                        </div>



                                    </div>
                                    <div class="menuCards">
                                        <div class="menuCard">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="menuCardContent">
                                                    <div class="menuCardTitle text-white">CHARLOTTE BAKERY</div>
                                                    <a href="https://basketeer.com/product-category/bakery-gifts/best-sellers-bakery-gifts/" target="_blank" rel="noopener noreferrer"><button class="menuCardBtn text-white">Best Sellers</button></a>
                                                    <img src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/charlotteeLogo.svg" alt="" srcset="">
                                                </div>
                                                <div class="menuCardImage">
                                                    <img src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/05/01093221/25-03-27-Letter-Cakes-ABC-20251839.jpg" alt="" srcset="" style="width: 60%; height: 60%; object-fit: cover; margin: auto; display: block;">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="ex2-tabs-2" role="tabpanel" aria-labelledby="ex2-tab-2">

                                    <div class="accordion" id="myAccordion">
                                        <div class="accordion-item">
                                            <h2 class="accordion-header" id="headingOne">
                                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                                Our Services
                                            </button>
                                            </h2>
                                            <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#myAccordion">
                                                <div class="accordion-body">
                                                    <div>
                                                        <div class="subNavItems">
                                                            <a class="" href="https://basketeer.com/corporate-gift-baskets/">Corporate Gift Baskets</a>
                                                            <a href="https://basketeer.com/gift-design-service/">Gifts Design Services</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header" id="headingTwo">
                                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                                Customer Services
                                            </button>
                                            </h2>
                                            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#myAccordion">
                                                <div class="accordion-body">
                                                    <div>
                                                        <div class="subNavTitle" style="font-family: EB Garamond;font-size: 16px;font-weight: 600;line-height: 21px;margin-bottom: 20px;">Customer Service Team</div>
                                                        <div class="subNavItems">
                                                            <a href="https://wa.me/66919366956"><img width="17px" height="17px" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/whatsapp-icon.svg" alt="whatsapp">Whatsapp</a>
                                                            <a href="https://www.facebook.com/messages/t/166151743584888"><img width="18px" height="18px" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/messenger-icon.svg" alt="messenger">Messenger</a>
                                                            <a href="tel:+66028215042"><img width="16px" height="16px" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/phone-icon.svg" alt="phone">+66(0)2 821 5042</a>
                                                            <a href="/cdn-cgi/l/email-protection#a3cacdc5cce3c1c2d0c8c6d7c6c6d18dc0cc8dd7cb"><img width="14px" height="11px" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/email-icon.svg" alt="email"><span class="__cf_email__" data-cfemail="541d3a323b143635273f31203131267a373b7a203c">[email&#160;protected]</span></a>
                                                            <a href="http://line.me/ti/p/@basketeer"><img width="15px" height="14px" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/line-icon.svg" alt="line">@Basketeer</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Tabs content -->
                            </div>
                        </div>
                    </div>
                    <div class="mainHeaderbarRight col-6 d-flex justify-content-center px-0">
                        <a href="https://basketeer.com">
                        <img width="156" height="34" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/08/Full-Logo.svg" alt="logo">
                    </a>
                    </div>
                    <div class="mainHeaderbarLeft col-3 d-flex justify-content-end align-items-center text-end">
                        <a class="cart" href="javascript://" onclick="openMiniCart();" style="margin-left:8px">
                            <!-- <a class="cart" href="/cart/"> -->
                            <img width="25" height="22" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/basketeerCart.svg" alt="Cart">
                            <span class="cart-count">0</span> </a>
                        <div class="gtranslate_wrapper" id="gt-wrapper-88349573"></div>
                    </div>

                </div>
            </nav>
            <!-- <div class="collapse multi-collapse" id="multiCollapseExample1">
            <div  class="dgwt-wcas-search-wrapp dgwt-wcas-has-submit woocommerce dgwt-wcas-style-pirx-compact dgwt-wcas-style-pirx js-dgwt-wcas-layout-icon-flexible dgwt-wcas-layout-icon-flexible js-dgwt-wcas-mobile-overlay-enabled">
							<svg class="dgwt-wcas-loader-circular dgwt-wcas-icon-preloader" viewBox="25 25 50 50">
					<circle class="dgwt-wcas-loader-circular-path" cx="50" cy="50" r="20" fill="none"
						 stroke-miterlimit="10"/>
				</svg>
						<a href="#"  class="dgwt-wcas-search-icon js-dgwt-wcas-search-icon-handler" aria-label="Open search bar">				<svg class="dgwt-wcas-ico-magnifier-handler" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18">
					<path  d=" M 16.722523,17.901412 C 16.572585,17.825208 15.36088,16.670476 14.029846,15.33534 L 11.609782,12.907819 11.01926,13.29667 C 8.7613237,14.783493 5.6172703,14.768302 3.332423,13.259528 -0.07366363,11.010358 -1.0146502,6.5989684 1.1898146,3.2148776
						  1.5505179,2.6611594 2.4056498,1.7447266 2.9644271,1.3130497 3.4423015,0.94387379 4.3921825,0.48568469 5.1732652,0.2475835 5.886299,0.03022609 6.1341883,0 7.2037391,0 8.2732897,0 8.521179,0.03022609 9.234213,0.2475835 c 0.781083,0.23810119 1.730962,0.69629029 2.208837,1.0654662
						  0.532501,0.4113763 1.39922,1.3400096 1.760153,1.8858877 1.520655,2.2998531 1.599025,5.3023778 0.199549,7.6451086 -0.208076,0.348322 -0.393306,0.668209 -0.411622,0.710863 -0.01831,0.04265 1.065556,1.18264 2.408603,2.533307 1.343046,1.350666 2.486621,2.574792 2.541278,2.720279 0.282475,0.7519
						  -0.503089,1.456506 -1.218488,1.092917 z M 8.4027892,12.475062 C 9.434946,12.25579 10.131043,11.855461 10.99416,10.984753 11.554519,10.419467 11.842507,10.042366 12.062078,9.5863882 12.794223,8.0659672 12.793657,6.2652398 12.060578,4.756293 11.680383,3.9737304 10.453587,2.7178427
						  9.730569,2.3710306 8.6921295,1.8729196 8.3992147,1.807606 7.2037567,1.807606 6.0082984,1.807606 5.7153841,1.87292 4.6769446,2.3710306 3.9539263,2.7178427 2.7271301,3.9737304 2.3469352,4.756293 1.6138384,6.2652398 1.6132726,8.0659672 2.3454252,9.5863882 c 0.4167354,0.8654208 1.5978784,2.0575608
						  2.4443766,2.4671358 1.0971012,0.530827 2.3890403,0.681561 3.6130134,0.421538 z
					"/>
				</svg>
				</a>
		<div class="dgwt-wcas-search-icon-arrow"></div>
		<form class="dgwt-wcas-search-form" role="search" action="https://basketeer.com/" method="get">
		<div class="dgwt-wcas-sf-wrapp">
						<label class="screen-reader-text"
				   for="dgwt-wcas-search-input-2">Products search</label>

			<input id="dgwt-wcas-search-input-2"
				   type="search"
				   class="dgwt-wcas-search-input"
				   name="s"
				   value=""
				   placeholder="Search..."
				   autocomplete="off"
							/>
			<div class="dgwt-wcas-preloader"></div>

			<div class="dgwt-wcas-voice-search"></div>

							<button type="submit"
						aria-label="Search"
						class="dgwt-wcas-search-submit">				<svg class="dgwt-wcas-ico-magnifier" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18">
					<path  d=" M 16.722523,17.901412 C 16.572585,17.825208 15.36088,16.670476 14.029846,15.33534 L 11.609782,12.907819 11.01926,13.29667 C 8.7613237,14.783493 5.6172703,14.768302 3.332423,13.259528 -0.07366363,11.010358 -1.0146502,6.5989684 1.1898146,3.2148776
						  1.5505179,2.6611594 2.4056498,1.7447266 2.9644271,1.3130497 3.4423015,0.94387379 4.3921825,0.48568469 5.1732652,0.2475835 5.886299,0.03022609 6.1341883,0 7.2037391,0 8.2732897,0 8.521179,0.03022609 9.234213,0.2475835 c 0.781083,0.23810119 1.730962,0.69629029 2.208837,1.0654662
						  0.532501,0.4113763 1.39922,1.3400096 1.760153,1.8858877 1.520655,2.2998531 1.599025,5.3023778 0.199549,7.6451086 -0.208076,0.348322 -0.393306,0.668209 -0.411622,0.710863 -0.01831,0.04265 1.065556,1.18264 2.408603,2.533307 1.343046,1.350666 2.486621,2.574792 2.541278,2.720279 0.282475,0.7519
						  -0.503089,1.456506 -1.218488,1.092917 z M 8.4027892,12.475062 C 9.434946,12.25579 10.131043,11.855461 10.99416,10.984753 11.554519,10.419467 11.842507,10.042366 12.062078,9.5863882 12.794223,8.0659672 12.793657,6.2652398 12.060578,4.756293 11.680383,3.9737304 10.453587,2.7178427
						  9.730569,2.3710306 8.6921295,1.8729196 8.3992147,1.807606 7.2037567,1.807606 6.0082984,1.807606 5.7153841,1.87292 4.6769446,2.3710306 3.9539263,2.7178427 2.7271301,3.9737304 2.3469352,4.756293 1.6138384,6.2652398 1.6132726,8.0659672 2.3454252,9.5863882 c 0.4167354,0.8654208 1.5978784,2.0575608
						  2.4443766,2.4671358 1.0971012,0.530827 2.3890403,0.681561 3.6130134,0.421538 z
					"/>
				</svg>
				</button>
			
			<input type="hidden" name="post_type" value="product"/>
			<input type="hidden" name="dgwt_wcas" value="1"/>

			
					</div>
	</form>
</div>
        </div> -->
        </section>

        <section class="mainHeaderbar d-none d-xl-block" style="background:#fff">
            <div class="container-fluid">
                <div class="topBarInfo">
                    <div class=" d-flex flex-nowrap justify-content-between align-items-center">
                        <div class="mainHeaderbarRight col-4 d-flex align-items-centerter px-0">
                            <a href="https://basketeer.com">
                            <img width="210" height="46" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/08/Full-Logo.svg" alt="logo">
                        </a>
                        </div>
                        <div class="mainHeaderbarLeft col-8 d-flex justify-content-end align-items-center px-0">
                            <div class="searchbar">
                                <div class="dgwt-wcas-search-wrapp dgwt-wcas-has-submit woocommerce dgwt-wcas-style-pirx-compact dgwt-wcas-style-pirx js-dgwt-wcas-layout-icon-flexible dgwt-wcas-layout-icon-flexible js-dgwt-wcas-mobile-overlay-enabled">
                                    <svg class="dgwt-wcas-loader-circular dgwt-wcas-icon-preloader" viewBox="25 25 50 50">
					<circle class="dgwt-wcas-loader-circular-path" cx="50" cy="50" r="20" fill="none"
						 stroke-miterlimit="10"/>
				</svg>
                                    <a href="#" class="dgwt-wcas-search-icon js-dgwt-wcas-search-icon-handler" aria-label="Open search bar">				<svg class="dgwt-wcas-ico-magnifier-handler" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18">
					<path  d=" M 16.722523,17.901412 C 16.572585,17.825208 15.36088,16.670476 14.029846,15.33534 L 11.609782,12.907819 11.01926,13.29667 C 8.7613237,14.783493 5.6172703,14.768302 3.332423,13.259528 -0.07366363,11.010358 -1.0146502,6.5989684 1.1898146,3.2148776
						  1.5505179,2.6611594 2.4056498,1.7447266 2.9644271,1.3130497 3.4423015,0.94387379 4.3921825,0.48568469 5.1732652,0.2475835 5.886299,0.03022609 6.1341883,0 7.2037391,0 8.2732897,0 8.521179,0.03022609 9.234213,0.2475835 c 0.781083,0.23810119 1.730962,0.69629029 2.208837,1.0654662
						  0.532501,0.4113763 1.39922,1.3400096 1.760153,1.8858877 1.520655,2.2998531 1.599025,5.3023778 0.199549,7.6451086 -0.208076,0.348322 -0.393306,0.668209 -0.411622,0.710863 -0.01831,0.04265 1.065556,1.18264 2.408603,2.533307 1.343046,1.350666 2.486621,2.574792 2.541278,2.720279 0.282475,0.7519
						  -0.503089,1.456506 -1.218488,1.092917 z M 8.4027892,12.475062 C 9.434946,12.25579 10.131043,11.855461 10.99416,10.984753 11.554519,10.419467 11.842507,10.042366 12.062078,9.5863882 12.794223,8.0659672 12.793657,6.2652398 12.060578,4.756293 11.680383,3.9737304 10.453587,2.7178427
						  9.730569,2.3710306 8.6921295,1.8729196 8.3992147,1.807606 7.2037567,1.807606 6.0082984,1.807606 5.7153841,1.87292 4.6769446,2.3710306 3.9539263,2.7178427 2.7271301,3.9737304 2.3469352,4.756293 1.6138384,6.2652398 1.6132726,8.0659672 2.3454252,9.5863882 c 0.4167354,0.8654208 1.5978784,2.0575608
						  2.4443766,2.4671358 1.0971012,0.530827 2.3890403,0.681561 3.6130134,0.421538 z
					"/>
				</svg>
				</a>
                                    <div class="dgwt-wcas-search-icon-arrow"></div>
                                    <form class="dgwt-wcas-search-form" role="search" action="https://basketeer.com/" method="get">
                                        <div class="dgwt-wcas-sf-wrapp">
                                            <label class="screen-reader-text" for="dgwt-wcas-search-input-3">Products search</label>

                                            <input id="dgwt-wcas-search-input-3" type="search" class="dgwt-wcas-search-input" name="s" value="" placeholder="Search..." autocomplete="off" />
                                            <div class="dgwt-wcas-preloader"></div>

                                            <div class="dgwt-wcas-voice-search"></div>

                                            <button type="submit" aria-label="Search" class="dgwt-wcas-search-submit">				<svg class="dgwt-wcas-ico-magnifier" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18">
					<path  d=" M 16.722523,17.901412 C 16.572585,17.825208 15.36088,16.670476 14.029846,15.33534 L 11.609782,12.907819 11.01926,13.29667 C 8.7613237,14.783493 5.6172703,14.768302 3.332423,13.259528 -0.07366363,11.010358 -1.0146502,6.5989684 1.1898146,3.2148776
						  1.5505179,2.6611594 2.4056498,1.7447266 2.9644271,1.3130497 3.4423015,0.94387379 4.3921825,0.48568469 5.1732652,0.2475835 5.886299,0.03022609 6.1341883,0 7.2037391,0 8.2732897,0 8.521179,0.03022609 9.234213,0.2475835 c 0.781083,0.23810119 1.730962,0.69629029 2.208837,1.0654662
						  0.532501,0.4113763 1.39922,1.3400096 1.760153,1.8858877 1.520655,2.2998531 1.599025,5.3023778 0.199549,7.6451086 -0.208076,0.348322 -0.393306,0.668209 -0.411622,0.710863 -0.01831,0.04265 1.065556,1.18264 2.408603,2.533307 1.343046,1.350666 2.486621,2.574792 2.541278,2.720279 0.282475,0.7519
						  -0.503089,1.456506 -1.218488,1.092917 z M 8.4027892,12.475062 C 9.434946,12.25579 10.131043,11.855461 10.99416,10.984753 11.554519,10.419467 11.842507,10.042366 12.062078,9.5863882 12.794223,8.0659672 12.793657,6.2652398 12.060578,4.756293 11.680383,3.9737304 10.453587,2.7178427
						  9.730569,2.3710306 8.6921295,1.8729196 8.3992147,1.807606 7.2037567,1.807606 6.0082984,1.807606 5.7153841,1.87292 4.6769446,2.3710306 3.9539263,2.7178427 2.7271301,3.9737304 2.3469352,4.756293 1.6138384,6.2652398 1.6132726,8.0659672 2.3454252,9.5863882 c 0.4167354,0.8654208 1.5978784,2.0575608
						  2.4443766,2.4671358 1.0971012,0.530827 2.3890403,0.681561 3.6130134,0.421538 z
					"/>
				</svg>
				</button>

                                            <input type="hidden" name="post_type" value="product" />
                                            <input type="hidden" name="dgwt_wcas" value="1" />


                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="profileBar">
                                <img width="22" height="22" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/basketeerProfile.svg" alt="profile">

                                <a class="text " href="https://basketeer.com/login">Login</a> / <a class="text " href="https://basketeer.com/register">Register</a>

                            </div>

                            <a href="https://basketeer.com/my-account/wishlists/" class="wishList">
                            <img width="25" height="22" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/basketeerWishlist.svg" alt="Wishlist" />
                            <span id="wishlist-count" class="wishlist-count"></span>
                        </a>

                            <a class="cart" href="javascript://" onclick="openMiniCart();" style="margin-left:8px">
                                <!-- <a class="cart" href="/cart/"> -->
                                <img width="25" height="22" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/basketeerCart.svg" alt="cart">
                                <span class="cart-count">0</span> </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <section class="bottomHeaderbar d-none d-xl-block" style="background:#fff">
            <nav class="navbar navbar-expand-lg">
                <div class="container-fluid">
                    <ul class="navbar-nav">
                        <li class="nav-item dropdown has-megamenu ">
                            <a class="navText nav-link dropdown-toggle" href="https://basketeer.com/product-category/gift-baskets/">Gift Baskets</a>
                            <div class="dropdown-menu megamenu" role="menu">
                                <div class="container-fluid d-flex navContainer justify-content-between">
                                    <div class="col-lg-3 col-6">
                                        <div class="col-megamenu">
                                            <h6 class="title">Shop By Collections</h6>
                                            <element class="horizontal"></element>
                                            <ul class="navList list-unstyled">

                                                <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/gift-basket-best-sellers/">Best Sellers</a></li>
                                                <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/luxury-collection/">Luxury Collection</a></li>
                                                <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/food-beverage/">Food & Beverage</a></li>
                                                <li class="navLink"><a href="https://basketeer.com/product-category/wine-gifts/" rel="nofollow">Celebratory Drinks<span style="display:block;font-size:11px;color:#a0a0a0;line-height:1;margin-top:-3px;">Log in required</span></a></li>
                                                <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/picnic-hampers/">Picnic Hampers</a></li>
                                                <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/health-wellness/">Health & Wellness</a></li>
                                                <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/gift-bag-collection/">Gift Bags</a></li>
                                                <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/gift-box-collection/">Gift Boxes</a></li>
                                                <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/gift-for-him/">Gifts for Him</a></li>
                                                <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/gift-for-her/">Gifts for Her</a></li>
                                                <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/gifts-for-kids/">Gifts for Kids</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-6">
                                        <div class="col-megamenu">
                                            <h6 class="title">Shop By Occasions</h6>
                                            <element class="horizontal"></element>
                                            <ul class="navList list-unstyled">
                                                <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/birthday-gifts/">Birthday Gifts</a></li>
                                                <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/surprise-gifts/">Surprise Gifts</a></li>
                                                <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/congratulations/">Congratulations</a></li>
                                                <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/thank-you/">Thank you</a></li>
                                                <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/get-well-soon-gift-baskets/">Get Well Soon</a></li>
                                                <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/new-borns/">New Borns</a></li>
                                                <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/anniversary-gifts/">Anniversary Gifts</a>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/christmas/">Christmas Gifts</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/chinese-new-year/">Chinese New Year</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/valentiness-day/">Valentine's Day</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/mothers-day-gift-baskets/">Mother's Day</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/st-patricks-day/">St. Patricks Day</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/new-home-gifts/">New Home Gifts</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/the-moon-festival/">The Moon Festival</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/thai-new-year-songkran/">Thai New Year - Songkran</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-6">
                                        <div class="col-megamenu">
                                            <h6 class="title">Shop By Product</h6>
                                            <element class="horizontal"></element>
                                            <ul class="navList list-unstyled">
                                                <!-- <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/celebratory-drinks-gift-baskets/" rel="nofollow">Celebratory Drinks Baskets</a></li> -->
                                                <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/doitung-doikham-gift-baskets/">Doitung & Doikham Gift Baskets</a></li>
                                                <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/birdnests-gift-baskets/">Birdnests Gift Baskets</a></li>
                                                <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/spa-aroma-products/">Spa & Aroma Products</a></li>
                                                <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/cheese-gift-baskets/">Cheese Gift Baskets</a></li>
                                                <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/dired-fruits-nuts-baskets/">Dired Fruits & Nuts Baskets</a></li>
                                                <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/chocolates-sweets-baskets/">Chocolates & Sweets Baskets</a></li>
                                                <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/tea-coffee-collection/">Tea & Coffee Collection</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </li>
                            <li class="nav-item dropdown has-megamenu ">
                                <a class="navText nav-link dropdown-toggle" href="https://basketeer.com/product-category/fruit-baskets/">Fruit Baskets</a>
                                <div class="dropdown-menu megamenu" role="menu">
                                    <div class="container-fluid d-flex navContainer justify-content-between">
                                        <div class="col-lg-4 col-6">
                                            <div class="col-megamenu">
                                                <h6 class="title">Shop By Design</h6>
                                                <element class="horizontal"></element>
                                                <ul class=" list-unstyled">
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/fruit-baskets/best-sellers/">Best Sellers</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/fruit-baskets/classic-fruit-baskets/">Classic Fruit Baskets</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/fruit-baskets/luxury-premium-fruits/">Luxury & Premium Fruits </a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/fruit-baskets/fruit-flowers/">Fruit & Flowers </a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/fruit-baskets/get-well-soon-fruit-baskets/">Get Well Soon Fruits</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/fruit-baskets/the-fruit-box-fruit-baskets/">The Fruit Box</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/fruit-baskets/blooming-round-box/">Blooming Round Box</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/fruit-baskets/heart-shaped-fruit-boxes/">Heart Shaped Fruit Boxes</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/fruit-baskets/birthday-fruits/">Birthday Fruits</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/fruit-baskets/fruit-for-mom/">Fruits for Mum</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/fruit-baskets/thank-you-fruits/">Thank You Fruits</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/fruit-baskets/congratulation-fruits/">Congratulations Fruits</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-6">
                                            <div class="col-megamenu">
                                                <h6 class="title">Shop By Fruit Type</h6>
                                                <element class="horizontal"></element>
                                                <ul class="list-unstyled">
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/fruit-baskets/japanese-fruits/">Japanese Fruits</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/fruit-baskets/oranges/">Oranges</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/fruit-baskets/apples/">Apples</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/fruit-baskets/berries-fruits/">Berries</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/fruit-baskets/grapes/">Grapes</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/fruit-baskets/thai-tropical-fruits/">Thai Summer Fruit Baskets</a></li>

                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-6">
                                            <div class="col-megamenu">
                                                <h6 class="title">Shop By Mixed Set</h6>
                                                <element class="horizontal"></element>
                                                <ul class="list-unstyled">
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/fruit-baskets/fruits-with-cheeses/">Fruits with Cheeses</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/fruit-baskets/fruits-with-healthy-products/">Fruits with Healthy Products</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/fruit-baskets/fruits-with-birdsnests/">Fruits with Birdsnests</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/fruit-baskets/fruits-with-premium-products/">Fruits with Premium Products </a></li>

                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="nav-item dropdown has-megamenu ">
                                <a class="navText nav-link dropdown-toggle" href="https://basketeer.com/product-category/combo-gifts/">Combo Gifts</a>
                                <div class="dropdown-menu megamenu" role="menu">
                                    <div class="container-fluid d-flex navContainer justify-content-between">
                                        <div class="col-lg-4 col-6">
                                            <div class="col-megamenu">
                                                <h6 class="title">Birthday Combos</h6>
                                                <element class="horizontal"></element>
                                                <ul class="list-unstyled">
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/combo-gifts/best-sellers-birthday-combos/">Best Sellers</a></li>
                                                    <!-- <li class="navLink"><a href="https://basketeer.com/product-category/combo-gifts/cakes-with-celebratory-drinks/" rel="nofollow">Cakes with Combo Drinks</a></li> -->
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/combo-gifts/cake-with-flower-balloons/">Cake with Flowers & Balloons</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/combo-gifts/cakes-with-flowers/">Cake with Flowers</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/combo-gifts/cake-with-balloons/">Cake with Balloons</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/combo-gifts/cake-with-soft-toys/">Cake with Soft Toys</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-6">
                                            <div class="col-megamenu">
                                                <h6 class="title">Congratulations Combo</h6>
                                                <element class="horizontal"></element>
                                                <ul class="list-unstyled">
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/combo-gifts/flowers-with-balloons/">Flowers with Balloons</a></li>
                                                    <!-- <li class="navLink"><a href="https://basketeer.com/product-category/combo-gifts/flowers-with-celebratory-drinks/" rel="nofollow">Flowers with Comboo Drinks</a></li> -->
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/combo-gifts/flowers-with-soft-toys/">Flowers with Soft Toys</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/combo-gifts/flowers-with-balloons-soft-toys/">Flowers with Balloons & Soft toys</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/combo-gifts/balloons-with-chocolates/">Balloons with Chocolates</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/combo-gifts/balloon-with-soft-toys/">Balloons with Soft Toys</a></li>
                                                    <!-- <li class="navLink"><a href="https://basketeer.com/product-category/combo-gifts/flowers-with-celebratory-drinks-balloons/" rel="nofollow">Flowers with Combo Drinks & Balloons</a></li> -->
                                                    <!-- <li class="navLink"><a href="https://basketeer.com/product-category/combo-gifts/celebratory-drinks-with-flowers-congrat-flowers/" rel="nofollow">Combo Drinks with Flowers</a></li> -->
                                                    <!-- <li class="navLink"><a href="https://basketeer.com/product-category/combo-gifts/celebratory-drinks-with-chocolates-balloons/" rel="nofollow">Combo Drinks with Chocolates & Balloons</a></li> -->
                                                    <!-- <li class="navLink"><a href="https://basketeer.com/product-category/combo-gifts/celebratory-drinks-with-chocolates/" rel="nofollow">Combo Drinks with Chocolates</a></li> -->
                                                    <!-- <li class="navLink"><a href="https://basketeer.com/product-category/combo-gifts/celebratory-drinks-with-flower-chocolates/" rel="nofollow">Combo Drinks with Flower & Chocolates</a></li> -->
                                                    <!-- <li class="navLink"><a href="https://basketeer.com/product-category/combo-gifts/celebratory-drinks-with-orchid-plants/" rel="nofollow">Combo Drinks with Orchid Plants</a></li> -->
                                                    <!-- <li class="navLink"><a href="https://basketeer.com/product-category/combo-gifts/celebratory-drinks-with-balloons/" rel="nofollow">Combo Drinks with Balloons</a></li> -->
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-6 ">
                                            <div class="col-megamenu">
                                                <h6 class="title">Get Well Soon Combo</h6>
                                                <element class="horizontal"></element>
                                                <ul class="list-unstyled">
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/combo-gifts/fruit-baskets-with-flowers/">Fruit Baskets with Flowers</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/combo-gifts/fruit-baskets-with-balloons/">Fruit Baskets with Balloons</a></li>

                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Commenting out the Celebratory Drinks section -->
                                <!-- End of commented section for now -->
                            </li>
                            <li class="nav-item dropdown has-megamenu ">
                                <a class="navText nav-link dropdown-toggle" href="https://basketeer.com/product-category/bakery-gifts/">Charlotte Bakery</a>
                                <div class="dropdown-menu megamenu" role="menu">
                                    <div class="container-fluid d-flex navContainer justify-content-between">
                                        <div class="col-lg-3 col-6" style="margin-right: 60px;">
                                            <div class="col-megamenu">
                                                <h6 class="title">Shop by Bakery Type</h6>
                                                <element class="horizontal"></element>
                                                <ul class="navList list-unstyled">
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/best-sellers-bakery-gifts/">Best Sellers</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/signature-bakery/">Singature Cakes</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/same-day-cakes/">Same Day Cakes</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/custom-cakes/">Custom Cakes</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/classic-cakes/">Classic Cakes</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/layer-cakes/">Layer Cakes</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/2-tier-cakes/">2 Tier Cakes</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/letter-cakes/">Letter Cakes</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/mini-cake-bakery-gifts/">Mini Cakes</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/cupcake-bakery-gifts/">Cupcakes</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/pies-tarts/">Pies & Tarts</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/chocolate-truffles/">Truffles & Praline</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/brownies-cookies/">Brownies & Cookies</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/macarons/">Macarons</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/chocolate-covered-strawberries/">Choco Covered Strawberries</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-6">
                                            <div class="col-megamenu">
                                                <h6 class="title">Shop By Occasion</h6>
                                                <element class="horizontal"></element>
                                                <ul class="list-unstyled">
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/summer-bakery/">Summer Bakery</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/birthday-cakes/">Birthday Cakes</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/birthday-bakery/">Birthday Bakery</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/christmas-bakery/">Christmas Bakery</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/halloween-bakery/">Halloween Bakery</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/mothers-day-bakery-gifts/">Mother's Day</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/valentines-day-bakery-gifts/">Valentine's Day</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-6">
                                            <div class="col-megamenu">
                                                <h6 class="title">Shop By Recipient</h6>
                                                <element class="horizontal"></element>
                                                <ul class="list-unstyled">
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/shop-for-men/">Shop for Men</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/shop-for-women/">Shop for Women</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/shop-for-kids/">Shop for Kids</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/shop-for-friends/">Shop for Friends</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-6">
                                            <div class="col-megamenu">
                                                <h6 class="title">Shop by Bakery Flavors</h6>
                                                <element class="horizontal"></element>
                                                <ul class="list-unstyled">
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/cheese-cakes/">Cheese Cakes</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/chocolate-flavors/">Chocolate Flavors</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/vanilla-flavors/">Vanilla Flavors</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/strawberry-flavors/">Strawberry Flavors</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/fruity-flavors/">Fruity Flavors</a></li>
                                                </ul>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </li>
                            <li class="nav-item dropdown has-megamenu ">
                                <a class="navText nav-link dropdown-toggle" href="https://basketeer.com/product-category/flower-gifts/">Flowers by Basketeer</a>
                                <div class="dropdown-menu megamenu" role="menu">
                                    <div class="container-fluid d-flex navContainer justify-content-between">
                                        <div class="col-lg-2 col-6">
                                            <div class="col-megamenu">
                                                <h6 class="title">Shop by Occasions</h6>
                                                <element class="horizontal"></element>
                                                <ul class="list-unstyled">
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/best-seller/">Best Sellers</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/congratulations-flowers/">Congratulations Flowers</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/birthday-flowers/">Birthday Flowers</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/romantic-flowers-for-her/">Romantic Flowers for Her</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/flowers-for-him/">Flowers for Him</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/get-well-soon-flower-gifts/">Get Well Soon Flowers</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/flower-for-funeral/">Flowers for Funerals</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/graduation-flowers/">Graduation Flowers</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/valentines-day/">Valentine's Day</a></li>
                                                    <!-- Fix Link Here -->
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-lg-2 col-6">
                                            <div class="col-megamenu">
                                                <h6 class="title">Shop by Design Type</h6>
                                                <element class="horizontal"></element>
                                                <ul class="list-unstyled">
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/mini-bouquets/">Small Bouquets</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/all-bouquet-flowers/">All Premium Bouquets</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/flowers-in-vases/">Flowers in Vases</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/flowers-in-baskets/">Flowers in Baskets</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/flowers-in-boxes/">Flowers in Boxes</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts//mini-flowers-in-vases/">Mini Flowers in Vases</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/luxury-flowers/">Luxury Flowers</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/luxury-british-designs/">Luxury British Designs</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/plant-gifts/">Plant Gifts</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-lg-2 col-6">
                                            <div class="col-megamenu">
                                                <h6 class="title">Dried & Artificial Flowers</h6>
                                                <element class="horizontal"></element>
                                                <ul class="list-unstyled">
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/all-artificial-flowers/">View All Artificial</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/potted-orchids/">Potted Orchids</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/artificial-flower-vases/">Artificial Flower Vases</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/dried-and-preserved-flowers/">Dried & Preserved Flowers</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-lg-2 col-6">
                                            <div class="col-megamenu">
                                                <h6 class="title">Shop by Recipeints</h6>
                                                <element class="horizontal"></element>
                                                <ul class="list-unstyled">
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/flowers-for-women/">Flowers for Women </a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/flowers-for-men/">Flowers for Men</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/flowers-for-mum/">Flowers For Mum </a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/flowers-for-friends/">Flowers for Friends</a></li>
                                                </ul>
                                            </div>
                                        </div>

                                        <div class="col-lg-2 col-6">
                                            <div class="col-megamenu">
                                                <h6 class="title">Shop by Flower Type</h6>
                                                <element class="horizontal"></element>
                                                <ul class="list-unstyled">
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/roses/">Roses</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/lillys/">Lillys</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/sunflowers/">Sunflowers</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/hydrangeas/">Hydrangeas</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/orchids/">Orchids</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/tulips/">Tulips</a></li>
                                                </ul>
                                            </div>
                                        </div>


                                    </div>
                            </li>
                            <li class="nav-item dropdown has-megamenu ">
                                <a class="navText nav-link dropdown-toggle" href="https://basketeer.com/product-category/balloon-gifts/">Balloon Gifts</a>
                                <div class="dropdown-menu megamenu" role="menu">
                                    <div class="container-fluid d-flex navContainer justify-content-between">
                                        <div class="col-lg-4 col-6">
                                            <div class="col-megamenu">
                                                <h6 class="title">Shop by Design</h6>
                                                <element class="horizontal"></element>
                                                <ul class="list-unstyled">
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/balloon-gifts/best-selling-balloons/">Best Selling Balloons</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/balloon-gifts/single-balloons/">Single Balloons</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/balloon-gifts/set-of-balloons/">Set of Balloons</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/balloon-gifts/balloons-for-lovers/">Balloons for lovers</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/balloon-gifts/balloons-for-him/">Balloons for Him</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/balloon-gifts/balloons-for-her/">Balloons for Her</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/balloon-gifts/balloons-for-kids/">Balloons for Kids</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-6">
                                            <div class="col-megamenu">
                                                <h6 class="title">Shop by Occasions</h6>
                                                <element class="horizontal"></element>
                                                <ul class="list-unstyled">
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/balloon-gifts/birthday-balloons/">Birthday Balloons</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/balloon-gifts/new-baby-born-balloon/">New Born Baby Balloons</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/balloon-gifts/get-well-soon-balloons/">Get Well Soon Balloons</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/balloon-gifts/kids-birthday-balloons/">Kids Birthday Balloons</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-6">
                                            <div class="col-megamenu">
                                                <h6 class="title">Balloons By Color Tone</h6>
                                                <element class="horizontal"></element>
                                                <ul class="list-unstyled">
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/balloon-gifts/pink-tone-balloons/">Pink and Rose Gold Tone Balloons</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/balloon-gifts/gold-and-yellow-tones-balloons/">Gold and Yellow Tone Balloons</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/balloon-gifts/red-and-orange-tones-balloons/">Red and Orange Tone Balloons</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/balloon-gifts/black-tone-balloon/">Black Tone Balloons</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/balloon-gifts/pastell-balloons/">Pastell Balloons</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/balloon-gifts/blue-tone-balloons/">Blue Tone Balloons</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/balloon-gifts/bronze-tones-balloons/">Bronze Tone Balloons</a></li>
                                                    <li class="navLink"><a href="https://basketeer.com/product-category/balloon-gifts/cream-white-tones-balloons/">Cream and White Tone Balloons</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <li class="nav-item dropdown has-megamenu ">
                                    <a class="navText nav-link dropdown-toggle" href="https://basketeer.com/product-category/kids-and-babies/">Kids & Babies</a>
                                    <div class="dropdown-menu megamenu" role="menu">
                                        <div class="container-fluid d-flex navContainer g-2">
                                            <div class="col-lg-4 col-6">
                                                <div class="col-megamenu">
                                                    <h6 class="title">New Born Gifts</h6>
                                                    <element class="horizontal"></element>
                                                    <ul class="list-unstyled">
                                                        <li class="navLink"><a href="https://basketeer.com/product-category/kids-and-babies/new-born-gift-baskets-hampers/">New Born Gift Baskets & Hampers</a></li>
                                                        <li class="navLink"><a href="https://basketeer.com/product-category/kids-and-babies/babies-cuddly-toys/">Babies Cuddly Toys</a></li>
                                                        <li class="navLink"><a href="https://basketeer.com/product-category/kids-and-babies/personalised-baby-gifts/">Personalised Baby Gifts</a></li>
                                                        <li class="navLink"><a href="https://basketeer.com/product-category/kids-and-babies/welcome-baby-balloons/">Welcome Baby Balloons</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-lg-4 col-6">
                                                <div class="col-megamenu">
                                                    <h6 class="title">Kids Gifts</h6>
                                                    <element class="horizontal"></element>
                                                    <ul class="list-unstyled">
                                                        <li class="navLink"><a href="https://basketeer.com/product-category/kids-and-babies/kids-birthday-cakes/">Kids Birthday Cakes</a></li>
                                                        <li class="navLink"><a href="https://basketeer.com/product-category/kids-and-babies/kids-birthday-balloons/">Kids Birthday Balloons</a></li>
                                                        <li class="navLink"><a href="https://basketeer.com/product-category/kids-and-babies/kids-birthday-gift-baskets/">Kids Birthday Gift Baskets</a>
                                                            <li class="navLink"><a href="https://basketeer.com/product-category/kids-and-babies/kids-soft-toys/">Kids Soft Toys</a></li>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </li>
                                <li class="nav-item dropdown  has-megamenu ">
                                    <a class="navText nav-link dropdown-toggle" href="https://basketeer.com/product-category/our-products/">Our Products</a>
                                    <div class="dropdown-menu megamenu" role="menu">
                                        <div class="container-fluid d-flex navContainer justify-content-between">
                                            <div class="col-lg-12 col-12">
                                                <div class="col-megamenu">

                                                    <ul class="list-unstyled">
                                                        <!-- <li class="navLink"><a href="https://basketeer.com/product-category/our-products/celebratory-drinks-list/" rel="nofollow">Celebratory Drinks List</a></li> -->
                                                        <li class="navLink"><a href="https://basketeer.com/product-category/our-products/empty-baskets/">Empty Baskets</a></li>
                                                        <li class="navLink"><a href="https://basketeer.com/product-category/our-products/teddy-bears-soft-toys/">Teddy Bears & Soft Toys</a></li>
                                                        <li class="navLink"><a href="https://basketeer.com/product-category/our-products/vase/">Vases</a></li>
                                                    </ul>
                                                </div>
                                            </div>


                                        </div>
                                    </div>
                                </li>

                                <li class="nav-item dropdown has-megamenu ">
                                    <a class="navText nav-link" href="https://basketeer.com/corporate-gift-baskets/">Corporate Gift Baskets</a>
                                </li>
                                <li class="nav-item dropdown has-megamenu navLastItem d-flex align-item-center ">
                                    <img width="14" height="14" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/basketeerGift.svg" alt="Corporate Gift Baskets">
                                    <a class="navText nav-link dropdown-toggle" href="https://basketeer.com/product-category/popular-gifts/">Gifts & Promos</a>
                                    <div class="dropdown-menu megamenu" role="menu">
                                        <div class="container-fluid d-flex navContainer justify-content-between">

                                            <!-- Favourite Gifts Column -->
                                            <div class="col-lg-2 col-6">
                                                <div class="col-megamenu">
                                                    <h6 class="title">Favourite Gifts</h6>
                                                    <element class="horizontal"></element>
                                                    <ul class="navList list-unstyled" style="column-count: 1;">
                                                        <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/thai-new-year-songkran/">Songkran Collection</a></li>
                                                        <li class="navLink"><a href="https://basketeer.com/product-category/fruit-baskets/thai-tropical-fruits/">Summer Collection</a></li>
                                                        <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/gift-for-her/">Gifts for Her</a></li>
                                                        <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/gift-for-him/">Gifts for Him</a></li>
                                                        <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/birthday-gifts/">Birthday Gifts</a></li>
                                                    </ul>
                                                </div>
                                            </div>

                                            <!-- Special Occasions Column -->
                                            <div class="col-lg-3 col-6">
                                                <div class="col-megamenu">
                                                    <h6 class="title">Special Occasions</h6>
                                                    <element class="horizontal"></element>
                                                    <ul class="navList list-unstyled" style="column-count: 1;">
                                                        <li class="navLink"><a href="https://basketeer.com/product-category/bakery-gifts/birthday-cakes/">Birthday Cakes</a></li>
                                                        <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/surprise-gifts/">Surprise Gifts</a></li>
                                                        <li class="navLink"><a href="https://basketeer.com/product-category/gift-baskets/get-well-soon-gift-baskets/">Get Well Soon</a></li>
                                                        <li class="navLink"><a href="https://basketeer.com/product-category/flower-gifts/all-bouquet-flowers/">Flower Bouquets</a></li>
                                                    </ul>
                                                </div>
                                            </div>

                                            <!-- Promotions Column -->
                                            <div class="col-lg-2 col-6">
                                                <div class="col-megamenu">
                                                    <h6 class="title">
                                                        <img src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/06173455/discount-coupon-voucher-shopping-ticket-promo-code-gift-card-be3a63.svg" alt="Promotions Icon" style="width: 24px; height: 22px; margin-right: 6px; vertical-align: middle;">                                                        Promotions
                                                    </h6>
                                                    <element class="horizontal"></element>
                                                    <ul class="navList list-unstyled" style="column-count: 1;">
                                                        <li class="navLink">
                                                            <a href="https://basketeer.com/promotions/">View All Promotions</a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>

                                            <!-- Image Column -->
                                            <div class="col-lg-2 col-6 text-center">
                                                <div class="col-megamenu">
                                                    <a href="https://basketeer.com/shop/bakery-gifts/sweetheart-serenade-cake/">
                        <img src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/04/10190814/25-02-03-Valentine20250465.jpg" alt="Popular Gifts Sweet Heart Pink Cake and decoration With Basketeer Ribbons" width="90%" height="">
                        <p class="menuProductCode" style="font-size: 0.8rem;">View Our Sweetheart Serenade Cake</p>
                    </a>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </li>

    </header>
    <section class="heroSlider">
        <div class="container-fluid">
            <div class="d-lg-block heroSliderItem d-none">
                <div class="heroSliderItems">
                    <div class="hero_slider_172593">
                        <link rel="preload" as="image" href="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/08/29132819/Fruit-and-Flowers-Web-1.jpg" />
                        <div class="d-flex align-items-center justify-content-between text-center heroSliderConatiner" style="background:url('https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/08/29132819/Fruit-and-Flowers-Web-1.jpg') center center/cover no-repeat"
                            aria-label="Homepage Image" fetchpriority="high" alt="Round tray arrangement with fresh cherries, strawberries, apples, raspberries, blueberries, and seasonal flowers for elegant gifting">
                            <div class="heroSliderContent">
                                <h4 class="heroSliderItemSubheading">Luxurious </h4>
                                <h2 class="heroSliderItemTitle">Blooming Fruit Boxes</h2>
                                <p class="text-center heroSliderItemText">Elegant Fruit & Flowers – Premium Fresh Gifts for Special Occasions</p>
                                <a href="https://basketeer.com/product-category/fruit-baskets/blooming-round-box/">
                                        <button class="btnBlack">VIEW COLLECTION</button>
                                    </a>
                            </div>
                        </div>
                    </div>
                    <style type="text/css">
                        .hero_slider_172593 .heroSliderItemSubheading,
                        .hero_slider_172593 .heroSliderItemTitle,
                        .hero_slider_172593 .heroSliderItemText {
                            color: #ffffff;
                        }

                        .hero_slider_172593 button.btnBlack:after {
                            background-color: #ffffff;
                        }
                    </style>
                </div>
            </div>
            <div class="heroSliderItemMobile d-lg-none">
                <div class="heroSliderItemsMobile">
                    <link rel="preload" as="image" href="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/08/29132828/Fruit-and-Flowers-Mobile-1.jpg" />
                    <div class="d-flex flex-column align-items-center justify-content-between text-center heroSliderConatiner hero_slider_mobile_172593">
                        <img width="100%" height="100%" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/08/29132828/Fruit-and-Flowers-Mobile-1.jpg" alt="Round tray arrangement with fresh cherries, strawberries, apples, raspberries, blueberries, and seasonal flowers for elegant gifting">
                        <div class="heroSliderContent">
                            <h4 class="heroSliderItemSubheading">Luxurious </h4>
                            <h2 class="heroSliderItemTitle">Blooming Fruit Boxes</h2>
                            <p class="text-center heroSliderItemText">Elegant Fruit & Flowers – Premium Fresh Gifts for Special Occasions</p>
                            <a href="https://basketeer.com/product-category/fruit-baskets/blooming-round-box/">
                                    <button class="btnBlack" href="https://basketeer.com/product-category/fruit-baskets/blooming-round-box/">VIEW COLLECTION</button>
                                </a>
                        </div>
                    </div>
                </div>
                <style type="text/css">
                    @media only screen and (max-width: 991px) {
                        .hero_slider_mobile_172593 .heroSliderItemSubheading,
                        .hero_slider_mobile_172593 .heroSliderItemTitle,
                        .hero_slider_mobile_172593 .heroSliderItemText {
                            color: #ffffff !important;
                        }
                        .hero_slider_mobile_172593 .heroSliderContent {
                            background-color: #c9cecc !important;
                        }
                        .hero_slider_mobile_172593 button.btnBlack:after {
                            background-color: #ffffff;
                        }
                    }
                </style>
            </div>
        </div>



        </div>
    </section>
    <!-- category_flower : string(0) ""
 -->
    <section class="features features_gold collection">
        <div class="container-fluid">
            <div class="d-flex justify-content-between featuresItems">
                <div class="d-flex featureItem">
                    <a href="https://basketeer.com/delivery-service/">
							<img width="41" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/03/05173937/feature-image-1-649bf8.svg" alt="Eco Friendly Vehicles" class="featureicon">
							<div class="featureItemContent">
								<h5 class="featureTitle">
									<a href="https://basketeer.com/delivery-service/">Expert Delivery Drivers</a>
                    </h5>
                    <p class="featureText">
                        <a style="color:#6B6B6B;" href="https://basketeer.com/delivery-service/">Friendly and Reliable</a>
                    </p>
                </div>
                </a>
            </div>
            <div class="d-flex featureItem">
                <a href="https://basketeer.com/delivery-service/">
							<img width="41" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/03/05173944/feature-image-2-b249d7.svg" alt="2 Hour Express Delivery" class="featureicon">
							<div class="featureItemContent">
								<h5 class="featureTitle">
									<a href="https://basketeer.com/delivery-service/">Refrigerated Ev Vehicles</a>
                </h5>
                <p class="featureText">
                    <a style="color:#6B6B6B;" href="https://basketeer.com/delivery-service/">Fast, Safe and Electric</a>
                </p>
            </div>
            </a>
        </div>
        <div class="d-flex featureItem">
            <a href="https://basketeer.com/delivery-service/">
							<img width="41" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/03/05173950/feature-image-3-afa9c4.svg" alt="Customer Support" class="featureicon">
							<div class="featureItemContent">
								<h5 class="featureTitle">
									<a href="https://basketeer.com/delivery-service/">Personalised Messaging</a>
            </h5>
            <p class="featureText">
                <a style="color:#6B6B6B;" href="https://basketeer.com/delivery-service/">Free Custom cards</a>
            </p>
        </div>
        </a>
        </div>
        <div class="d-flex featureItem">
            <a href="https://basketeer.com/delivery-service/">
							<img width="41" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/03/05173957/feature-image-4-f60072.svg" alt="Happiness Guarantee" class="featureicon">
							<div class="featureItemContent">
								<h5 class="featureTitle">
									<a href="https://basketeer.com/delivery-service/">Live Order Tracking</a>
            </h5>
            <p class="featureText">
                <a style="color:#6B6B6B;" href="https://basketeer.com/delivery-service/">Easy online service</a>
            </p>
        </div>
        </a>
        </div>
        </div>
        </div>
    </section>
    <section class="shopCategory">
        <div class="container-fluid">
            <div class="text-center shopCategoryHeader">
                <h2 class="sectionHeading">Shop <i>by</i> Category</h2>
                <h4 class="sectionSubHeading">Bangkok Same Day Delivery </h4>
            </div>
            <div class="categoryItems">
                <div class="text-center categoryItem">
                    <a href="https://basketeer.com/product-category/gift-baskets/">
                                <img width="100%" height="100%" class="categoryImage" decoding="async" loading="lazy" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/11111441/Gift-Baskets-1.jpg" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/11111441/Gift-Baskets-1.jpg 777w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/11111441/Gift-Baskets-1-600x686.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/11111441/Gift-Baskets-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/11111441/Gift-Baskets-1-263x300.jpg 263w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/11111441/Gift-Baskets-1-768x878.jpg 768w" alt="Golden Harvest Gift Hamper filled with gourmet treats, truffle oil, Ferrero Rocher chocolates, and luxury snacks in a wicker basket.">
                            </a>
                    <h4 class="categoryTitle">
                        <a href="https://basketeer.com/product-category/gift-baskets/">GIFT BASKETS</a>
                    </h4>
                </div>
                <div class="text-center categoryItem">
                    <a href="https://basketeer.com/product-category/gift-baskets/shop-by-collections/food-beverage/">
                                <img width="100%" height="100%" class="categoryImage" decoding="async" loading="lazy" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/11111754/Food-Beverage-Gifts-1-4.jpg" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/11111754/Food-Beverage-Gifts-1-4.jpg 777w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/11111754/Food-Beverage-Gifts-1-4-600x686.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/11111754/Food-Beverage-Gifts-1-4-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/11111754/Food-Beverage-Gifts-1-4-263x300.jpg 263w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/11111754/Food-Beverage-Gifts-1-4-768x878.jpg 768w" alt="Deluxe Celebration Gift Hamper filled with sparkling grape juice, gourmet chocolates, Maxim coffee, shortbread cookies, and other luxurious treats.">
                            </a>
                    <h4 class="categoryTitle">
                        <a href="https://basketeer.com/product-category/gift-baskets/shop-by-collections/food-beverage/">FOOD & BEVERAGE GIFTS</a>
                    </h4>
                </div>
                <div class="text-center categoryItem">
                    <a href="https://basketeer.com/product-category/fruit-baskets/">
                                <img width="100%" height="100%" class="categoryImage" decoding="async" loading="lazy" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/11111547/Fruit-Baskets1-2.jpg" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/11111547/Fruit-Baskets1-2.jpg 777w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/11111547/Fruit-Baskets1-2-600x686.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/11111547/Fruit-Baskets1-2-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/11111547/Fruit-Baskets1-2-263x300.jpg 263w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/11111547/Fruit-Baskets1-2-768x878.jpg 768w" alt="Luxury fruit basket with fresh seasonal fruits including melon, grapes, apples, blueberries, and white floral accents.">
                            </a>
                    <h4 class="categoryTitle">
                        <a href="https://basketeer.com/product-category/fruit-baskets/">FRUIT BASKETS</a>
                    </h4>
                </div>
                <div class="text-center categoryItem">
                    <a href="https://basketeer.com/product-category/bakery-gifts/">
                                <img width="100%" height="100%" class="categoryImage" decoding="async" loading="lazy" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/10/11185120/bakery-1-1.jpg" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/10/11185120/bakery-1-1.jpg 777w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/10/11185120/bakery-1-1-600x686.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/10/11185120/bakery-1-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/10/11185120/bakery-1-1-263x300.jpg 263w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/10/11185120/bakery-1-1-768x878.jpg 768w" alt="A luxurious two-tiered cake graced with an exquisite pink and orange watercolor design, adorned with an opulent array of pastel-colored roses and peonies, is elegantly displayed on a polished wooden pedestal. Beside the pedestal, a pristine white cloth and a luminous gold ring rest delicately on the surface. The scene is harmoniously tied together by the sophistication of Basketeer branding ribbon, adding an extra touch of refinement to this lavish presentation.">
                            </a>
                    <h4 class="categoryTitle">
                        <a href="https://basketeer.com/product-category/bakery-gifts/">BAKERY GIFTS</a>
                    </h4>
                </div>
                <div class="text-center categoryItem">
                    <a href="https://basketeer.com/product-category/kids-and-babies/new-born-gift-baskets-hampers/">
                                <img width="100%" height="100%" class="categoryImage" decoding="async" loading="lazy" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/10/12131903/New-brn.jpg" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/10/12131903/New-brn.jpg 640w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/10/12131903/New-brn-600x600.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/10/12131903/New-brn-100x100.jpg 100w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/10/12131903/New-brn-64x64.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/10/12131903/New-brn-300x300.jpg 300w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/10/12131903/New-brn-150x150.jpg 150w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/10/12131903/New-brn-50x50.jpg 50w" alt="A luxurious white wicker basket brimming with premium baby essentials, including a charming blue teddy bear, delightful baby clothes, a cozy polka dot blanket, and elegant bottles of Absorba baby care products. The scene exudes sophistication with its decorative blue balloons and delicate ribbons, perfectly complemented by the brand's signature Basketeer logo elegantly displayed on the accompanying ribbon. Nestled against an opulent marble background, a single pristine blue rose adds the final touch of refinement to this sumptuous display.">
                            </a>
                    <h4 class="categoryTitle">
                        <a href="https://basketeer.com/product-category/kids-and-babies/new-born-gift-baskets-hampers/">NEW BORN BABIES</a>
                    </h4>
                </div>
                <div class="text-center categoryItem">
                    <a href="https://basketeer.com/product-category/flower-gifts/">
                                <img width="100%" height="100%" class="categoryImage" decoding="async" loading="lazy" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/26090241/Christmas-Flower-Vase-v1.webp" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/26090241/Christmas-Flower-Vase-v1.webp 960w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/26090241/Christmas-Flower-Vase-v1-262x300.webp 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/26090241/Christmas-Flower-Vase-v1-894x1024.webp 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/26090241/Christmas-Flower-Vase-v1-768x880.webp 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/26090241/Christmas-Flower-Vase-v1-600x688.webp 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/26090241/Christmas-Flower-Vase-v1-64x73.webp 64w" alt="FLOWER GIFTS">
                            </a>
                    <h4 class="categoryTitle">
                        <a href="https://basketeer.com/product-category/flower-gifts/">FLOWER GIFTS</a>
                    </h4>
                </div>
                <div class="text-center categoryItem">
                    <a href="https://basketeer.com/product-category/kids-and-babies/">
                                <img width="100%" height="100%" class="categoryImage" decoding="async" loading="lazy" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/24170716/Kid-Gifts.jpg" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/24170716/Kid-Gifts.jpg 960w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/24170716/Kid-Gifts-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/24170716/Kid-Gifts-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/24170716/Kid-Gifts-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/24170716/Kid-Gifts-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/24170716/Kid-Gifts-768x880.jpg 768w" alt="A young girl in a peach and pink dress holds a large number 5 balloon beside a swan-themed cake table. Pink and clear balloons with confetti adorn the scene, creating a festive backdrop against the pink wall. This delightful celebration could be featured on any homepage of joy.">
                            </a>
                    <h4 class="categoryTitle">
                        <a href="https://basketeer.com/product-category/kids-and-babies/">Kid and Baby Gifts</a>
                    </h4>
                </div>
                <div class="text-center categoryItem">
                    <a href="https://basketeer.com/product-category/combo-gifts/">
                                <img width="100%" height="100%" class="categoryImage" decoding="async" loading="lazy" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/22101908/Combo.jpg" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/22101908/Combo.jpg 960w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/22101908/Combo-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/22101908/Combo-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/22101908/Combo-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/22101908/Combo-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/22101908/Combo-768x880.jpg 768w" alt="A woman in a pink dress sits on the floor, smiling. She holds a large teddy bear and a bouquet of pink roses wrapped in white paper. Behind her, there is a bunch of pink heart-shaped balloons. The background is a plain light grey.">
                            </a>
                    <h4 class="categoryTitle">
                        <a href="https://basketeer.com/product-category/combo-gifts/">COMBO GIFTS</a>
                    </h4>
                </div>
                <div class="text-center categoryItem">
                    <a href="https://basketeer.com/product-category/balloon-gifts/">
                                <img width="100%" height="100%" class="categoryImage" decoding="async" loading="lazy" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/22102727/Balloon.jpg" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/22102727/Balloon.jpg 960w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/22102727/Balloon-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/22102727/Balloon-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/22102727/Balloon-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/22102727/Balloon-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/22102727/Balloon-768x880.jpg 768w" alt="A person with long dark hair and a black outfit holds a bunch of shiny red heart-shaped balloons, partially obscuring their face. The background is plain and light-colored, contrasting with the vibrant balloons.">
                            </a>
                    <h4 class="categoryTitle">
                        <a href="https://basketeer.com/product-category/balloon-gifts/">BALLOON GIFTS</a>
                    </h4>
                </div>
                <div class="text-center categoryItem">
                    <a href="https://basketeer.com/product-category/flower-gifts/plant-gifts/">
                                <img width="100%" height="100%" class="categoryImage" decoding="async" loading="lazy" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/10/11185535/Plant-Gifts-1-1.jpg" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/10/11185535/Plant-Gifts-1-1.jpg 777w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/10/11185535/Plant-Gifts-1-1-600x686.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/10/11185535/Plant-Gifts-1-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/10/11185535/Plant-Gifts-1-1-263x300.jpg 263w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/10/11185535/Plant-Gifts-1-1-768x878.jpg 768w" alt="A luxurious white ceramic pot, adorned with vibrant pink orchids in full bloom, graces a pristine white surface. The radiant flowers are elegantly supported by green stakes, exuding an aura of refined beauty. Scattered blossoms and delicate petals embellish the surrounding area, adding a touch of organic charm to the scene. Positioned against an elegant paneled wall, this exquisite arrangement epitomizes sophistication and style. A subtle yet distinguished Basketeer ribbon gracefully wraps around the pot, lending an exclusive touch to this enchanting display from Basketeer’s elite collection.">
                            </a>
                    <h4 class="categoryTitle">
                        <a href="https://basketeer.com/product-category/flower-gifts/plant-gifts/">PLANTS & GIFTS</a>
                    </h4>
                </div>
            </div>
            <div class="text-center d-lg-none">
                <a href="https://basketeer.com/shop" class="d-inline-block btnBlack">View All</a>
            </div>
        </div>
    </section>
    <div class="mb-3 container-fluid">
        <div class="m-3 m-md-0 cta">
            <div class="row">
                <div class="order-1 order-lg-2 p-0 cta-image col-12 col-lg-6" style="background-image:url(https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/10141500/Mums-Promo-Banner.jpg"></div>
                <div class="overlap-right d-flex align-items-center order-2 order-lg-1 my-0 my-lg-4 cta-text col-12 col-lg-6" style="background-color: #f7f7f7;">
                    <div class="p-4">
                        <h2 class="bsk-italic text-sm-start text-center">Mother's Day Promotions!</h2>
                        <p class="text-sm-start text-center">Shop our Mother’s Day collection and enjoy <strong>EXCLUSIVE DISCOUNTS</strong>, plus <strong>FREE DELIVERY</strong> in Bangkok on qualifying orders. </p>
                        <div class="d-flex flex-column flex-sm-row mb-4 text-center">
                            <div class="m-2 ms-xl-0 p-3" style="color: #fff; background-color: #A1D8E1;">5% OFF<br> No Minimum Order</div>
                            <div class="m-2 p-3" style="color: #fff; background-color: #A1D8E1;">10% OFF<br> 2 Items or More</div>
                            <div class="m-2 p-3" style="color: #fff; background-color: #aaaaac;">FREE DELIVERY<br> Orders Over 2,500฿</div>
                        </div>
                        <p class="text-center">
                            <a href="https://basketeer.com/promotion/mothers-day-promotions/" class="d-inline-block btnBlack" target="_self"><span>See Promos Here</span></a>
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <!--
https://www.loga.app/line/6263
-->
    </div>
    <section class="popularOccasions" style="background:#ecebeb">
        <div class="container-fluid">
            <div class="text-center popularOccasionsHeader">
                <h2 class="sectionHeading">Popular Occasions</h2>
                <h4 class="mb-3 sectionSubHeading">View Our Most Popular Gifts </h4>
            </div>
            <div class="d-flex justify-content-between mt-5 occasionItems_2 splide">
                <div class="splide__track">
                    <ul class="splide__list">
                        <li class="splide__slide splide__slide_147403_0">
                            <a href="https://basketeer.com/product-category/gift-baskets/mothers-day-gift-baskets/" class="d-block rounded-4" style="overflow: hidden;">
                                <div class="custom-image-wrapper">
                                    <img srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/26090655/Mothers_Day_gifts-v1.webp" sizes="(max-width: 300px) 100vw, 300px" decoding="async" loading="lazy" alt="MOTHER'S DAY" style="width: 100%; aspect-ratio: 6/7; object-fit: cover;">
                                </div>

                                <div class="p-4">
                                    <h3 class="fs-6 ff-head line-2">MOTHER'S DAY</h3>
                                    <p class="m-0 ff-body line-2">Send love to mum, for best mum EVER!</p>
                                </div>
                            </a>
                        </li>
                        <style>
                            .splide__slide_147403_0 h3,
                            .splide__slide_147403_0 p {
                                color: #222222;
                            }

                            .splide__slide_147403_0 a {
                                background-color: #b0d4ef;
                            }
                        </style>
                        <li class="splide__slide splide__slide_147403_1">
                            <a href="https://basketeer.com/product-category/gift-baskets/gift-for-her/" class="d-block rounded-4" style="overflow: hidden;">
                                <div class="custom-image-wrapper">
                                    <img srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/26091255/gifts-for-her-8.webp" sizes="(max-width: 300px) 100vw, 300px" decoding="async" loading="lazy" alt="GIFTS FOR HER" style="width: 100%; aspect-ratio: 6/7; object-fit: cover;">
                                </div>

                                <div class="p-4">
                                    <h3 class="fs-6 ff-head line-2">GIFTS FOR HER</h3>
                                    <p class="m-0 ff-body line-2">Find gifts for her - Same-Day Bangkok Delivery</p>
                                </div>
                            </a>
                        </li>
                        <style>
                            .splide__slide_147403_1 h3,
                            .splide__slide_147403_1 p {
                                color: #222222;
                            }

                            .splide__slide_147403_1 a {
                                background-color: #ffffff;
                            }
                        </style>
                        <li class="splide__slide splide__slide_147403_2">
                            <a href="https://basketeer.com/product-category/gift-baskets/birthday-gifts/" class="d-block rounded-4" style="overflow: hidden;">
                                <div class="custom-image-wrapper">
                                    <img srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/05/17084238/25-04-23-Group-Cake2979.jpg" sizes="(max-width: 300px) 100vw, 300px" decoding="async" loading="lazy" alt="Birthday sponge cake on a pink and blue table and background with hands holding up a knife and fork with a strawberry on."
                                        style="width: 100%; aspect-ratio: 6/7; object-fit: cover;">
                                </div>

                                <div class="p-4">
                                    <h3 class="fs-6 ff-head line-2">BIRTHDAY GIFTS </h3>
                                    <p class="m-0 ff-body line-2">Premium Birthday Gifts with Same-Day Delivery in Bankgok</p>
                                </div>
                            </a>
                        </li>
                        <style>
                            .splide__slide_147403_2 h3,
                            .splide__slide_147403_2 p {
                                color: #222222;
                            }

                            .splide__slide_147403_2 a {
                                background-color: #ffffff;
                            }
                        </style>
                        <li class="splide__slide splide__slide_147403_3">
                            <a href="https://basketeer.com/product-category/gift-baskets/gift-for-him/" class="d-block rounded-4" style="overflow: hidden;">
                                <div class="custom-image-wrapper">
                                    <img srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/26090955/BIRTHDAY-GIFTS-v1.webp" sizes="(max-width: 300px) 100vw, 300px" decoding="async" loading="lazy" alt="GIFTS FOR HIM" style="width: 100%; aspect-ratio: 6/7; object-fit: cover;">
                                </div>

                                <div class="p-4">
                                    <h3 class="fs-6 ff-head line-2">GIFTS FOR HIM</h3>
                                    <p class="m-0 ff-body line-2">Perfect Gifts for Him - Same-Day Bangkok Delivery</p>
                                </div>
                            </a>
                        </li>
                        <style>
                            .splide__slide_147403_3 h3,
                            .splide__slide_147403_3 p {
                                color: #222222;
                            }

                            .splide__slide_147403_3 a {
                                background-color: #ffffff;
                            }
                        </style>
                        <li class="splide__slide splide__slide_147403_4">
                            <a href="https://basketeer.com/product-category/gift-baskets/anniversary-gifts/" class="d-block rounded-4" style="overflow: hidden;">
                                <div class="custom-image-wrapper">
                                    <img srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/26090823/Anniversary-Gifts-v1.webp" sizes="(max-width: 300px) 100vw, 300px" decoding="async" loading="lazy" alt="ANNIVERSARY GIFTS" style="width: 100%; aspect-ratio: 6/7; object-fit: cover;">
                                </div>

                                <div class="p-4">
                                    <h3 class="fs-6 ff-head line-2">ANNIVERSARY GIFTS</h3>
                                    <p class="m-0 ff-body line-2">Thoughtful anniversary gifts for him and her </p>
                                </div>
                            </a>
                        </li>
                        <style>
                            .splide__slide_147403_4 h3,
                            .splide__slide_147403_4 p {
                                color: #ffffff;
                            }

                            .splide__slide_147403_4 a {
                                background-color: #eababa;
                            }
                        </style>
                        <li class="splide__slide splide__slide_147403_5">
                            <a href="https://basketeer.com/product-category/gift-baskets/surprise-gifts/" class="d-block rounded-4" style="overflow: hidden;">
                                <div class="custom-image-wrapper">
                                    <img srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/04/02165822/Gifts-For-Her.jpg" sizes="(max-width: 300px) 100vw, 300px" decoding="async" loading="lazy" alt="Soft Pink Floral Bouquet With Heart Balloons Fiesta Gift SetSmiling woman holding a pink rose bouquet and pink heart-shaped balloons"
                                        style="width: 100%; aspect-ratio: 6/7; object-fit: cover;">
                                </div>

                                <div class="p-4">
                                    <h3 class="fs-6 ff-head line-2">SURPRISE GIFTS</h3>
                                    <p class="m-0 ff-body line-2">Unique Surprise Gifts for Every Special Moment</p>
                                </div>
                            </a>
                        </li>
                        <style>
                            .splide__slide_147403_5 h3,
                            .splide__slide_147403_5 p {
                                color: #222222;
                            }

                            .splide__slide_147403_5 a {
                                background-color: #ffffff;
                            }
                        </style>
                        <li class="splide__slide splide__slide_147403_6">
                            <a href="https://basketeer.com/product-category/gift-baskets/get-well-soon-gift-baskets/" class="d-block rounded-4" style="overflow: hidden;">
                                <div class="custom-image-wrapper">
                                    <img srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/05/02114001/Get-Well-Soon-Fruits.jpg" sizes="(max-width: 300px) 100vw, 300px" decoding="async" loading="lazy" alt="White wicker basket with fresh fruits, white-green flowers, and Get Well Soon balloon on a white background"
                                        style="width: 100%; aspect-ratio: 6/7; object-fit: cover;">
                                </div>

                                <div class="p-4">
                                    <h3 class="fs-6 ff-head line-2">GET WELL SOON</h3>
                                    <p class="m-0 ff-body line-2">Send your warmest wishes with Basketeer’s Get Well Soon gifts</p>
                                </div>
                            </a>
                        </li>
                        <style>
                            .splide__slide_147403_6 h3,
                            .splide__slide_147403_6 p {
                                color: #222222;
                            }

                            .splide__slide_147403_6 a {
                                background-color: #ffffff;
                            }
                        </style>
                        <li class="splide__slide splide__slide_147403_7">
                            <a href="https://basketeer.com/product-category/gift-baskets/new-home-gifts/" class="d-block rounded-4" style="overflow: hidden;">
                                <div class="custom-image-wrapper">
                                    <img srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/05/07101438/IM22-056.jpg" sizes="(max-width: 300px) 100vw, 300px" decoding="async" loading="lazy" alt="New Home Gifts" style="width: 100%; aspect-ratio: 6/7; object-fit: cover;">
                                </div>

                                <div class="p-4">
                                    <h3 class="fs-6 ff-head line-2">NEW HOME GIFTS</h3>
                                    <p class="m-0 ff-body line-2">Celebrate new beginnings with Basketeer’s New Home Gifts</p>
                                </div>
                            </a>
                        </li>
                        <style>
                            .splide__slide_147403_7 h3,
                            .splide__slide_147403_7 p {
                                color: #222222;
                            }

                            .splide__slide_147403_7 a {
                                background-color: #ffffff;
                            }
                        </style>
                        <li class="splide__slide splide__slide_147403_8">
                            <a href="https://basketeer.com/product-category/gift-baskets/new-borns/" class="d-block rounded-4" style="overflow: hidden;">
                                <div class="custom-image-wrapper">
                                    <img srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/05/07101808/BB23-021-1.jpg" sizes="(max-width: 300px) 100vw, 300px" decoding="async" loading="lazy" alt="A wicker basket filled with baby care items and soft blue and white towels, topped with pastel balloons—perfect for celebrating popular occasions. The "
                                        Basketeer " logo appears in the bottom left corner, ideal for any homepage display." style="width: 100%; aspect-ratio: 6/7; object-fit: cover;">
                                </div>

                                <div class="p-4">
                                    <h3 class="fs-6 ff-head line-2">NEW BORN GIFTS</h3>
                                    <p class="m-0 ff-body line-2">Celebrate new beginnings with our Newborn Gift Baskets—featuring baby clothes, toys, and essentials in luxurious, ready-to-gift sets.</p>
                                </div>
                            </a>
                        </li>
                        <style>
                            .splide__slide_147403_8 h3,
                            .splide__slide_147403_8 p {
                                color: #ffffff;
                            }

                            .splide__slide_147403_8 a {
                                background-color: #b0d4ef;
                            }
                        </style>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function($) {
            new Splide('.occasionItems_2', {
                type: "loop",
                perPage: 5,
                perMove: 1,
                updateOnMove: true,
                pagination: false,
                throttle: 300,
                gap: 15,
                trimSpace: false,
                rewind: true,
                arrows: {
                    prev: '<button class="prv"><i class="bi-chevron-left bi"></i></button>',
                    next: '<button class="nxt"><i class="bi-chevron-right bi"></i></button>'
                },
                breakpoints: {
                    991: {
                        perPage: 3,
                    },
                    767: {
                        perPage: 2,
                    },
                    575: {
                        arrows: false,
                        drag: "free",
                        pagination: true,
                        fixedWidth: 300,
                        trimSpace: false,
                        focus: "center",
                        snap: true,
                        gap: 10
                    },
                }
            }).mount();
        });
    </script>
    <section>
        <div class="container-fluid">
            <div class="mb-4 text-center">
                <h2 class="sectionHeading">New Arrivals</h2>
                <h4 class="sectionSubHeading">Check Out Our New Arrivals </h4>
            </div>
            <div class="d-flex justify-content-between mt-3 occasionItems2 splide_el splide basketeer_splide_1014006974">
                <div class="splide__track">

                    <ul class="splide__list">
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/congratulations-flowers/blush-symphony-vase-arrangement/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/19154454/FLV25-040-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/19154454/FLV25-040-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/19154454/FLV25-040-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/19154454/FLV25-040-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/19154454/FLV25-040-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/19154454/FLV25-040.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Elegant vase arrangement with pink lilies, roses, gerbera daisies, and hydrangeas in a white ceramic vase with gold accents." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Elegant vase arrangement with pink lilies, roses, gerbera daisies, and hydrangeas in a white ceramic vase with gold accents." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FLV25-040</p>

                                        <button onclick="addToCart(291231)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/congratulations-flowers/blush-symphony-vase-arrangement/">Blush Symphony Vase Arrangement</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>3,950.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/flowers-in-vases/crimson-elegance-vase/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/19140017/40Kvwmtk-262x300.jpeg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/19140017/40Kvwmtk-894x1024.jpeg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/19140017/40Kvwmtk-768x880.jpeg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/19140017/40Kvwmtk-600x688.jpeg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/19140017/40Kvwmtk-64x73.jpeg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/19140017/40Kvwmtk.jpeg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="White vase filled with deep red roses and greenery, styled in a romantic luxury floral arrangement." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="White vase filled with deep red roses and greenery, styled in a romantic luxury floral arrangement." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FLV25-013</p>

                                        <button onclick="addToCart(291196)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/flowers-in-vases/crimson-elegance-vase/">Crimson Elegance Vase</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>4,300.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/flowers-in-vases/serenity-bloom-vase/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18185222/Rl8SLYs8-262x300.jpeg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18185222/Rl8SLYs8-894x1024.jpeg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18185222/Rl8SLYs8-768x880.jpeg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18185222/Rl8SLYs8-600x688.jpeg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18185222/Rl8SLYs8-64x73.jpeg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18185222/Rl8SLYs8.jpeg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Luxury vase with white and cream roses, blue hydrangeas, and white stock, arranged in a round glass vase with ribbon detail." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Luxury vase with white and cream roses, blue hydrangeas, and white stock, arranged in a round glass vase with ribbon detail." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FLV25-012</p>

                                        <button onclick="addToCart(291152)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/flowers-in-vases/serenity-bloom-vase/">Serenity Bloom Vase</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>6,950.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/flowers-in-vases/elegant-red-rose-vase/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18184606/FLV25-011-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18184606/FLV25-011-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18184606/FLV25-011-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18184606/FLV25-011-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18184606/FLV25-011-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18184606/FLV25-011.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Luxury vase with deep red roses and pink astilbe, accented with greenery for an elegant floral arrangement." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Luxury vase with deep red roses and pink astilbe, accented with greenery for an elegant floral arrangement." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FLV25-011</p>

                                        <button onclick="addToCart(291150)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/flowers-in-vases/elegant-red-rose-vase/">Elegant Red Rose Vase</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>5,750.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/flowers-in-vases/291126/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18174149/FLV25-010-1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18174149/FLV25-010-1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18174149/FLV25-010-1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18174149/FLV25-010-1-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18174149/FLV25-010-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18174149/FLV25-010-1.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Close-up of peach roses with pink astilbe and greenery in a luxury floral vase arrangement." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Close-up of peach roses with pink astilbe and greenery in a luxury floral vase arrangement." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FLV25-010</p>

                                        <button onclick="addToCart(291126)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/flowers-in-vases/291126/">Peach Whisper Vase Arrangement</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>6,200.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/flowers-in-vases/blush-harmony-vase-arrangement/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18173947/2REIbYRY-262x300.jpeg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18173947/2REIbYRY-894x1024.jpeg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18173947/2REIbYRY-768x880.jpeg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18173947/2REIbYRY-600x688.jpeg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18173947/2REIbYRY-64x73.jpeg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18173947/2REIbYRY.jpeg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Wide shot of a luxury vase with pastel roses, lisianthus, and white stock in cream and blush tones, styled with fresh greenery." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Wide shot of a luxury vase with pastel roses, lisianthus, and white stock in cream and blush tones, styled with fresh greenery." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FLV25-009</p>

                                        <button onclick="addToCart(291125)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/flowers-in-vases/blush-harmony-vase-arrangement/">Blush Harmony Vase Arrangement</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>4,100.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/flowers-in-vases/golden-toffee-elegance-vase/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18150913/FLV25-019-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18150913/FLV25-019-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18150913/FLV25-019-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18150913/FLV25-019-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18150913/FLV25-019-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18150913/FLV25-019.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Luxurious vase with toffee roses in warm orange-brown tones, styled with silver foliage and greenery for an elegant autumn look" decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Luxurious vase with toffee roses in warm orange-brown tones, styled with silver foliage and greenery for an elegant autumn look" decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FLV25-019</p>

                                        <button onclick="addToCart(291058)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/flowers-in-vases/golden-toffee-elegance-vase/">Golden Toffee Elegance Vase</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>5,190.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/flowers-in-vases/soft-grace-vase-arrangement/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18141145/FLV25-008-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18141145/FLV25-008-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18141145/FLV25-008-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18141145/FLV25-008-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18141145/FLV25-008-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18141145/FLV25-008.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Elegant vase with dusty pink roses, white calla lilies, carnations, and lush greenery, arranged in a graceful romantic style." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Elegant vase with dusty pink roses, white calla lilies, carnations, and lush greenery, arranged in a graceful romantic style." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FLV25-008</p>

                                        <button onclick="addToCart(291059)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/flowers-in-vases/soft-grace-vase-arrangement/">Soft Grace Vase Arrangement</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>5,300.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/flowers-in-vases/elegant-sunrise-vase-arrangement/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18140920/FLV25-007-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18140920/FLV25-007-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18140920/FLV25-007-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18140920/FLV25-007-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18140920/FLV25-007-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18140920/FLV25-007.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="ase with yellow roses, peach roses, white stock, and green lisianthus, styled in a fresh and cheerful floral design." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="ase with yellow roses, peach roses, white stock, and green lisianthus, styled in a fresh and cheerful floral design." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FLV25-007</p>

                                        <button onclick="addToCart(291048)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/flowers-in-vases/elegant-sunrise-vase-arrangement/">Elegant Sunrise Vase Arrangement</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>4,790.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/flowers-in-vases/ivory-serenity-vase-arrangement/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18140503/FLV25-006-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18140503/FLV25-006-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18140503/FLV25-006-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18140503/FLV25-006-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18140503/FLV25-006-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/18140503/FLV25-006.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Tall white vase with cream roses, yellow snapdragons, and white stock flowers arranged in an elegant and fresh floral design." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Tall white vase with cream roses, yellow snapdragons, and white stock flowers arranged in an elegant and fresh floral design." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FLV25-006</p>

                                        <button onclick="addToCart(291044)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/flowers-in-vases/ivory-serenity-vase-arrangement/">Ivory Serenity Vase Arrangement</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>5,890.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/mothers-day-bakery-gifts/mini-coconut-jelly-dessert-set-for-mums-special-day/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/08101118/Mother-day-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/08101118/Mother-day-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/08101118/Mother-day-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/08101118/Mother-day-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/08101118/Mother-day-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/08101118/Mother-day.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Mother’s Day floral jelly cups in pink and blue, decorated with jasmine garlands and roses, with greeting card and fresh garland beside" decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Mother’s Day floral jelly cups in pink and blue, decorated with jasmine garlands and roses, with greeting card and fresh garland beside" decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CKS25-078</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/mothers-day-bakery-gifts/mini-coconut-jelly-dessert-set-for-mums-special-day/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/mothers-day-bakery-gifts/mini-coconut-jelly-dessert-set-for-mums-special-day/">Mini Coconut Jelly Dessert Set for Mum’s Special Day</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>890.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/mothers-day-bakery-gifts/coconut-jasmine-flower-jelly-set-for-mum/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/07092119/CKS25-076.3-1-262x300.jpeg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/07092119/CKS25-076.3-1-894x1024.jpeg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/07092119/CKS25-076.3-1-768x880.jpeg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/07092119/CKS25-076.3-1-600x688.jpeg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/07092119/CKS25-076.3-1-64x73.jpeg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/07092119/CKS25-076.3-1.jpeg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Pink and blue coconut jelly decorated with white jasmine flowers and green leaves, paired with a fresh jasmine garland for Mother’s Day." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Pink and blue coconut jelly decorated with white jasmine flowers and green leaves, paired with a fresh jasmine garland for Mother’s Day." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CKS25-076</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/mothers-day-bakery-gifts/coconut-jasmine-flower-jelly-set-for-mum/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/mothers-day-bakery-gifts/coconut-jasmine-flower-jelly-set-for-mum/">Coconut Jasmine Flower Jelly Set for Mum</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>890.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/mothers-day-bakery-gifts/chocolate-strawberries-with-jasmine-garland-gift-for-mum/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/07091642/CKS25-075-1-262x300.jpeg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/07091642/CKS25-075-1-894x1024.jpeg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/07091642/CKS25-075-1-768x880.jpeg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/07091642/CKS25-075-1-600x688.jpeg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/07091642/CKS25-075-1-64x73.jpeg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/07091642/CKS25-075-1.jpeg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Gift box of 12 blue chocolate-covered strawberries with drizzle, lattice, and heart designs, paired with fresh jasmine garland." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Gift box of 12 blue chocolate-covered strawberries with drizzle, lattice, and heart designs, paired with fresh jasmine garland." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CKS25-075</p>

                                        <button onclick="addToCart(289629)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/mothers-day-bakery-gifts/chocolate-strawberries-with-jasmine-garland-gift-for-mum/">Chocolate Strawberries with Jasmine Garland – Gift for Mum</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>3,590.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/new-arrival-bakery-gifts/chocolate%e2%80%91covered-strawberries-mothers-day-gift-box/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/07143532/CKS25-074.4-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/07143532/CKS25-074.4-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/07143532/CKS25-074.4-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/07143532/CKS25-074.4-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/07143532/CKS25-074.4-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/07143532/CKS25-074.4.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Angled view of 12 blue chocolate-covered strawberries in gift box with drizzle, lattice, and white heart designs." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Angled view of 12 blue chocolate-covered strawberries in gift box with drizzle, lattice, and white heart designs." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CKS25-074</p>

                                        <button onclick="addToCart(289620)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/new-arrival-bakery-gifts/chocolate%e2%80%91covered-strawberries-mothers-day-gift-box/">Chocolate‑Covered Strawberries – Mother’s Day Gift Box</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>1,250.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/mothers-day-bakery-gifts/mothers-day-edible-photo-vanilla-cake/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/07090621/CKS25-073-1-262x300.jpeg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/07090621/CKS25-073-1-894x1024.jpeg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/07090621/CKS25-073-1-768x880.jpeg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/07090621/CKS25-073-1-600x688.jpeg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/07090621/CKS25-073-1-64x73.jpeg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/07090621/CKS25-073-1.jpeg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Mother’s Day personalised photo buttercream cake with blue and white floral border and “Love You Mum” text." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Mother’s Day personalised photo buttercream cake with blue and white floral border and “Love You Mum” text." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CKS25-073</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/mothers-day-bakery-gifts/mothers-day-edible-photo-vanilla-cake/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/mothers-day-bakery-gifts/mothers-day-edible-photo-vanilla-cake/">Mother’s Day Edible Photo Vanilla Cake</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>2,490.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                    </ul>
                </div>
            </div>
            <div class="mt-3 text-center">
                <a href="https://basketeer.com/product-category/new-arrivals/" class="d-inline-block btnBlack">View All</a>
            </div>
        </div>
    </section>
    <script>
        document.addEventListener("DOMContentLoaded", function($) {
            new Splide('.basketeer_splide_1014006974', {
                perPage: 5,
                perMove: 1,
                flickMaxPages: 3,
                updateOnMove: true,
                pagination: false,
                throttle: 300,
                gap: 16,
                arrows: {
                    prev: '<button class="prv"><i class="bi-chevron-left bi"></i></button>',
                    next: '<button class="nxt"><i class="bi-chevron-right bi"></i></button>'
                },
                breakpoints: {
                    991: {
                        perPage: 3,
                    },
                    767: {
                        perPage: 2,
                    },
                    575: {
                        drag: true,
                        fixedWidth: 170,
                        gap: 10,
                    },
                }
            }).mount();
        })
    </script>
    <section>
        <div class="container-fluid">
            <div class="mb-4 text-center">
                <h2 class="sectionHeading">Formal Hampers</h2>
                <h4 class="sectionSubHeading">Discover Basketeer’s Formal Hamper Collection </h4>
            </div>
            <div class="cta">
                <div class="d-flex flex-column flex-lg-row align-items-center" style="background-color: #f7f7f7;">
                    <div class="order-1 order-lg-2 p-0 cta-image" style="flex: 1;">
                        <img src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/30161805/Formal-Hampers-Executive-Gift-Baskets-Bangkok-Basketeer-1.jpg" alt="Formal Hampers & Executive Gift Baskets" style="aspect-ratio: 100 / 66; object-fit: cover; width: 100%">
                    </div>
                    <div class="order-2 order-lg-1 p-4 text-center cta-text" style="flex: 1;">
                        <h1>Formal Hampers & Executive Gift Baskets</h1>


                        <p class="d-md-block text-short d-none">
                            Discover Basketeer’s Formal Hamper Collection — refined and elegant gifts curated for corporate clients, business partners, and distinguished occasions. Each hamper features premium selections of tea, coffee, and gourmet treats, beautifully presented
                            with same-day delivery in Bangkok and nationwide shipping across Thailand.
                        </p>


                        <p class="d-block text-short d-md-none">
                            Discover Basketeer’s Formal Hamper Collection — refined and elegant gifts curated for corporate clients, business partners, and distinguished occasions. Each hamper features premium selections of tea, coffee, and gourmet treats, beautifully presented
                            with same-day delivery in Bangkok and nationwide shipping across Thailand.
                        </p>

                        <p class="mt-3 mb-0 pt-3">
                            <a href="https://basketeer.com/product-category/gift-baskets/forman-hampers-and-exclusive-gift-baskets/" class="d-inline-block btnBlack">SHOP NOW</a>
                        </p>
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-between mt-3 occasionItems2 splide_el splide basketeer_splide_233016273">
                <div class="splide__track">

                    <ul class="splide__list">
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/gift-baskets/gourmet-indulgence-gift-hamper/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/31092510/GBG25-017-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/31092510/GBG25-017-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/31092510/GBG25-017-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/31092510/GBG25-017-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/31092510/GBG25-017-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/31092510/GBG25-017.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Luxurious gourmet gift hamper featuring tea, cookies, cheese puffs, and marmalade in an elegant blue box." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Luxurious gourmet gift hamper featuring tea, cookies, cheese puffs, and marmalade in an elegant blue box." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">GBG25-017</p>

                                        <button onclick="addToCart(179611)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/gift-baskets/gourmet-indulgence-gift-hamper/">Blue Gourmet Delight Hamper</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>4,310.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/gift-baskets/exclusive-gourmet-food-hamper/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/29141804/GBG25-219-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/29141804/GBG25-219-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/29141804/GBG25-219-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/29141804/GBG25-219-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/29141804/GBG25-219-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/29141804/GBG25-219.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Black wicker gift hamper with tea, gourmet coffee, chocolates, strawberry jam, and sweet treats." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Black wicker gift hamper with tea, gourmet coffee, chocolates, strawberry jam, and sweet treats." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">GBG25-219</p>

                                        <button onclick="addToCart(179406)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/gift-baskets/exclusive-gourmet-food-hamper/">Exclusive Gourmet Food Hamper</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>3,600.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/gift-baskets/premium-indulgence/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26180456/Bci1vycQ-262x300.jpeg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26180456/Bci1vycQ-600x688.jpeg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26180456/Bci1vycQ-64x73.jpeg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26180456/Bci1vycQ-894x1024.jpeg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26180456/Bci1vycQ-768x880.jpeg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26180456/Bci1vycQ.jpeg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="luxurious hamper filled with premium international products, known for their quality and taste." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="luxurious hamper filled with premium international products, known for their quality and taste." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">GBG25-141</p>

                                        <button onclick="addToCart(179131)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/gift-baskets/premium-indulgence/">Premium Indulgence</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>3,689.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/gift-baskets/luxury-treat-basket/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26175841/tguYVMDQ-262x300.jpeg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26175841/tguYVMDQ-600x688.jpeg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26175841/tguYVMDQ-64x73.jpeg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26175841/tguYVMDQ-894x1024.jpeg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26175841/tguYVMDQ-768x880.jpeg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26175841/tguYVMDQ.jpeg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Black woven gift hamper filled with gourmet treats including Ferrero Rocher, Jaffa cakes, sesame breadsticks, Oatside biscuits, champagne, and luxury chocolates." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Black woven gift hamper filled with gourmet treats including Ferrero Rocher, Jaffa cakes, sesame breadsticks, Oatside biscuits, champagne, and luxury chocolates." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">GBG25-142</p>

                                        <button onclick="addToCart(179123)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/gift-baskets/luxury-treat-basket/">Luxury Treat Basket</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>5,200.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/gift-baskets/heartfelt-gift/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26173045/GBG25-131-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26173045/GBG25-131-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26173045/GBG25-131-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26173045/GBG25-131-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26173045/GBG25-131-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26173045/GBG25-131.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A grey basket filled with a variety of gourmet cookies." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A grey basket filled with a variety of gourmet cookies." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">GBG25-131</p>

                                        <button onclick="addToCart(179116)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/gift-baskets/heartfelt-gift/">Classic Harvest Gourmet Gift Bag</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>3,750.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/gift-baskets/the-ultimate-gift/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26163724/GBG25-123-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26163724/GBG25-123-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26163724/GBG25-123-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26163724/GBG25-123-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26163724/GBG25-123-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26163724/GBG25-123.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A grey basket filled with a variety of gourmet food items." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A grey basket filled with a variety of gourmet food items." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">GBG25-123</p>

                                        <button onclick="addToCart(179092)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/gift-baskets/the-ultimate-gift/">The Ultimate Gift</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>2,988.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/gift-baskets/a-gift-to-remember-2/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26162653/GBG25-121-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26162653/GBG25-121-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26162653/GBG25-121-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26162653/GBG25-121-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26162653/GBG25-121-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26162653/GBG25-121.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A black basket filled with a variety of gourmet food items." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A black basket filled with a variety of gourmet food items." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">GBG25-121</p>

                                        <button onclick="addToCart(179087)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/gift-baskets/a-gift-to-remember-2/">Elegant Chocolate &#038; Treats Gift Basket</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>2,050.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/gift-baskets/manly-indulgence-gift/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26160838/GBG25-119-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26160838/GBG25-119-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26160838/GBG25-119-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26160838/GBG25-119-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26160838/GBG25-119-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26160838/GBG25-119.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A blue basket filled with a variety of gourmet food items." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A blue basket filled with a variety of gourmet food items." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">GBG25-119</p>

                                        <button onclick="addToCart(179082)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/gift-baskets/manly-indulgence-gift/">Manly Indulgence Gift</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>3,990.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/gift-baskets/thoughtful-gift-basket/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26160256/GBG25-118-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26160256/GBG25-118-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26160256/GBG25-118-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26160256/GBG25-118-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26160256/GBG25-118-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26160256/GBG25-118.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A black basket filled with a variety of gourmet food items." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A black basket filled with a variety of gourmet food items." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">GBG25-118</p>

                                        <button onclick="addToCart(179079)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/gift-baskets/thoughtful-gift-basket/">Thoughtful Gift Basket</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>6,890.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/gift-baskets/executive-essentials/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26151244/GBG25-109-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26151244/GBG25-109-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26151244/GBG25-109-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26151244/GBG25-109-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26151244/GBG25-109-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26151244/GBG25-109.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A gift basket with assorted snacks and beverages." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A gift basket with assorted snacks and beverages." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">GBG25-109</p>

                                        <button onclick="addToCart(179055)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/gift-baskets/executive-essentials/">Executive Essentials</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>3,430.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/gift-baskets/chic-and-classy-gift-box/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26104305/GBG25-092-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26104305/GBG25-092-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26104305/GBG25-092-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26104305/GBG25-092-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26104305/GBG25-092-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/26104305/GBG25-092.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A blue leather-look basket filled with crackers, olives, olive oil, and other gourmet snacks." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A blue leather-look basket filled with crackers, olives, olive oil, and other gourmet snacks." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">GBG25-092</p>

                                        <button onclick="addToCart(179008)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/gift-baskets/chic-and-classy-gift-box/">Chic and Classy Gift Box</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>4,230.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/gift-baskets/delightful-gift-box/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/24203847/VgXCJ3dw-262x300.jpeg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/24203847/VgXCJ3dw-600x688.jpeg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/24203847/VgXCJ3dw-64x73.jpeg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/24203847/VgXCJ3dw-894x1024.jpeg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/24203847/VgXCJ3dw-768x880.jpeg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/24203847/VgXCJ3dw.jpeg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Black gift box filled with premium treats including crackers, English breakfast tea, and Dutch cocoa, tied with a white ribbon." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Black gift box filled with premium treats including crackers, English breakfast tea, and Dutch cocoa, tied with a white ribbon." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">GBG25-076</p>

                                        <button onclick="addToCart(178900)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/gift-baskets/delightful-gift-box/">Plant Kitchen Delights Hamper</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>3,410.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/gift-baskets/a-symphony-of-flavors/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/22153533/GBG25-073-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/22153533/GBG25-073-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/22153533/GBG25-073-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/22153533/GBG25-073-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/22153533/GBG25-073-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/22153533/GBG25-073.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A blue wicker basket filled with a variety of gourmet food items, including coffee, chocolate, and snacks." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A blue wicker basket filled with a variety of gourmet food items, including coffee, chocolate, and snacks." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">GBG25-073</p>

                                        <button onclick="addToCart(178773)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/gift-baskets/a-symphony-of-flavors/">A Symphony of Flavors</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>4,330.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/gift-baskets/gift-of-good-taste/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/22142639/GBG25-069-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/22142639/GBG25-069-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/22142639/GBG25-069-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/22142639/GBG25-069-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/22142639/GBG25-069-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/22142639/GBG25-069.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A festive gift basket featuring a selection of sweet , perfect for sharing with loved ones." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A festive gift basket featuring a selection of sweet , perfect for sharing with loved ones." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">GBG25-069</p>

                                        <button onclick="addToCart(178753)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/gift-baskets/gift-of-good-taste/">Gift of Good Taste Basket</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>3,850.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/gift-baskets/holiday-cheer-hamper/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/17181922/GBG25-028-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/17181922/GBG25-028-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/17181922/GBG25-028-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/17181922/GBG25-028-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/17181922/GBG25-028-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/10/17181922/GBG25-028.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A holiday gift basket containing indulgent food items, perfect for gifting or enjoying yourself." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A holiday gift basket containing indulgent food items, perfect for gifting or enjoying yourself." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">GBG25-028</p>

                                        <button onclick="addToCart(178476)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/gift-baskets/holiday-cheer-hamper/">Holiday Cheer Hamper</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>6,490.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                    </ul>
                </div>
            </div>
            <div class="mt-3 text-center">
                <a href="https://basketeer.com/product-category/gift-baskets/forman-hampers-and-exclusive-gift-baskets/" class="d-inline-block btnBlack">View All</a>
            </div>
        </div>
    </section>
    <script>
        document.addEventListener("DOMContentLoaded", function($) {
            new Splide('.basketeer_splide_233016273', {
                perPage: 5,
                perMove: 1,
                flickMaxPages: 3,
                updateOnMove: true,
                pagination: false,
                throttle: 300,
                gap: 16,
                arrows: {
                    prev: '<button class="prv"><i class="bi-chevron-left bi"></i></button>',
                    next: '<button class="nxt"><i class="bi-chevron-right bi"></i></button>'
                },
                breakpoints: {
                    991: {
                        perPage: 3,
                    },
                    767: {
                        perPage: 2,
                    },
                    575: {
                        drag: true,
                        fixedWidth: 170,
                        gap: 10,
                    },
                }
            }).mount();
        })
    </script>
    <section>
        <div class="container-fluid">
            <div class="mb-4 text-center">
                <h2 class="sectionHeading">Signature Bakery</h2>
                <h4 class="sectionSubHeading">Discover Charlotte Bakery’s signature British Sponge Cake </h4>
            </div>
            <div class="cta cta--banner-summer-bakery-gifts">
                <div class="d-flex flex-column flex-lg-row align-items-center" style="background-color: #545E86;">
                    <div class="order-1 order-lg-2 p-0 cta-image" style="flex: 1;">
                        <img src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/11/04144000/Victoria_Sponge_Cakes_Bangkok_Delivery.jpg" alt="" style="aspect-ratio: 100 / 66; object-fit: cover; width: 100%">
                    </div>
                    <div class="order-2 order-lg-1 p-4 text-center cta-text" style="flex: 1;">
                        <h2 class="bsk-italic">British Sponge Cake – A Taste of Timeless Tradition</h2>

                        <!-- Full paragraph for desktop -->
                        <p class="bsk-body d-md-block text-short d-none">
                            Discover Charlotte Bakery’s signature British Sponge Cake — baked with Grandma Amy’s original recipe and finest ingredients. Soft, buttery, and truly classic — the perfect gift for every special moment.
                        </p>

                        <!-- Short paragraph for mobile -->
                        <p class="bsk-body d-block text-short d-md-none">
                            Discover Charlotte Bakery’s signature British Sponge Cake — baked with Grandma Amy’s original recipe and finest ingredients. Soft, buttery, and truly classic — the perfect gift for every special moment.
                        </p>

                        <p class="mt-3 mb-0 pt-3">
                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/" class="d-inline-block btnBlack">SHOP NOW</a>
                        </p>
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-between mt-3 occasionItems2 splide_el splide basketeer_splide_202087111">
                <div class="splide__track">

                    <ul class="splide__list">
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/traditional-victoria-sponge-cake/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07095825/Charlotte-Bakery-Victoria-Sponge-Cake-Whole-Bangkok-BK-1001-1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07095825/Charlotte-Bakery-Victoria-Sponge-Cake-Whole-Bangkok-BK-1001-1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07095825/Charlotte-Bakery-Victoria-Sponge-Cake-Whole-Bangkok-BK-1001-1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07095825/Charlotte-Bakery-Victoria-Sponge-Cake-Whole-Bangkok-BK-1001-1-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07095825/Charlotte-Bakery-Victoria-Sponge-Cake-Whole-Bangkok-BK-1001-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07095825/Charlotte-Bakery-Victoria-Sponge-Cake-Whole-Bangkok-BK-1001-1.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Charlotte Bakery Victoria Sponge Cake whole Bangkok" decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Charlotte Bakery Victoria Sponge Cake whole Bangkok" decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">BK-1001</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/traditional-victoria-sponge-cake/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/traditional-victoria-sponge-cake/">Traditional Victoria Sponge Cake</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>1,090.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/chocolate-raspberry-ganache-sponge-cake/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07095303/Charlotte-Bakery-Chocolate-Raspberry-Ganache-Sponge-Cake-Whole-Bangkok-BK-1003-1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07095303/Charlotte-Bakery-Chocolate-Raspberry-Ganache-Sponge-Cake-Whole-Bangkok-BK-1003-1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07095303/Charlotte-Bakery-Chocolate-Raspberry-Ganache-Sponge-Cake-Whole-Bangkok-BK-1003-1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07095303/Charlotte-Bakery-Chocolate-Raspberry-Ganache-Sponge-Cake-Whole-Bangkok-BK-1003-1-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07095303/Charlotte-Bakery-Chocolate-Raspberry-Ganache-Sponge-Cake-Whole-Bangkok-BK-1003-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07095303/Charlotte-Bakery-Chocolate-Raspberry-Ganache-Sponge-Cake-Whole-Bangkok-BK-1003-1.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Charlotte Bakery Chocolate Raspberry Ganache Sponge Cake whole Bangkok" decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Charlotte Bakery Chocolate Raspberry Ganache Sponge Cake whole Bangkok" decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">BK-1003</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/chocolate-raspberry-ganache-sponge-cake/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/chocolate-raspberry-ganache-sponge-cake/">Chocolate Raspberry Ganache Sponge Cake</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>1,990.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/raspberry-and-almond-sponge-cake/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07095737/Charlotte-Bakery-Raspberry-Almond-Sponge-Cake-Whole-Bangkok-BK-1002-1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07095737/Charlotte-Bakery-Raspberry-Almond-Sponge-Cake-Whole-Bangkok-BK-1002-1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07095737/Charlotte-Bakery-Raspberry-Almond-Sponge-Cake-Whole-Bangkok-BK-1002-1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07095737/Charlotte-Bakery-Raspberry-Almond-Sponge-Cake-Whole-Bangkok-BK-1002-1-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07095737/Charlotte-Bakery-Raspberry-Almond-Sponge-Cake-Whole-Bangkok-BK-1002-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07095737/Charlotte-Bakery-Raspberry-Almond-Sponge-Cake-Whole-Bangkok-BK-1002-1.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Charlotte Bakery Raspberry and Almond Sponge Cake whole Bangkok" decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Charlotte Bakery Raspberry and Almond Sponge Cake whole Bangkok" decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">BK-1002</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/raspberry-and-almond-sponge-cake/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/raspberry-and-almond-sponge-cake/">Raspberry &amp; Almond Sponge Cake</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>1,490.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/lemon-cream-cheese-sponge-cake/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07095019/Charlotte-Bakery-Lemon-Passion-Fruit-Sponge-Cake-Whole-Bangkok-BK-1004-1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07095019/Charlotte-Bakery-Lemon-Passion-Fruit-Sponge-Cake-Whole-Bangkok-BK-1004-1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07095019/Charlotte-Bakery-Lemon-Passion-Fruit-Sponge-Cake-Whole-Bangkok-BK-1004-1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07095019/Charlotte-Bakery-Lemon-Passion-Fruit-Sponge-Cake-Whole-Bangkok-BK-1004-1-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07095019/Charlotte-Bakery-Lemon-Passion-Fruit-Sponge-Cake-Whole-Bangkok-BK-1004-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07095019/Charlotte-Bakery-Lemon-Passion-Fruit-Sponge-Cake-Whole-Bangkok-BK-1004-1.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Charlotte Bakery Lemon and Passion Fruit Sponge Cake whole Bangkok" decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Charlotte Bakery Lemon and Passion Fruit Sponge Cake whole Bangkok" decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">BK-1004</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/lemon-cream-cheese-sponge-cake/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/lemon-cream-cheese-sponge-cake/">Lemon Cream-Cheese Sponge Cake</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>1,190.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/cherry-bakewell-almond-sponge-cake/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07094729/Charlotte-Bakery-Cherry-Bakewell-Sponge-Cake-Whole-Bangkok-BK-1005-1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07094729/Charlotte-Bakery-Cherry-Bakewell-Sponge-Cake-Whole-Bangkok-BK-1005-1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07094729/Charlotte-Bakery-Cherry-Bakewell-Sponge-Cake-Whole-Bangkok-BK-1005-1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07094729/Charlotte-Bakery-Cherry-Bakewell-Sponge-Cake-Whole-Bangkok-BK-1005-1-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07094729/Charlotte-Bakery-Cherry-Bakewell-Sponge-Cake-Whole-Bangkok-BK-1005-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07094729/Charlotte-Bakery-Cherry-Bakewell-Sponge-Cake-Whole-Bangkok-BK-1005-1.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Charlotte Bakery Cherry Bakewell Sponge Cake whole Bangkok" decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Charlotte Bakery Cherry Bakewell Sponge Cake whole Bangkok" decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">BK-1005</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/cherry-bakewell-almond-sponge-cake/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/cherry-bakewell-almond-sponge-cake/">Cherry Bakewell Almond Sponge Cake</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>1,150.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/adapted-strawberry-victoria-sponge-cake/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07093855/Charlotte-Bakery-Strawberry-Victoria-Sponge-Cake-Whole-Bangkok-BK-1008-1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07093855/Charlotte-Bakery-Strawberry-Victoria-Sponge-Cake-Whole-Bangkok-BK-1008-1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07093855/Charlotte-Bakery-Strawberry-Victoria-Sponge-Cake-Whole-Bangkok-BK-1008-1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07093855/Charlotte-Bakery-Strawberry-Victoria-Sponge-Cake-Whole-Bangkok-BK-1008-1-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07093855/Charlotte-Bakery-Strawberry-Victoria-Sponge-Cake-Whole-Bangkok-BK-1008-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07093855/Charlotte-Bakery-Strawberry-Victoria-Sponge-Cake-Whole-Bangkok-BK-1008-1.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Charlotte Bakery Strawberry Victoria Sponge Cake whole Bangkok" decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Charlotte Bakery Strawberry Victoria Sponge Cake whole Bangkok" decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">BK-1008</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/adapted-strawberry-victoria-sponge-cake/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/adapted-strawberry-victoria-sponge-cake/">Adapted Strawberry Victoria Sponge Cake</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>1,850.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/frosted-carrot-sponge-cake/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07094436/Charlotte-Bakery-Carrot-Cake-Cream-Cheese-Frosting-Whole-Bangkok-BK-1006-1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07094436/Charlotte-Bakery-Carrot-Cake-Cream-Cheese-Frosting-Whole-Bangkok-BK-1006-1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07094436/Charlotte-Bakery-Carrot-Cake-Cream-Cheese-Frosting-Whole-Bangkok-BK-1006-1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07094436/Charlotte-Bakery-Carrot-Cake-Cream-Cheese-Frosting-Whole-Bangkok-BK-1006-1-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07094436/Charlotte-Bakery-Carrot-Cake-Cream-Cheese-Frosting-Whole-Bangkok-BK-1006-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07094436/Charlotte-Bakery-Carrot-Cake-Cream-Cheese-Frosting-Whole-Bangkok-BK-1006-1.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Charlotte Bakery Carrot Cake with Cream Cheese Frosting whole Bangkok" decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Charlotte Bakery Carrot Cake with Cream Cheese Frosting whole Bangkok" decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">BK-1006</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/frosted-carrot-sponge-cake/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/frosted-carrot-sponge-cake/">Frosted Carrot Sponge Cake</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>1,090.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/sues-classic-coffee-sponge-cake/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07094141/Charlotte-Bakery-Coffee-Walnut-Sponge-Cake-Whole-Bangkok-BK-1007-1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07094141/Charlotte-Bakery-Coffee-Walnut-Sponge-Cake-Whole-Bangkok-BK-1007-1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07094141/Charlotte-Bakery-Coffee-Walnut-Sponge-Cake-Whole-Bangkok-BK-1007-1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07094141/Charlotte-Bakery-Coffee-Walnut-Sponge-Cake-Whole-Bangkok-BK-1007-1-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07094141/Charlotte-Bakery-Coffee-Walnut-Sponge-Cake-Whole-Bangkok-BK-1007-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/07094141/Charlotte-Bakery-Coffee-Walnut-Sponge-Cake-Whole-Bangkok-BK-1007-1.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Charlotte Bakery Coffee Walnut Sponge Cake whole Bangkok" decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Charlotte Bakery Coffee Walnut Sponge Cake whole Bangkok" decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">BK-1007</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/sues-classic-coffee-sponge-cake/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/sues-classic-coffee-sponge-cake/">Sue’s Classic Coffee Sponge Cake</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>1,290.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/classic-cakes/raspberry-buttercream-sponge-cake/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/05/29093122/CKS25-042-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/05/29093122/CKS25-042-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/05/29093122/CKS25-042-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/05/29093122/CKS25-042-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/05/29093122/CKS25-042-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/05/29093122/CKS25-042.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Two-layer vanilla sponge cake filled and topped with buttercream and fresh raspberries, in naked cake style." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Two-layer vanilla sponge cake filled and topped with buttercream and fresh raspberries, in naked cake style." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CKS25-042</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/classic-cakes/raspberry-buttercream-sponge-cake/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/classic-cakes/raspberry-buttercream-sponge-cake/">Raspberry Buttercream Sponge Cake</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>1,290.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                    </ul>
                </div>
            </div>
            <div class="mt-3 text-center">
                <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/signature-bakery/" class="d-inline-block btnBlack">View All</a>
            </div>
        </div>
    </section>
    <script>
        document.addEventListener("DOMContentLoaded", function($) {
            new Splide('.basketeer_splide_202087111', {
                perPage: 5,
                perMove: 1,
                flickMaxPages: 3,
                updateOnMove: true,
                pagination: false,
                throttle: 300,
                gap: 16,
                arrows: {
                    prev: '<button class="prv"><i class="bi-chevron-left bi"></i></button>',
                    next: '<button class="nxt"><i class="bi-chevron-right bi"></i></button>'
                },
                breakpoints: {
                    991: {
                        perPage: 3,
                    },
                    767: {
                        perPage: 2,
                    },
                    575: {
                        drag: true,
                        fixedWidth: 170,
                        gap: 10,
                    },
                }
            }).mount();
        })
    </script>
    <section>
        <div class="container-fluid">
            <div class="mb-4 text-center">
                <h2 class="sectionHeading">Layer Cakes</h2>
                <h4 class="sectionSubHeading">Loads of Layers of Loveliness </h4>
            </div>
            <!-- Original Code
 <div class="cta cta--banner-summer-bakery-gifts">
    <div class="d-flex flex-column flex-lg-row align-items-center" style="background-color:rgb(224, 191, 46);">
        <div class="order-1 order-lg-2 p-0 cta-image" style="flex: 1;"><img src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/04/24100817/banner-summer-bakery-gifts.jpg" alt="" style="aspect-ratio: 100 / 66; object-fit: cover; width: 100%"></div>
        <div class="order-2 order-lg-1 p-4 text-center cta-text" style="flex: 1;">
            <h1>Celebrate with Fresh, Fruity, and Irresistible Summer Bakery Creations</h1>
            <p class="text-short">Indulge in our Summer Bakery treats with juicy fruits, tarts, and cakes. <b> Premium dessert delivery Bangkok, </b>ideal for summer birthdays and surprises.</p>
            <p class="mt-3 mb-0 pt-3"><a href="https://basketeer.com/charlotte-bakery/bakery-gifts/layer-cakes/" class="d-inline-block btnBlack">SHOP NOW</a></p>
        </div>
    </div>
</div>

<style>
.cta--banner-summer-bakery-gifts .cta-text { color: white; }
</style>
-->

            <div class="cta cta--banner-summer-bakery-gifts">
                <div class="d-flex flex-column flex-lg-row align-items-center" style="background-color: #d88e8d;">
                    <div class="order-1 order-lg-2 p-0 cta-image" style="flex: 1;">
                        <img src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/08/29145450/Layer-Cake-Banner-v2.webp" alt="Summer Bakery Gifts featuring fresh fruit tarts and cakes" style="aspect-ratio: 100 / 66; object-fit: cover; width: 100%">
                    </div>
                    <div class="order-2 order-lg-1 p-4 text-center cta-text" style="flex: 1;">
                        <h1>Soft, Elegant Sponge Layer Cakes – Freshly Baked in Bangkok</h1>

                        <!-- Full paragraph for desktop -->
                        <p class="text-short d-none d-md-block">
                            Discover Basketeer's signature sponge layer cakes, made with soft sponge and the finest ingredients. Thoughtfully designed and freshly baked in Bangkok, they’re perfect for birthdays, heartfelt gifts, and special moments. Same-day delivery available across
                            Bangkok and nearby areas.
                        </p>

                        <!-- Short paragraph for mobile -->
                        <p class="text-short d-block d-md-none">
                            Discover Basketeer's soft sponge layer cakes – freshly baked in Bangkok. Perfect for birthdays, gifts, and special celebrations with same-day delivery.
                        </p>

                        <p class="mt-3 mb-0 pt-3">
                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/layer-cakes/" class="d-inline-block btnBlack">SHOP NOW</a>
                        </p>
                    </div>
                </div>
            </div>

            <style>
                .cta--banner-summer-bakery-gifts .cta-text {
                    color: white;
                }
            </style>

            <div class="d-flex justify-content-between mt-3 occasionItems2 splide_el splide basketeer_splide_1275525099">
                <div class="splide__track">

                    <ul class="splide__list">
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/layer-cakes/emerald-vintage-draped-cake/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/07/02115227/CKS25-068-262x300.jpeg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/07/02115227/CKS25-068-894x1024.jpeg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/07/02115227/CKS25-068-768x880.jpeg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/07/02115227/CKS25-068-600x688.jpeg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/07/02115227/CKS25-068-64x73.jpeg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/07/02115227/CKS25-068.jpeg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Dark emerald green cake with gold pearls, buttercream piping in draped curtain design." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Dark emerald green cake with gold pearls, buttercream piping in draped curtain design." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CKS25-068</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/layer-cakes/emerald-vintage-draped-cake/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/layer-cakes/emerald-vintage-draped-cake/">Emerald Vintage Draped Cake</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>1,150.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/chocolate-flavors/ferrero-chocolate-luxe-cake/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/26085227/CKS25-069-262x300.jpeg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/26085227/CKS25-069-894x1024.jpeg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/26085227/CKS25-069-768x880.jpeg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/26085227/CKS25-069-600x688.jpeg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/26085227/CKS25-069-64x73.jpeg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/26085227/CKS25-069.jpeg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Tall round chocolate cake with a decorative band of Ferrero, chocolate bars, and golden pearls." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Tall round chocolate cake with a decorative band of Ferrero, chocolate bars, and golden pearls." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CKS25-069</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/chocolate-flavors/ferrero-chocolate-luxe-cake/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/chocolate-flavors/ferrero-chocolate-luxe-cake/">Ferrero Chocolate Luxe Cake</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>1,390.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/layer-cakes/luxury-rectangular-cherry-cream-cake/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/26082658/CKS25-067.3-262x300.jpeg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/26082658/CKS25-067.3-894x1024.jpeg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/26082658/CKS25-067.3-768x880.jpeg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/26082658/CKS25-067.3-600x688.jpeg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/26082658/CKS25-067.3-64x73.jpeg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/26082658/CKS25-067.3.jpeg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Luxury Cherry Cream Cake with Gold Candles | Vintage Birthday Cake" decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Luxury Cherry Cream Cake with Gold Candles | Vintage Birthday Cake" decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CKS25-067</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/layer-cakes/luxury-rectangular-cherry-cream-cake/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/layer-cakes/luxury-rectangular-cherry-cream-cake/">Luxury Rectangular Cherry Cream Cake</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>2,900.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/layer-cakes/romantic-pink-rose-heart-cake/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/23083139/CKS25-066-262x300.jpeg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/23083139/CKS25-066-894x1024.jpeg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/23083139/CKS25-066-768x880.jpeg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/23083139/CKS25-066-600x688.jpeg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/23083139/CKS25-066-64x73.jpeg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/23083139/CKS25-066.jpeg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Heart-shaped cake with white buttercream, pink rose decorations, and delicate ribbon accents." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Heart-shaped cake with white buttercream, pink rose decorations, and delicate ribbon accents." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CKS25-066</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/layer-cakes/romantic-pink-rose-heart-cake/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/layer-cakes/romantic-pink-rose-heart-cake/">Romantic Pink Rose Heart Cake</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>1,790.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/birthday-cakes/pink-ribbon-heart-birthday-cake/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/20101221/CKS25-055-262x300.jpeg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/20101221/CKS25-055-894x1024.jpeg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/20101221/CKS25-055-768x880.jpeg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/20101221/CKS25-055-600x688.jpeg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/20101221/CKS25-055-64x73.jpeg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/20101221/CKS25-055.jpeg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Rectangular pink birthday cake with “happy birthday” piping, 6 fondant hearts, 2 candles, and 4 satin ribbon bows." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Rectangular pink birthday cake with “happy birthday” piping, 6 fondant hearts, 2 candles, and 4 satin ribbon bows." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CKS25-055</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/birthday-cakes/pink-ribbon-heart-birthday-cake/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/birthday-cakes/pink-ribbon-heart-birthday-cake/">Pink Ribbon Heart Birthday Cake</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>2,090.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/layer-cakes/luxe-heart-charm-chocolate-cake/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/20092526/CKS25-064-262x300.jpeg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/20092526/CKS25-064-894x1024.jpeg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/20092526/CKS25-064-768x880.jpeg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/20092526/CKS25-064-600x688.jpeg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/20092526/CKS25-064-64x73.jpeg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/20092526/CKS25-064.jpeg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Mini M&M chocolate sponge cake with red fondant hearts, metallic gold beads, and a sculpted luxe candle." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Mini M&M chocolate sponge cake with red fondant hearts, metallic gold beads, and a sculpted luxe candle." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CKS25-064</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/layer-cakes/luxe-heart-charm-chocolate-cake/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/layer-cakes/luxe-heart-charm-chocolate-cake/">Minimal Red Heart Celebration Cake</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>1,220.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/edible-printing-cake/cherry-heart-vintage-photo-cake/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/20093646/CKS25-063.4-262x300.jpeg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/20093646/CKS25-063.4-894x1024.jpeg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/20093646/CKS25-063.4-768x880.jpeg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/20093646/CKS25-063.4-600x688.jpeg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/20093646/CKS25-063.4-64x73.jpeg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/20093646/CKS25-063.4.jpeg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Heart-shaped vanilla cake topped with red cherries and custom photo icing, decorated with piped buttercream." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Heart-shaped vanilla cake topped with red cherries and custom photo icing, decorated with piped buttercream." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CKS25-063</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/edible-printing-cake/cherry-heart-vintage-photo-cake/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/edible-printing-cake/cherry-heart-vintage-photo-cake/">Vintage Cherry Heart Edible Photo Cake</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>3,100.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/custom-cakes/floral-frame-photo-cake/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/23112110/CKS25-065.4-262x300.jpeg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/23112110/CKS25-065.4-894x1024.jpeg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/23112110/CKS25-065.4-768x880.jpeg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/23112110/CKS25-065.4-600x688.jpeg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/23112110/CKS25-065.4-64x73.jpeg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/23112110/CKS25-065.4.jpeg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Vanilla photo cake with pastel edible flowers and buttercream piping." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Vanilla photo cake with pastel edible flowers and buttercream piping." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CKS25-065</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/custom-cakes/floral-frame-photo-cake/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/custom-cakes/floral-frame-photo-cake/">Personalised Edible Photo Floral Cake</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>2,070.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/layer-cakes/white-buttercream-vintage-celebration-cake/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18145600/CKS25-050-262x300.jpeg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18145600/CKS25-050-894x1024.jpeg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18145600/CKS25-050-768x880.jpeg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18145600/CKS25-050-600x688.jpeg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18145600/CKS25-050-64x73.jpeg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18145600/CKS25-050.jpeg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Tall white buttercream cake with intricate vintage piping, floral rose designs, and five gold taper candles." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Tall white buttercream cake with intricate vintage piping, floral rose designs, and five gold taper candles." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CKS25-050</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/layer-cakes/white-buttercream-vintage-celebration-cake/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/layer-cakes/white-buttercream-vintage-celebration-cake/">White Buttercream Vintage Celebration Cake</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>1,290.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/edible-printing-cake/pink-buttercream-cake-with-photo-print/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18141833/CKS25-059-262x300.jpeg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18141833/CKS25-059-894x1024.jpeg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18141833/CKS25-059-768x880.jpeg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18141833/CKS25-059-600x688.jpeg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18141833/CKS25-059-64x73.jpeg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18141833/CKS25-059.jpeg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Mini rectangular strawberry sponge cake with pink piped buttercream and edible photo printed on icing paper." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Mini rectangular strawberry sponge cake with pink piped buttercream and edible photo printed on icing paper." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CKS25-061</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/edible-printing-cake/pink-buttercream-cake-with-photo-print/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/edible-printing-cake/pink-buttercream-cake-with-photo-print/">Pink Buttercream Cake topped with Edible Photo</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>2,390.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/fruity-flavors/luxury-fresh-fruits-celebration-cake/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18133141/CKS25-058-262x300.jpeg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18133141/CKS25-058-894x1024.jpeg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18133141/CKS25-058-768x880.jpeg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18133141/CKS25-058-600x688.jpeg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18133141/CKS25-058-64x73.jpeg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18133141/CKS25-058.jpeg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Rectangular strawberry sponge cake topped with kiwi, orange slices, blueberries, Japanese strawberries, raspberries, and piped cream border." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Rectangular strawberry sponge cake topped with kiwi, orange slices, blueberries, Japanese strawberries, raspberries, and piped cream border." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CKS25-058</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/fruity-flavors/luxury-fresh-fruits-celebration-cake/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/fruity-flavors/luxury-fresh-fruits-celebration-cake/">Luxury Fresh Fruits Celebration Cake</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>6,200.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/layer-cakes/romantic-whimsical-garden-cake/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18113439/CKS25-057-262x300.jpeg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18113439/CKS25-057-894x1024.jpeg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18113439/CKS25-057-768x880.jpeg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18113439/CKS25-057-600x688.jpeg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18113439/CKS25-057-64x73.jpeg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18113439/CKS25-057.jpeg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Rectangular Biscoff sponge cake topped with whipped cream, edible flower petals, and fresh pink flower arrangements." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Rectangular Biscoff sponge cake topped with whipped cream, edible flower petals, and fresh pink flower arrangements." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CKS25-057</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/layer-cakes/romantic-whimsical-garden-cake/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/layer-cakes/romantic-whimsical-garden-cake/">Romantic Whimsical Edible Flower Cake</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>1,990.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/layer-cakes/vanilla-bloom-garden-cake/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18114926/CKS25-056.4-262x300.jpeg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18114926/CKS25-056.4-894x1024.jpeg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18114926/CKS25-056.4-768x880.jpeg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18114926/CKS25-056.4-600x688.jpeg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18114926/CKS25-056.4-64x73.jpeg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18114926/CKS25-056.4.jpeg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Rectangular vanilla sponge cake decorated with whipped cream, edible flower mix, and two silver birthday candles." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Rectangular vanilla sponge cake decorated with whipped cream, edible flower mix, and two silver birthday candles." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CKS25-056</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/layer-cakes/vanilla-bloom-garden-cake/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/layer-cakes/vanilla-bloom-garden-cake/">Vanilla Bloom Edible Flower Garden Cake</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>1,590.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/edible-printing-cake/personalised-vanilla-photo-cake/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18100007/CKS25-054-262x300.jpeg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18100007/CKS25-054-894x1024.jpeg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18100007/CKS25-054-768x880.jpeg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18100007/CKS25-054-600x688.jpeg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18100007/CKS25-054-64x73.jpeg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18100007/CKS25-054.jpeg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Rectangular vanilla sponge cake with printed photo collage on icing paper and piped cream borders." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Rectangular vanilla sponge cake with printed photo collage on icing paper and piped cream borders." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CKS25-054</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/edible-printing-cake/personalised-vanilla-photo-cake/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/edible-printing-cake/personalised-vanilla-photo-cake/">Personalised Vanilla Edible Photo Cake</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>4,550.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/edible-printing-cake/lemon-zest-photo-celebration-cake/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18093641/CKS25-053.2-262x300.jpeg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18093641/CKS25-053.2-894x1024.jpeg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18093641/CKS25-053.2-768x880.jpeg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18093641/CKS25-053.2-600x688.jpeg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18093641/CKS25-053.2-64x73.jpeg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/06/18093641/CKS25-053.2.jpeg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Rectangular lemon sponge cake with edible photo print on icing paper and piped buttercream decoration." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Rectangular lemon sponge cake with edible photo print on icing paper and piped buttercream decoration." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CKS25-053</p>

                                        <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/edible-printing-cake/lemon-zest-photo-celebration-cake/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/edible-printing-cake/lemon-zest-photo-celebration-cake/">Lemon Zest Celebration Cake with Edible Photo</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>3,020.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                    </ul>
                </div>
            </div>
            <div class="mt-3 text-center">
                <a href="https://basketeer.com/charlotte-bakery/bakery-gifts/layer-cakes/" class="d-inline-block btnBlack">View All</a>
            </div>
        </div>
    </section>
    <script>
        document.addEventListener("DOMContentLoaded", function($) {
            new Splide('.basketeer_splide_1275525099', {
                perPage: 5,
                perMove: 1,
                flickMaxPages: 3,
                updateOnMove: true,
                pagination: false,
                throttle: 300,
                gap: 16,
                arrows: {
                    prev: '<button class="prv"><i class="bi-chevron-left bi"></i></button>',
                    next: '<button class="nxt"><i class="bi-chevron-right bi"></i></button>'
                },
                breakpoints: {
                    991: {
                        perPage: 3,
                    },
                    767: {
                        perPage: 2,
                    },
                    575: {
                        drag: true,
                        fixedWidth: 170,
                        gap: 10,
                    },
                }
            }).mount();
        })
    </script>
    <section>
        <div class="container-fluid">
            <div class="mb-4 text-center">
                <h2 class="sectionHeading">Surprise Gifts</h2>
                <h4 class="sectionSubHeading">SURPRISE! Someone You Love </h4>
            </div>
            <div class="cta cta--banner-surprise-box">
                <div class="d-flex flex-column flex-lg-row align-items-center" style="background-color: #cb7b84;">
                    <div class="order-1 order-lg-2 p-0 cta-image" style="flex: 1;"><img src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/04/24100823/banner-surprise-box.jpg" alt="" style="aspect-ratio: 100 / 66; object-fit: cover; width: 100%"></div>
                    <div class="order-2 order-lg-1 p-4 text-center cta-text" style="flex: 1;">
                        <h1>Want to Surpise Your Loved ones?</h1>
                        <p class="text-short">Make every moment unforgettable with Basketeer’s curated <b>Surprise Gift Ideas</b>, perfect for expressing love and appreciation.</p>
                        <p class="mt-3 mb-0 pt-3"><a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/" class="d-inline-block btnBlack">View all</a></p>
                    </div>
                </div>
            </div>

            <style>
                .cta--banner-surprise-box .cta-text {
                    color: white;
                }
            </style>
            <div class="d-flex justify-content-between mt-3 occasionItems2 splide_el splide basketeer_splide_1779220876">
                <div class="splide__track">

                    <ul class="splide__list">
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/valentines-surprise-box-with-teddy-balloons/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/02/10165658/VLT25-064-1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/02/10165658/VLT25-064-1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/02/10165658/VLT25-064-1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/02/10165658/VLT25-064-1-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/02/10165658/VLT25-064-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/02/10165658/VLT25-064-1.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A Valentine’s surprise gift featuring a giant pink gift box with the words "Unbox the Love", a pink teddy bear, and heart-shaped balloons floating in the background." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A Valentine’s surprise gift featuring a giant pink gift box with the words "Unbox the Love", a pink teddy bear, and heart-shaped balloons floating in the background." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">VLT25-064</p>

                                        <button onclick="addToCart(194759)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/valentines-surprise-box-with-teddy-balloons/">Valentine’s Surprise Box with Teddy &#038; Balloons</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>4,790.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/jomaline-english-pear-perfume-gift/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/09100502/Valentine21-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/09100502/Valentine21-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/09100502/Valentine21-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/09100502/Valentine21-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/09100502/Valentine21-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/09100502/Valentine21.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A Jo Malone London gift box with a black ribbon surrounded by an arrangement of white roses and green foliage on a marble surface. The ribbon and box are imprinted with "Basket" in gold, adding an elegant touch to the sophisticated floral display, ideal for presenting Jomalone's English Pear Perfume Gift." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A Jo Malone London gift box with a black ribbon surrounded by an arrangement of white roses and green foliage on a marble surface. The ribbon and box are imprinted with "Basket" in gold, adding an elegant touch to the sophisticated floral display, ideal for presenting Jomalone's English Pear Perfume Gift." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">VLT-021</p>

                                        <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/jomaline-english-pear-perfume-gift/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/jomaline-english-pear-perfume-gift/">Jomalone &#8211; English Pear Perfume Gift</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>8,530.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/byredo-lil-fleur-perfume-gift/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/09095704/Valentine20-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/09095704/Valentine20-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/09095704/Valentine20-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/09095704/Valentine20-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/09095704/Valentine20-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/09095704/Valentine20.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A gift box of Byredo Lil Fleur Perfume surrounded by an arrangement of pale pink and white roses. The box is tied with a black ribbon that says "BASKETIER." The perfume bottle is visible among the flowers, all set on a white surface." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A gift box of Byredo Lil Fleur Perfume surrounded by an arrangement of pale pink and white roses. The box is tied with a black ribbon that says "BASKETIER." The perfume bottle is visible among the flowers, all set on a white surface." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">VLT-020</p>

                                        <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/byredo-lil-fleur-perfume-gift/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/byredo-lil-fleur-perfume-gift/">Byredo Young Rose Perfume Gift</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>13,880.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/birthday-flowers/miss-dior-blooming-bouquet-perfume-gift/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/09094302/Valentine16-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/09094302/Valentine16-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/09094302/Valentine16-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/09094302/Valentine16-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/09094302/Valentine16-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/02/09094302/Valentine16.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A bottle of Miss Dior Blooming Bouquet perfume sits in the center of a square arrangement of red and pink roses. The roses are surrounded by pink ribbon with "BASKETEER" written on it. The scene is set on a white surface with scattered petals and small decorative elements, creating a perfect gift." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A bottle of Miss Dior Blooming Bouquet perfume sits in the center of a square arrangement of red and pink roses. The roses are surrounded by pink ribbon with "BASKETEER" written on it. The scene is set on a white surface with scattered petals and small decorative elements, creating a perfect gift." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">VLT-019</p>

                                        <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/birthday-flowers/miss-dior-blooming-bouquet-perfume-gift/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/birthday-flowers/miss-dior-blooming-bouquet-perfume-gift/">Miss Dior Blooming Bouquet Perfume Gift</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>10,500.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/valentines-day-bakery-balloon-gift-box-11/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/09150444/CB23-025-2-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/09150444/CB23-025-2-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/09150444/CB23-025-2-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/09150444/CB23-025-2-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/09150444/CB23-025-2-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/09150444/CB23-025-2-21x24.jpg 21w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/09150444/CB23-025-2-31x36.jpg 31w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/09150444/CB23-025-2-42x48.jpg 42w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/09150444/CB23-025-2.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A stylish individual in an elegant black dress graces the scene with a warm smile, holding an exquisite black gift box adorned with a luxurious ribbon. Attached to this sophisticated package are three charming red heart-shaped balloons, one inscribed with the romantic phrase "You Are My Valentine." The serene, light-colored background highlights the opulence of the moment. In the corner, proudly displayed, is the distinguished "BASKETEER" logo, affirming this as a premium offering from their exclusive collection." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A stylish individual in an elegant black dress graces the scene with a warm smile, holding an exquisite black gift box adorned with a luxurious ribbon. Attached to this sophisticated package are three charming red heart-shaped balloons, one inscribed with the romantic phrase "You Are My Valentine." The serene, light-colored background highlights the opulence of the moment. In the corner, proudly displayed, is the distinguished "BASKETEER" logo, affirming this as a premium offering from their exclusive collection." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CB23-026</p>

                                        <button onclick="addToCart(85962)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/valentines-day-bakery-balloon-gift-box-11/">Valentine&#8217;s Gift Set with Red Heart Balloons</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>4,100.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/valentines-day-bakery-balloon-gift-box-10/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/09160018/CB23-024-2-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/09160018/CB23-024-2-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/09160018/CB23-024-2-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/09160018/CB23-024-2-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/09160018/CB23-024-2-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/09160018/CB23-024-2-21x24.jpg 21w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/09160018/CB23-024-2-31x36.jpg 31w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/09160018/CB23-024-2-42x48.jpg 42w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/09160018/CB23-024-2.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A sophisticated woman in an elegant light blue dress stands gracefully, holding three exquisite pink heart-shaped balloons inscribed with the loving message "You Are My Valentine." In her other hand, she delicately cradles a pristine white gift box adorned with a luxurious ribbon. The signature "BASKETEER" logo proudly graces the scene in gleaming letters at the bottom left corner, adding a touch of opulence to the serene gray backdrop." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A sophisticated woman in an elegant light blue dress stands gracefully, holding three exquisite pink heart-shaped balloons inscribed with the loving message "You Are My Valentine." In her other hand, she delicately cradles a pristine white gift box adorned with a luxurious ribbon. The signature "BASKETEER" logo proudly graces the scene in gleaming letters at the bottom left corner, adding a touch of opulence to the serene gray backdrop." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CB23-025</p>

                                        <button onclick="addToCart(85950)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/valentines-day-bakery-balloon-gift-box-10/">Valentine&#8217;s Gift Set with Pink Heart Balloons</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>4,100.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/romantic-flowers-for-her/balloon-rose-bouquets-combo-set-2/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10155440/CB23-008-2-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10155440/CB23-008-2-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10155440/CB23-008-2-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10155440/CB23-008-2-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10155440/CB23-008-2-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10155440/CB23-008-2-21x24.jpg 21w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10155440/CB23-008-2-31x36.jpg 31w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10155440/CB23-008-2-42x48.jpg 42w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10155440/CB23-008-2.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A sophisticated woman in an elegant black dress sits gracefully on the floor, cradling a luxurious bouquet of exquisite red and beige roses wrapped in chic black paper. Surrounding her, a cluster of vibrant red heart-shaped balloons adds a touch of romance and celebration. In the lower left corner, elegant white text proudly announces "BASKETEER THE ULTIMATE GIFT: Red Heart Balloons & Roses Set," enhancing the allure and exclusivity of this enchanting scene." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A sophisticated woman in an elegant black dress sits gracefully on the floor, cradling a luxurious bouquet of exquisite red and beige roses wrapped in chic black paper. Surrounding her, a cluster of vibrant red heart-shaped balloons adds a touch of romance and celebration. In the lower left corner, elegant white text proudly announces "BASKETEER THE ULTIMATE GIFT: Red Heart Balloons & Roses Set," enhancing the allure and exclusivity of this enchanting scene." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CB23-008</p>

                                        <button onclick="addToCart(85188)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/romantic-flowers-for-her/balloon-rose-bouquets-combo-set-2/">Love in Luxe – Red Heart Balloon &#038; Roses Set</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>8,160.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/flowers-for-women/balloon-and-bouquets-flower-combo-set-7/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10155922/CB23-007-2-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10155922/CB23-007-2-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10155922/CB23-007-2-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10155922/CB23-007-2-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10155922/CB23-007-2-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10155922/CB23-007-2-21x24.jpg 21w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10155922/CB23-007-2-31x36.jpg 31w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10155922/CB23-007-2-42x48.jpg 42w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10155922/CB23-007-2.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A woman in an elegant light blue dress gracefully reclines on a sumptuous white tufted couch, holding an opulent bouquet of vibrant red roses. Beside her, the exquisite Heart Balloons & Red Roses Combo from Basketeer is tastefully tethered to the couch. The backdrop is adorned with sophisticated decorative molding against a pristine white wall. The distinguished "Basketeer" logo graces the bottom left corner, epitomizing luxury and refinement." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A woman in an elegant light blue dress gracefully reclines on a sumptuous white tufted couch, holding an opulent bouquet of vibrant red roses. Beside her, the exquisite Heart Balloons & Red Roses Combo from Basketeer is tastefully tethered to the couch. The backdrop is adorned with sophisticated decorative molding against a pristine white wall. The distinguished "Basketeer" logo graces the bottom left corner, epitomizing luxury and refinement." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CB23-007</p>

                                        <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/flowers-for-women/balloon-and-bouquets-flower-combo-set-7/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/flowers-for-women/balloon-and-bouquets-flower-combo-set-7/">Red Roses Bouquet &#038; Heart Balloons Set</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>10,210.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/balloon-and-bouquets-flower-combo-set-6/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10160658/CB23-006-3-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10160658/CB23-006-3-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10160658/CB23-006-3-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10160658/CB23-006-3-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10160658/CB23-006-3-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10160658/CB23-006-3-21x24.jpg 21w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10160658/CB23-006-3-31x36.jpg 31w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10160658/CB23-006-3-42x48.jpg 42w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10160658/CB23-006-3.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A beaming woman draped in an elegant pink dress sits gracefully on the floor, cradling a sumptuous bouquet of exquisite pink roses. Beside her rests an adorable brown teddy bear adorned with heart-shaped pink balloons, casting a nostalgic charm. The luxurious ambiance is subtly highlighted by the tastefully placed "Basketeer" logo in the corner, promising sophistication and thoughtful curation." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A beaming woman draped in an elegant pink dress sits gracefully on the floor, cradling a sumptuous bouquet of exquisite pink roses. Beside her rests an adorable brown teddy bear adorned with heart-shaped pink balloons, casting a nostalgic charm. The luxurious ambiance is subtly highlighted by the tastefully placed "Basketeer" logo in the corner, promising sophistication and thoughtful curation." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CB23-006</p>

                                        <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/balloon-and-bouquets-flower-combo-set-6/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/balloon-and-bouquets-flower-combo-set-6/">Luxury Blush Roses &#038; Teddy Bear Gift Set</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>8,660.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/balloon-and-bouquets-flower-combo-set-4/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10161353/CB23-011-2-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10161353/CB23-011-2-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10161353/CB23-011-2-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10161353/CB23-011-2-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10161353/CB23-011-2-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10161353/CB23-011-2-21x24.jpg 21w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10161353/CB23-011-2-31x36.jpg 31w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10161353/CB23-011-2-42x48.jpg 42w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10161353/CB23-011-2.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A sophisticated woman in an elegant brown dress beams with joy as she cradles a lush bouquet of sweet pink roses and an exquisite oversized pink teddy bear. Surrounding her, delicate pink heart balloons float gracefully against a chic neutral gray backdrop, creating an enchanting atmosphere. In the bottom-left corner, the prestigious "BASKETEER" logo adds a touch of refined luxury to the scene." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A sophisticated woman in an elegant brown dress beams with joy as she cradles a lush bouquet of sweet pink roses and an exquisite oversized pink teddy bear. Surrounding her, delicate pink heart balloons float gracefully against a chic neutral gray backdrop, creating an enchanting atmosphere. In the bottom-left corner, the prestigious "BASKETEER" logo adds a touch of refined luxury to the scene." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CB23-011</p>

                                        <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/balloon-and-bouquets-flower-combo-set-4/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/balloon-and-bouquets-flower-combo-set-4/">Romantic Pink Roses &#038; Big Teddy Set</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>8,460.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/birthday-flowers/balloon-and-bouquets-flower-combo-set-3/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10161936/CB23-004-2-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10161936/CB23-004-2-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10161936/CB23-004-2-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10161936/CB23-004-2-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10161936/CB23-004-2-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10161936/CB23-004-2-21x24.jpg 21w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10161936/CB23-004-2-31x36.jpg 31w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10161936/CB23-004-2-42x48.jpg 42w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10161936/CB23-004-2.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A joyful woman in an elegant white ensemble gracefully holds a luxurious Soft Pink Bouquet, meticulously wrapped in pristine white paper. Her eyes sparkle as she also holds enchanting heart-shaped balloons that gently float above her. The backdrop is a sophisticated plain gray, allowing the scene to radiate with warmth and charm. In the bottom left corner, "Basketeer: The Ultimate Gifts" subtly reminds you of the unparalleled elegance and thoughtfulness associated with the brand." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A joyful woman in an elegant white ensemble gracefully holds a luxurious Soft Pink Bouquet, meticulously wrapped in pristine white paper. Her eyes sparkle as she also holds enchanting heart-shaped balloons that gently float above her. The backdrop is a sophisticated plain gray, allowing the scene to radiate with warmth and charm. In the bottom left corner, "Basketeer: The Ultimate Gifts" subtly reminds you of the unparalleled elegance and thoughtfulness associated with the brand." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CB23-004</p>

                                        <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/birthday-flowers/balloon-and-bouquets-flower-combo-set-3/" class="view-product"><i class="bi bi-arrow-right-short"></i><span>View</span></a>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/birthday-flowers/balloon-and-bouquets-flower-combo-set-3/">Pink Rose Bouquet &#038; Heart Balloons Set</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>5,360.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/balloon-rose-bouquets-combo-set/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/27173008/CB23-001-3-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/27173008/CB23-001-3-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/27173008/CB23-001-3-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/27173008/CB23-001-3-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/27173008/CB23-001-3-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/27173008/CB23-001-3-21x24.jpg 21w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/27173008/CB23-001-3-31x36.jpg 31w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/27173008/CB23-001-3-42x48.jpg 42w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/27173008/CB23-001-3.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A sophisticated woman in an elegant black dress cradles a lavish bouquet of sweet roses, exuding luxury with its delicate white and pale pink blooms. Behind her, a collection of opulent black-gray heart-shaped balloons float gracefully, creating an enchanting and inviting atmosphere. Set against a pristine white background, the bottom left corner proudly displays the Basketeer logo along with their distinguished slogan "THE ULTIMATE GIFTS," adding a touch of refinement and exclusivity to the scene." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A sophisticated woman in an elegant black dress cradles a lavish bouquet of sweet roses, exuding luxury with its delicate white and pale pink blooms. Behind her, a collection of opulent black-gray heart-shaped balloons float gracefully, creating an enchanting and inviting atmosphere. Set against a pristine white background, the bottom left corner proudly displays the Basketeer logo along with their distinguished slogan "THE ULTIMATE GIFTS," adding a touch of refinement and exclusivity to the scene." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CB23-001</p>

                                        <button onclick="addToCart(85125)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/balloon-rose-bouquets-combo-set/">Black &#038; White Roses Balloons Surprise Set</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>8,010.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/balloon-and-bouquets-flower-combo-set-2/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162735/CB23-002-2-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162735/CB23-002-2-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162735/CB23-002-2-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162735/CB23-002-2-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162735/CB23-002-2-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162735/CB23-002-2-21x24.jpg 21w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162735/CB23-002-2-31x36.jpg 31w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162735/CB23-002-2-42x48.jpg 42w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162735/CB23-002-2.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A woman, elegantly adorned in a flowing white dress, radiates joy as she cradles a bouquet of delicate pastel-shaded flowers. In her hands, she also holds the luxurious "Cream Heart Balloons & Roses Gift Set," featuring heart-shaped balloons in soft peach and cream hues. The background is minimalistic, accentuating the sophistication of the scene. The prestigious BASKETEER logo proudly accents the bottom left corner, signifying timeless elegance and unparalleled quality." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A woman, elegantly adorned in a flowing white dress, radiates joy as she cradles a bouquet of delicate pastel-shaded flowers. In her hands, she also holds the luxurious "Cream Heart Balloons & Roses Gift Set," featuring heart-shaped balloons in soft peach and cream hues. The background is minimalistic, accentuating the sophistication of the scene. The prestigious BASKETEER logo proudly accents the bottom left corner, signifying timeless elegance and unparalleled quality." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CB23-002</p>

                                        <button onclick="addToCart(85102)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/balloon-and-bouquets-flower-combo-set-2/">Dreamy Blush Roses &#038; Balloons Set</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>4,440.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/balloon-valentine-combo-gifts-set-2/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162100/CB23-014-2-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162100/CB23-014-2-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162100/CB23-014-2-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162100/CB23-014-2-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162100/CB23-014-2-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162100/CB23-014-2-21x24.jpg 21w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162100/CB23-014-2-31x36.jpg 31w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162100/CB23-014-2-42x48.jpg 42w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162100/CB23-014-2.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A radiant woman in an elegant brown dress embraces a sumptuous, oversized teddy bear, exuding warmth and charm. Her backdrop features a dreamy collection of heart-shaped balloons in sophisticated beige and cream tones, creating a serene and delightful atmosphere. The minimalist gray background accentuates the luxurious feel of the moment. The revered "BASKETEER" logo graces the bottom left corner, highlighting the exquisite Cream Heart Balloons & Brown Teddy Bear Set — a true testament to Basketeer's commitment to luxury and inviting sentimentality." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A radiant woman in an elegant brown dress embraces a sumptuous, oversized teddy bear, exuding warmth and charm. Her backdrop features a dreamy collection of heart-shaped balloons in sophisticated beige and cream tones, creating a serene and delightful atmosphere. The minimalist gray background accentuates the luxurious feel of the moment. The revered "BASKETEER" logo graces the bottom left corner, highlighting the exquisite Cream Heart Balloons & Brown Teddy Bear Set — a true testament to Basketeer's commitment to luxury and inviting sentimentality." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CB23-014</p>

                                        <button onclick="addToCart(85103)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/balloon-valentine-combo-gifts-set-2/">Grand Love Teddy &#038; Balloons Set</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>2,450.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/flowers-for-women/balloon-and-bouquets-flower-combo-set/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162935/CB23-015-2-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162935/CB23-015-2-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162935/CB23-015-2-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162935/CB23-015-2-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162935/CB23-015-2-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162935/CB23-015-2-21x24.jpg 21w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162935/CB23-015-2-31x36.jpg 31w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162935/CB23-015-2-42x48.jpg 42w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/02/10162935/CB23-015-2.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A sophisticated woman in an elegant brown dress exudes joy, holding a sumptuous bouquet of pink and white roses in one hand. In the other, she gracefully displays a collection of heart-shaped balloons in luxurious shades of brown and gold, part of the exquisite Brown Heart Balloons & Roses Set by Basketeer. The understated light gray background subtly features the word "BASKETEER," adding an air of refined elegance to the scene." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A sophisticated woman in an elegant brown dress exudes joy, holding a sumptuous bouquet of pink and white roses in one hand. In the other, she gracefully displays a collection of heart-shaped balloons in luxurious shades of brown and gold, part of the exquisite Brown Heart Balloons & Roses Set by Basketeer. The understated light gray background subtly features the word "BASKETEER," adding an air of refined elegance to the scene." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">CB23-015</p>

                                        <button onclick="addToCart(85076)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/flowers-for-women/balloon-and-bouquets-flower-combo-set/">Romantic Mocha Rose &#038; Heart Balloons Set</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>4,240.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                    </ul>
                </div>
            </div>
            <div class="mt-3 text-center">
                <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/surprise-gifts/" class="d-inline-block btnBlack">View All</a>
            </div>
        </div>
    </section>
    <script>
        document.addEventListener("DOMContentLoaded", function($) {
            new Splide('.basketeer_splide_1779220876', {
                perPage: 5,
                perMove: 1,
                flickMaxPages: 3,
                updateOnMove: true,
                pagination: false,
                throttle: 300,
                gap: 16,
                arrows: {
                    prev: '<button class="prv"><i class="bi-chevron-left bi"></i></button>',
                    next: '<button class="nxt"><i class="bi-chevron-right bi"></i></button>'
                },
                breakpoints: {
                    991: {
                        perPage: 3,
                    },
                    767: {
                        perPage: 2,
                    },
                    575: {
                        drag: true,
                        fixedWidth: 170,
                        gap: 10,
                    },
                }
            }).mount();
        })
    </script>
    <section>
        <div class="container-fluid">
            <div class="mb-4 text-center">
                <h2 class="sectionHeading">Fruit & Flowers</h2>
                <h4 class="sectionSubHeading">Premium Fruit, Stunning Flowers... Together </h4>
            </div>
            <!-- Original Code
 <div class="cta">
    <div class="d-flex flex-column flex-lg-row align-items-center" style="background-color: #CDC1B5;">
        <div class="order-1 order-lg-2 p-0 cta-image" style="flex: 1;"><img src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/04/24100811/banner-fruits-and-flowers.jpg" alt="" style="aspect-ratio: 100 / 66; object-fit: cover; width: 100%"></div>
        <div class="order-2 order-lg-1 p-4 text-center cta-text" style="flex: 1;">
            <h1>Fruit & Flower Hampers<br> Premium, Elegant Designs</h1>
            <p class="text-short">Discover Basketeer’s finest gift hampers with healthy Thai fruits, Korean pears, imported cherries, and fresh seasonal blooms.<b> Thoughtfully crafted</b> for birthdays, new baby celebrations, get-well-soon wishes, anniversaries, and heartfelt thank-you gifts — with same-day delivery in Bangkok.</p>
            <p class="mt-3 mb-0 pt-3"><a href="https://basketeer.com/product-category/fruit-baskets/fruit-flowers/" class="d-inline-block btnBlack">SHOP NOW</a></p>
        </div>
    </div>
</div>
-->
            <!-- Mobile Less Text Code -->
            <div class="cta">
                <div class="d-flex flex-column flex-lg-row align-items-center" style="background-color: #CDC1B5;">
                    <div class="order-1 order-lg-2 p-0 cta-image" style="flex: 1;">
                        <img src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/04/24100811/banner-fruits-and-flowers.jpg" alt="" style="aspect-ratio: 100 / 66; object-fit: cover; width: 100%">
                    </div>
                    <div class="order-2 order-lg-1 p-4 text-center cta-text" style="flex: 1;">
                        <h1>Fruit & Flower Hampers<br>– Premium, Elegant Designs</h1>

                        <!-- Full paragraph for desktop -->
                        <p class="text-short d-none d-md-block">
                            Discover Basketeer’s finest gift hampers with healthy Thai fruits, Korean pears, imported cherries, and fresh seasonal blooms.
                            <b> Thoughtfully crafted</b> for birthdays, new baby celebrations, get-well-soon wishes, anniversaries, and heartfelt thank-you gifts — with same-day delivery in Bangkok.
                        </p>

                        <!-- Short paragraph for mobile -->
                        <p class="text-short d-block d-md-none">
                            Healthy Thai fruits and fresh blooms — thoughtfully crafted for any occasion. Same-day delivery in Bangkok.
                        </p>

                        <p class="mt-3 mb-0 pt-3">
                            <a href="https://basketeer.com/product-category/fruit-baskets/fruit-flowers/" class="d-inline-block btnBlack">SHOP NOW</a>
                        </p>
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-between mt-3 occasionItems2 splide_el splide basketeer_splide_1648590697">
                <div class="splide__track">

                    <ul class="splide__list">
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/fruit-baskets/luxury-blue-florals-and-fruits-gift/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/12/19085627/FRF25-102-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/12/19085627/FRF25-102-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/12/19085627/FRF25-102-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/12/19085627/FRF25-102-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/12/19085627/FRF25-102-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/12/19085627/FRF25-102.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Luxurious gift crate featuring vibrant blue roses, white flowers, fresh fruits like grapes, strawberries, oranges, apples, and melons." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Luxurious gift crate featuring vibrant blue roses, white flowers, fresh fruits like grapes, strawberries, oranges, apples, and melons." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FRF25-102</p>

                                        <button onclick="addToCart(187124)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/fruit-baskets/luxury-blue-florals-and-fruits-gift/">Luxury Blue Florals and Fruits Gift</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>7,230.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/fruit-baskets/fruit-flowers/charming-fruit-and-flower-gift/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/12/05135744/FRF25-100-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/12/05135744/FRF25-100-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/12/05135744/FRF25-100-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/12/05135744/FRF25-100-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/12/05135744/FRF25-100-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/12/05135744/FRF25-100.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A luxurious fruit and floral hamper in a wooden crate, featuring fresh seasonal fruits and stunning blue and white flowers, tied with a navy ribbon." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A luxurious fruit and floral hamper in a wooden crate, featuring fresh seasonal fruits and stunning blue and white flowers, tied with a navy ribbon." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FRF25-100</p>

                                        <button onclick="addToCart(184666)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/fruit-baskets/fruit-flowers/charming-fruit-and-flower-gift/">Charming Fruits and Flowers Gift</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>6,000.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/fruit-baskets/fruit-flowers/exquisite-floral-fruit-gift-box/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/12/05134619/FRF25-099-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/12/05134619/FRF25-099-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/12/05134619/FRF25-099-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/12/05134619/FRF25-099-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/12/05134619/FRF25-099-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/12/05134619/FRF25-099.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Luxury fruit and flower hamper with fresh fruits including melons, grapes, and pomegranates, paired with red roses, gerberas, and tulips in a wooden basket tied with a red ribbon." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Luxury fruit and flower hamper with fresh fruits including melons, grapes, and pomegranates, paired with red roses, gerberas, and tulips in a wooden basket tied with a red ribbon." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FRF25-099</p>

                                        <button onclick="addToCart(184656)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/fruit-baskets/fruit-flowers/exquisite-floral-fruit-gift-box/">Exquisite Florals &#038; Fruits Gift Box</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>5,960.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/fruit-baskets/grand-floral-fruit-celebration-gift/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/10091421/FRF25-098.1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/10091421/FRF25-098.1-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/10091421/FRF25-098.1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/10091421/FRF25-098.1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/10091421/FRF25-098.1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/10091421/FRF25-098.1.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A stunning wooden gift box filled with fresh fruits, including grapes, strawberries, and melons, paired with a vibrant floral arrangement." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A stunning wooden gift box filled with fresh fruits, including grapes, strawberries, and melons, paired with a vibrant floral arrangement." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FRF25-098</p>

                                        <button onclick="addToCart(182981)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/fruit-baskets/grand-floral-fruit-celebration-gift/">Grand Florals &#038; Fruits Celebration Gift</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>7,500.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/fruit-baskets/view-all-fruit-baskets/elegant-wicker-basket-with-fruits/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22164254/FRF25-073-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22164254/FRF25-073-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22164254/FRF25-073-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22164254/FRF25-073-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22164254/FRF25-073-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22164254/FRF25-073.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A wicker basket containing green grapes, apples, pears, and kiwis, beautifully decorated with red and gold flowers and tied with a red ribbon." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A wicker basket containing green grapes, apples, pears, and kiwis, beautifully decorated with red and gold flowers and tied with a red ribbon." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FRF25-073</p>

                                        <button onclick="addToCart(182217)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/fruit-baskets/view-all-fruit-baskets/elegant-wicker-basket-with-fruits/">Seasonal Fruits in a Stylish Basket</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>3,460.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/fruit-baskets/view-all-fruit-baskets/wire-basket-with-fresh-fruits-and-vibrant-orange-blooms/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22164246/FRF25-072-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22164246/FRF25-072-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22164246/FRF25-072-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22164246/FRF25-072-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22164246/FRF25-072-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22164246/FRF25-072.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="A white wire basket featuring fresh green grapes, oranges, pears, and lemons, accented with orange and yellow flowers, tied with a peach ribbon." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="A white wire basket featuring fresh green grapes, oranges, pears, and lemons, accented with orange and yellow flowers, tied with a peach ribbon." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FRF25-072</p>

                                        <button onclick="addToCart(182179)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/fruit-baskets/view-all-fruit-baskets/wire-basket-with-fresh-fruits-and-vibrant-orange-blooms/">Premium Fruit and Flower Gift Basket</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>2,285.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/fruit-baskets/view-all-fruit-baskets/classic-wicker-basket-with-fresh-fruits-and-white-roses/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22163635/FRF25-071-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22163635/FRF25-071-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22163635/FRF25-071-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22163635/FRF25-071-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22163635/FRF25-071-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22163635/FRF25-071.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Classic wicker basket featuring fresh green grapes, apples, pears, kiwi, golden apples, and white roses with blue floral accents for a sophisticated gift." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Classic wicker basket featuring fresh green grapes, apples, pears, kiwi, golden apples, and white roses with blue floral accents for a sophisticated gift." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FRF25-071</p>

                                        <button onclick="addToCart(182205)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/fruit-baskets/view-all-fruit-baskets/classic-wicker-basket-with-fresh-fruits-and-white-roses/">Classic Wicker Basket with Fresh Fruits and White Roses</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>3,288.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/fruit-baskets/fruit-flowers/romantic-pink-rose-and-mixed-berry-wooden-basket/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22163221/FRF25-070-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22163221/FRF25-070-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22163221/FRF25-070-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22163221/FRF25-070-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22163221/FRF25-070-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22163221/FRF25-070.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Romantic wooden basket featuring cherries, blueberries, blackberries, strawberries, raspberries, and pink roses, beautifully styled for gifting." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Romantic wooden basket featuring cherries, blueberries, blackberries, strawberries, raspberries, and pink roses, beautifully styled for gifting." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FRF25-070</p>

                                        <button onclick="addToCart(182204)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/fruit-baskets/fruit-flowers/romantic-pink-rose-and-mixed-berry-wooden-basket/">Romantic Pink Rose and Mixed Berry Wooden Basket</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>4,430.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/fruit-baskets/view-all-fruit-baskets/elegant-white-rose-and-fruit-wicker-basket/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22163213/FRF25-069-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22163213/FRF25-069-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22163213/FRF25-069-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22163213/FRF25-069-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22163213/FRF25-069-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22163213/FRF25-069.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Elegant wicker basket featuring fresh red grapes, apples, golden pear, and oranges, accented with white roses and blue florals, beautifully styled for gifting." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Elegant wicker basket featuring fresh red grapes, apples, golden pear, and oranges, accented with white roses and blue florals, beautifully styled for gifting." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FRF25-069</p>

                                        <button onclick="addToCart(182203)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/fruit-baskets/view-all-fruit-baskets/elegant-white-rose-and-fruit-wicker-basket/">Elegant White Rose and Fruit Wicker Basket</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>3,217.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/fruit-baskets/view-all-fruit-baskets/bright-yellow-floral-and-fruit-wire-basket/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22162513/FRF25-068-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22162513/FRF25-068-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22162513/FRF25-068-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22162513/FRF25-068-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22162513/FRF25-068-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22162513/FRF25-068.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Bright wire basket featuring fresh green grapes, golden pear, avocado, and vibrant yellow and white florals, beautifully styled for gifting." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Bright wire basket featuring fresh green grapes, golden pear, avocado, and vibrant yellow and white florals, beautifully styled for gifting." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FRF25-068</p>

                                        <button onclick="addToCart(182202)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/fruit-baskets/view-all-fruit-baskets/bright-yellow-floral-and-fruit-wire-basket/">Bright Yellow Floral and Fruit Wire Basket</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>2,100.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/fruit-baskets/view-all-fruit-baskets/elegant-blue-rose-and-fruit-wicker-basket/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22162505/FRF25-067-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22162505/FRF25-067-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22162505/FRF25-067-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22162505/FRF25-067-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22162505/FRF25-067-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22162505/FRF25-067.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Elegant wicker basket featuring fresh red grapes, apples, golden pear, and stunning blue roses, beautifully styled for premium gifting." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Elegant wicker basket featuring fresh red grapes, apples, golden pear, and stunning blue roses, beautifully styled for premium gifting." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FRF25-067</p>

                                        <button onclick="addToCart(182201)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/fruit-baskets/view-all-fruit-baskets/elegant-blue-rose-and-fruit-wicker-basket/">Elegant Blue Rose and Fruit Wicker Basket</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>3,079.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/fruit-baskets/view-all-fruit-baskets/romantic-fruit-and-pink-floral-wooden-basket/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22161613/FRF25-066-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22161613/FRF25-066-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22161613/FRF25-066-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22161613/FRF25-066-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22161613/FRF25-066-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22161613/FRF25-066.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Romantic wooden fruit basket featuring strawberries, green grapes, apples, cherries, and pink roses, beautifully styled for gifting." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Romantic wooden fruit basket featuring strawberries, green grapes, apples, cherries, and pink roses, beautifully styled for gifting." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FRF25-066</p>

                                        <button onclick="addToCart(182200)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/fruit-baskets/view-all-fruit-baskets/romantic-fruit-and-pink-floral-wooden-basket/">Romantic Fruit and Pink Floral Wooden Basket</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>4,600.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/fruit-baskets/view-all-fruit-baskets/luxurious-mixed-berry-and-floral-gift-basket/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22161323/FRF25-064-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22161323/FRF25-064-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22161323/FRF25-064-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22161323/FRF25-064-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22161323/FRF25-064-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22161323/FRF25-064.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Luxurious gift basket featuring fresh cherries, raspberries, strawberries, apples, blueberries, and vibrant floral arrangements, styled beautifully for gifting." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Luxurious gift basket featuring fresh cherries, raspberries, strawberries, apples, blueberries, and vibrant floral arrangements, styled beautifully for gifting." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FRF25-064</p>

                                        <button onclick="addToCart(182178)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/fruit-baskets/view-all-fruit-baskets/luxurious-mixed-berry-and-floral-gift-basket/">Luxurious Mixed Berry and Floral Gift Basket</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>3,298.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/fruit-baskets/fruit-flowers/elegant-green-grape-and-blue-floral-gift-basket/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/25092708/FRF25-063.2-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/25092708/FRF25-063.2-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/25092708/FRF25-063.2-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/25092708/FRF25-063.2-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/25092708/FRF25-063.2-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/25092708/FRF25-063.2.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Elegant gift basket featuring fresh green grapes, white flowers, and blue florals, styled for premium gifting occasions." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Elegant gift basket featuring fresh green grapes, white flowers, and blue florals, styled for premium gifting occasions." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FRF25-063</p>

                                        <button onclick="addToCart(182177)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/fruit-baskets/fruit-flowers/elegant-green-grape-and-blue-floral-gift-basket/">Japan-Origin Premium Grape Gift Box</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>4,929.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/shop/fruit-baskets/view-all-fruit-baskets/luxury-mixed-fruit-and-floral-gift-basket/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22154916/FRF25-062-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22154916/FRF25-062-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22154916/FRF25-062-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22154916/FRF25-062-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22154916/FRF25-062-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2024/11/22154916/FRF25-062.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Luxury gift basket featuring fresh apples, golden pear, raspberries, blueberries, and white and blue florals, beautifully arranged for gifting." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Luxury gift basket featuring fresh apples, golden pear, raspberries, blueberries, and white and blue florals, beautifully arranged for gifting." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FRF25-062</p>

                                        <button onclick="addToCart(182176)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/shop/fruit-baskets/view-all-fruit-baskets/luxury-mixed-fruit-and-floral-gift-basket/">Luxury Mixed Fruit and Floral Gift Basket</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>3,648.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                    </ul>
                </div>
            </div>
            <div class="mt-3 text-center">
                <a href="https://basketeer.com/product-category/fruit-baskets/fruit-flowers/" class="d-inline-block btnBlack">View All</a>
            </div>
        </div>
    </section>
    <script>
        document.addEventListener("DOMContentLoaded", function($) {
            new Splide('.basketeer_splide_1648590697', {
                perPage: 5,
                perMove: 1,
                flickMaxPages: 3,
                updateOnMove: true,
                pagination: false,
                throttle: 300,
                gap: 16,
                arrows: {
                    prev: '<button class="prv"><i class="bi-chevron-left bi"></i></button>',
                    next: '<button class="nxt"><i class="bi-chevron-right bi"></i></button>'
                },
                breakpoints: {
                    991: {
                        perPage: 3,
                    },
                    767: {
                        perPage: 2,
                    },
                    575: {
                        drag: true,
                        fixedWidth: 170,
                        gap: 10,
                    },
                }
            }).mount();
        })
    </script>
    <section>
        <div class="container-fluid">
            <div class="mb-4 text-center">
                <h2 class="sectionHeading">All Bouquet Flowers</h2>
                <h4 class="sectionSubHeading">View Our Whole Bouquet Range Here </h4>
            </div>
            <div class="cta">
                <div class="d-flex flex-column flex-lg-row align-items-center" style="background-color: #e8eaf0;">
                    <div class="order-1 order-lg-2 p-0 cta-image" style="flex: 1;"><img src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/07/09165937/flower-bouquet-banner-02.jpg" alt="" style="aspect-ratio: 100 / 66; object-fit: cover; width: 100%"></div>
                    <div class="order-2 order-lg-1 p-4 text-center cta-text" style="flex: 1;">
                        <h1>Where every stem tells a story</h1>
                        <p class="text-short">Our hand-tied bouquets are crafted to speak the language of love, joy, and gratitude. <b>Featuring the finest</b> imported blooms and timeless design, each bouquet is a beautiful expression for birthdays, milestones, apologies,
                            or simply to brighten someone’s day.

                        </p>
                        <p class="mt-3 mb-0 pt-3"><a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/" class="d-inline-block btnBlack">EXPLORE BOUQUETS</a></p>
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-between mt-3 occasionItems2 splide_el splide basketeer_splide_1749669115">
                <div class="splide__track">

                    <ul class="splide__list">
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/ivory-roses-white-seasonal-bouquet/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/26181357/Flower-Arrangement-Ivory-Roses-White-Flowers-Bouquet-Delivery-Bangkok-FLB25-212-1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/26181357/Flower-Arrangement-Ivory-Roses-White-Flowers-Bouquet-Delivery-Bangkok-FLB25-212-1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/26181357/Flower-Arrangement-Ivory-Roses-White-Flowers-Bouquet-Delivery-Bangkok-FLB25-212-1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/26181357/Flower-Arrangement-Ivory-Roses-White-Flowers-Bouquet-Delivery-Bangkok-FLB25-212-1-1341x1536.jpg 1341w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/26181357/Flower-Arrangement-Ivory-Roses-White-Flowers-Bouquet-Delivery-Bangkok-FLB25-212-1-600x687.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/26181357/Flower-Arrangement-Ivory-Roses-White-Flowers-Bouquet-Delivery-Bangkok-FLB25-212-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/26181357/Flower-Arrangement-Ivory-Roses-White-Flowers-Bouquet-Delivery-Bangkok-FLB25-212-1.jpg 1676w" sizes="(max-width: 300px) 100vw, 300px" alt="Front view of ivory roses and white seasonal bouquet in white wrap." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Front view of ivory roses and white seasonal bouquet in white wrap." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FLB25-212</p>

                                        <button onclick="addToCart(296133)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/ivory-roses-white-seasonal-bouquet/">Ivory Roses &#038; White Seasonal Bouquet</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>4,050.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/yellow-roses-white-lilies-gerbera-bouquet/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150832/Flower-Arrangement-Yellow-Roses-and-White-Lilies-Bouquet-Delivery-Bangkok-FLB25-289-1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150832/Flower-Arrangement-Yellow-Roses-and-White-Lilies-Bouquet-Delivery-Bangkok-FLB25-289-1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150832/Flower-Arrangement-Yellow-Roses-and-White-Lilies-Bouquet-Delivery-Bangkok-FLB25-289-1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150832/Flower-Arrangement-Yellow-Roses-and-White-Lilies-Bouquet-Delivery-Bangkok-FLB25-289-1-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150832/Flower-Arrangement-Yellow-Roses-and-White-Lilies-Bouquet-Delivery-Bangkok-FLB25-289-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150832/Flower-Arrangement-Yellow-Roses-and-White-Lilies-Bouquet-Delivery-Bangkok-FLB25-289-1.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Front view of bouquet with yellow roses, white lilies, gerbera daisies and eucalyptus, wrapped in white paper." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Front view of bouquet with yellow roses, white lilies, gerbera daisies and eucalyptus, wrapped in white paper." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FLB25-289</p>

                                        <button onclick="addToCart(295653)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/yellow-roses-white-lilies-gerbera-bouquet/">Yellow Roses, White Lilies &#038; Gerbera Bouquet</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>1,790.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/blue-roses-white-lilies-hydrangea-bouquet/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145246/Flower-Arrangement-Blue-Roses-and-White-Lilies-Bouquet-Delivery-Bangkok-FLB25-288-1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145246/Flower-Arrangement-Blue-Roses-and-White-Lilies-Bouquet-Delivery-Bangkok-FLB25-288-1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145246/Flower-Arrangement-Blue-Roses-and-White-Lilies-Bouquet-Delivery-Bangkok-FLB25-288-1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145246/Flower-Arrangement-Blue-Roses-and-White-Lilies-Bouquet-Delivery-Bangkok-FLB25-288-1-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145246/Flower-Arrangement-Blue-Roses-and-White-Lilies-Bouquet-Delivery-Bangkok-FLB25-288-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145246/Flower-Arrangement-Blue-Roses-and-White-Lilies-Bouquet-Delivery-Bangkok-FLB25-288-1.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Front view of bouquet with blue roses, white lilies, blue hydrangea and lisianthus wrapped in white paper and ribbon for Bangkok delivery." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Front view of bouquet with blue roses, white lilies, blue hydrangea and lisianthus wrapped in white paper and ribbon for Bangkok delivery." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FLB25-288</p>

                                        <button onclick="addToCart(295652)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/blue-roses-white-lilies-hydrangea-bouquet/">Blue Roses, White Lilies &#038; Hydrangea Bouquet</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>2,650.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/blush-pink-roses-white-tulips-bouquet/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150414/Flower-Arrangement-Pink-Roses-and-White-Tulips-Bouquet-Delivery-Bangkok-FLB25-287-1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150414/Flower-Arrangement-Pink-Roses-and-White-Tulips-Bouquet-Delivery-Bangkok-FLB25-287-1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150414/Flower-Arrangement-Pink-Roses-and-White-Tulips-Bouquet-Delivery-Bangkok-FLB25-287-1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150414/Flower-Arrangement-Pink-Roses-and-White-Tulips-Bouquet-Delivery-Bangkok-FLB25-287-1-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150414/Flower-Arrangement-Pink-Roses-and-White-Tulips-Bouquet-Delivery-Bangkok-FLB25-287-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150414/Flower-Arrangement-Pink-Roses-and-White-Tulips-Bouquet-Delivery-Bangkok-FLB25-287-1.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Front view of blush pink roses and white tulips bouquet with lisianthus and white fillers, wrapped in white paper and ribbon for Bangkok delivery." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Front view of blush pink roses and white tulips bouquet with lisianthus and white fillers, wrapped in white paper and ribbon for Bangkok delivery." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FLB25-287</p>

                                        <button onclick="addToCart(295651)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/blush-pink-roses-white-tulips-bouquet/">Blush Pink Roses &#038; White Tulips Bouquet</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>2,790.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/ivory-roses-white-lilies-bouquet/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145843/Flower-Arrangement-Ivory-Roses-and-White-Tulips-Bouquet-Delivery-Bangkok-FLB25-286-1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145843/Flower-Arrangement-Ivory-Roses-and-White-Tulips-Bouquet-Delivery-Bangkok-FLB25-286-1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145843/Flower-Arrangement-Ivory-Roses-and-White-Tulips-Bouquet-Delivery-Bangkok-FLB25-286-1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145843/Flower-Arrangement-Ivory-Roses-and-White-Tulips-Bouquet-Delivery-Bangkok-FLB25-286-1-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145843/Flower-Arrangement-Ivory-Roses-and-White-Tulips-Bouquet-Delivery-Bangkok-FLB25-286-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145843/Flower-Arrangement-Ivory-Roses-and-White-Tulips-Bouquet-Delivery-Bangkok-FLB25-286-1.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Front view of ivory roses and white tulips bouquet with fresh greens, wrapped in white paper and white ribbon for Bangkok delivery." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Front view of ivory roses and white tulips bouquet with fresh greens, wrapped in white paper and white ribbon for Bangkok delivery." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FLB25-286</p>

                                        <button onclick="addToCart(295650)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/ivory-roses-white-lilies-bouquet/">Ivory Roses &#038; White Lilies Bouquet</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>3,790.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/ivory-rose-blue-delphinium-bouquet/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25144744/Flower-Arrangement-Peach-and-Ivory-Imported-Roses-Bouquet-Delivery-Bangkok-FLB25-125-1-1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25144744/Flower-Arrangement-Peach-and-Ivory-Imported-Roses-Bouquet-Delivery-Bangkok-FLB25-125-1-1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25144744/Flower-Arrangement-Peach-and-Ivory-Imported-Roses-Bouquet-Delivery-Bangkok-FLB25-125-1-1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25144744/Flower-Arrangement-Peach-and-Ivory-Imported-Roses-Bouquet-Delivery-Bangkok-FLB25-125-1-1-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25144744/Flower-Arrangement-Peach-and-Ivory-Imported-Roses-Bouquet-Delivery-Bangkok-FLB25-125-1-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25144744/Flower-Arrangement-Peach-and-Ivory-Imported-Roses-Bouquet-Delivery-Bangkok-FLB25-125-1-1.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Florist holding a hand-tied bouquet of ivory roses, dusty pink roses, red blooms, blue delphiniums, and peach astilbe wrapped in white paper." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Florist holding a hand-tied bouquet of ivory roses, dusty pink roses, red blooms, blue delphiniums, and peach astilbe wrapped in white paper." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FLB25-125</p>

                                        <button onclick="addToCart(295649)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/ivory-rose-blue-delphinium-bouquet/">Ivory Rose &#038; Blue Delphinium Bouquet</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>3,990.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/yellow-gerbera-daisies-white-chrysanthemums-bouquet/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150635/Flower-Arrangement-Yellow-Gerbera-Daisies-Chrysanthemums-Bouquet-Delivery-Bangkok-FLB25-290-1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150635/Flower-Arrangement-Yellow-Gerbera-Daisies-Chrysanthemums-Bouquet-Delivery-Bangkok-FLB25-290-1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150635/Flower-Arrangement-Yellow-Gerbera-Daisies-Chrysanthemums-Bouquet-Delivery-Bangkok-FLB25-290-1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150635/Flower-Arrangement-Yellow-Gerbera-Daisies-Chrysanthemums-Bouquet-Delivery-Bangkok-FLB25-290-1-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150635/Flower-Arrangement-Yellow-Gerbera-Daisies-Chrysanthemums-Bouquet-Delivery-Bangkok-FLB25-290-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150635/Flower-Arrangement-Yellow-Gerbera-Daisies-Chrysanthemums-Bouquet-Delivery-Bangkok-FLB25-290-1.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Front view of bouquet with yellow gerbera daisies and white chrysanthemums wrapped in white paper and ribbon." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Front view of bouquet with yellow gerbera daisies and white chrysanthemums wrapped in white paper and ribbon." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FLB25-290</p>

                                        <button onclick="addToCart(295654)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/yellow-gerbera-daisies-white-chrysanthemums-bouquet/">Yellow Gerbera Daisies &#038; White Chrysanthemums Bouquet</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>2,350.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/lavender-roses-white-calla-lilies-bouquet/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150437/Flower-Arrangement-Purple-Roses-White-Calla-Lilies-Bouquet-Delivery-Bangkok-FLB25-291-1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150437/Flower-Arrangement-Purple-Roses-White-Calla-Lilies-Bouquet-Delivery-Bangkok-FLB25-291-1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150437/Flower-Arrangement-Purple-Roses-White-Calla-Lilies-Bouquet-Delivery-Bangkok-FLB25-291-1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150437/Flower-Arrangement-Purple-Roses-White-Calla-Lilies-Bouquet-Delivery-Bangkok-FLB25-291-1-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150437/Flower-Arrangement-Purple-Roses-White-Calla-Lilies-Bouquet-Delivery-Bangkok-FLB25-291-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150437/Flower-Arrangement-Purple-Roses-White-Calla-Lilies-Bouquet-Delivery-Bangkok-FLB25-291-1.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Front view of bouquet with lavender roses, white calla lilies, lisianthus, stock and silver greens wrapped in lilac paper." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Front view of bouquet with lavender roses, white calla lilies, lisianthus, stock and silver greens wrapped in lilac paper." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FLB25-291</p>

                                        <button onclick="addToCart(295655)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/lavender-roses-white-calla-lilies-bouquet/">Lavender Roses &#038; White Calla Lilies Bouquet</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>2,690.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/pink-oriental-lilies-roses-bouquet/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150241/Flower-Arrangement-Pink-Lilies-and-Pink-Roses-Bouquet-Delivery-Bangkok-FLB25-295-1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150241/Flower-Arrangement-Pink-Lilies-and-Pink-Roses-Bouquet-Delivery-Bangkok-FLB25-295-1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150241/Flower-Arrangement-Pink-Lilies-and-Pink-Roses-Bouquet-Delivery-Bangkok-FLB25-295-1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150241/Flower-Arrangement-Pink-Lilies-and-Pink-Roses-Bouquet-Delivery-Bangkok-FLB25-295-1-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150241/Flower-Arrangement-Pink-Lilies-and-Pink-Roses-Bouquet-Delivery-Bangkok-FLB25-295-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150241/Flower-Arrangement-Pink-Lilies-and-Pink-Roses-Bouquet-Delivery-Bangkok-FLB25-295-1.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Front view of bouquet with pink oriental lilies, pink roses and white lisianthus wrapped in white paper." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Front view of bouquet with pink oriental lilies, pink roses and white lisianthus wrapped in white paper." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FLB25-295</p>

                                        <button onclick="addToCart(295656)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/pink-oriental-lilies-roses-bouquet/">Pink Oriental Lilies &#038; Roses Bouquet</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>2,650.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/ivory-roses-white-chrysanthemums-bouquet/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145647/Flower-Arrangement-Ivory-Roses-and-White-Chrysanthemums-Bouquet-Delivery-Bangkok-FLB25-296-1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145647/Flower-Arrangement-Ivory-Roses-and-White-Chrysanthemums-Bouquet-Delivery-Bangkok-FLB25-296-1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145647/Flower-Arrangement-Ivory-Roses-and-White-Chrysanthemums-Bouquet-Delivery-Bangkok-FLB25-296-1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145647/Flower-Arrangement-Ivory-Roses-and-White-Chrysanthemums-Bouquet-Delivery-Bangkok-FLB25-296-1-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145647/Flower-Arrangement-Ivory-Roses-and-White-Chrysanthemums-Bouquet-Delivery-Bangkok-FLB25-296-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145647/Flower-Arrangement-Ivory-Roses-and-White-Chrysanthemums-Bouquet-Delivery-Bangkok-FLB25-296-1.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Front view of bouquet with ivory roses, white chrysanthemums and lisianthus wrapped in sage-green paper." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Front view of bouquet with ivory roses, white chrysanthemums and lisianthus wrapped in sage-green paper." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FLB25-296</p>

                                        <button onclick="addToCart(295657)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/ivory-roses-white-chrysanthemums-bouquet/">Ivory Roses &#038; White Chrysanthemums Bouquet</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>2,150.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/blue-hydrangea-white-stock-elegant-bouquet/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145051/Flower-Arrangement-Blue-Hydrangea-and-White-Stock-Bouquet-Delivery-Bangkok-FLB25-299-1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145051/Flower-Arrangement-Blue-Hydrangea-and-White-Stock-Bouquet-Delivery-Bangkok-FLB25-299-1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145051/Flower-Arrangement-Blue-Hydrangea-and-White-Stock-Bouquet-Delivery-Bangkok-FLB25-299-1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145051/Flower-Arrangement-Blue-Hydrangea-and-White-Stock-Bouquet-Delivery-Bangkok-FLB25-299-1-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145051/Flower-Arrangement-Blue-Hydrangea-and-White-Stock-Bouquet-Delivery-Bangkok-FLB25-299-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145051/Flower-Arrangement-Blue-Hydrangea-and-White-Stock-Bouquet-Delivery-Bangkok-FLB25-299-1.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Front view of bouquet with blue hydrangea, white stock and blue delphinium wrapped in white paper." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Front view of bouquet with blue hydrangea, white stock and blue delphinium wrapped in white paper." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FLB25-299</p>

                                        <button onclick="addToCart(295660)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/blue-hydrangea-white-stock-elegant-bouquet/">Blue Hydrangea &#038; White Stock Elegant Bouquet</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>2,000.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/ivory-blush-roses-with-white-tulips-pastel-bouquet/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145444/Flower-Arrangement-Ivory-and-Blush-Roses-and-White-Tulips-Bouquet-Delivery-Bangkok-FLB25-298-1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145444/Flower-Arrangement-Ivory-and-Blush-Roses-and-White-Tulips-Bouquet-Delivery-Bangkok-FLB25-298-1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145444/Flower-Arrangement-Ivory-and-Blush-Roses-and-White-Tulips-Bouquet-Delivery-Bangkok-FLB25-298-1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145444/Flower-Arrangement-Ivory-and-Blush-Roses-and-White-Tulips-Bouquet-Delivery-Bangkok-FLB25-298-1-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145444/Flower-Arrangement-Ivory-and-Blush-Roses-and-White-Tulips-Bouquet-Delivery-Bangkok-FLB25-298-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25145444/Flower-Arrangement-Ivory-and-Blush-Roses-and-White-Tulips-Bouquet-Delivery-Bangkok-FLB25-298-1.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Front view of pastel bouquet with ivory roses, blush roses, white tulips and eucalyptus in dusty-pink wrap." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Front view of pastel bouquet with ivory roses, blush roses, white tulips and eucalyptus in dusty-pink wrap." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FLB25-298</p>

                                        <button onclick="addToCart(295659)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/ivory-blush-roses-with-white-tulips-pastel-bouquet/">Ivory &#038; Blush Roses with White Tulips Pastel Bouquet</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>3,100.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/pink-lilies-peach-roses-champagne-bouquet/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150039/Flower-Arrangement-Pink-Lilies-and-Peach-Roses-Bouquet-Delivery-Bangkok-FLB25-297-1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150039/Flower-Arrangement-Pink-Lilies-and-Peach-Roses-Bouquet-Delivery-Bangkok-FLB25-297-1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150039/Flower-Arrangement-Pink-Lilies-and-Peach-Roses-Bouquet-Delivery-Bangkok-FLB25-297-1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150039/Flower-Arrangement-Pink-Lilies-and-Peach-Roses-Bouquet-Delivery-Bangkok-FLB25-297-1-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150039/Flower-Arrangement-Pink-Lilies-and-Peach-Roses-Bouquet-Delivery-Bangkok-FLB25-297-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25150039/Flower-Arrangement-Pink-Lilies-and-Peach-Roses-Bouquet-Delivery-Bangkok-FLB25-297-1.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Front view of bouquet with pink lilies, peach roses and champagne chrysanthemums wrapped in white paper and ribbon." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Front view of bouquet with pink lilies, peach roses and champagne chrysanthemums wrapped in white paper and ribbon." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FLB25-297</p>

                                        <button onclick="addToCart(295658)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/pink-lilies-peach-roses-champagne-bouquet/">Pink Lilies &#038; Peach Roses Champagne Bouquet</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>2,450.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/ivory-blush-roses-with-white-freesia-pastel-bouquet/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25153359/Flower-Arrangement-Ivory-and-Blush-Roses-White-Freesia-Bouquet-Delivery-Bangkok-FLB25-101-1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25153359/Flower-Arrangement-Ivory-and-Blush-Roses-White-Freesia-Bouquet-Delivery-Bangkok-FLB25-101-1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25153359/Flower-Arrangement-Ivory-and-Blush-Roses-White-Freesia-Bouquet-Delivery-Bangkok-FLB25-101-1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25153359/Flower-Arrangement-Ivory-and-Blush-Roses-White-Freesia-Bouquet-Delivery-Bangkok-FLB25-101-1-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25153359/Flower-Arrangement-Ivory-and-Blush-Roses-White-Freesia-Bouquet-Delivery-Bangkok-FLB25-101-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25153359/Flower-Arrangement-Ivory-and-Blush-Roses-White-Freesia-Bouquet-Delivery-Bangkok-FLB25-101-1.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Front view of pastel bouquet with ivory roses, blush roses, white freesia and eucalyptus in blush pink wrap." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Front view of pastel bouquet with ivory roses, blush roses, white freesia and eucalyptus in blush pink wrap." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FLB25-101</p>

                                        <button onclick="addToCart(295696)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/ivory-blush-roses-with-white-freesia-pastel-bouquet/">Ivory &#038; Blush Roses with White Freesia Pastel Bouquet</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>2,250.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                        <li class="splide__slide">

                            <div class="topSellingItem">
                                <div class="topSellingImage">

                                    <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/orange-lilies-mixed-roses-pastel-wildflowers-bouquet/">
                                                                                                    <img width="100%" height="100%" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25153754/Flower-Arrangement-Orange-Lilies-Mixed-Roses-Pastel-Wildflowers-Bouquet-Delivery-Bangkok-FLB25-102-1-262x300.jpg 262w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25153754/Flower-Arrangement-Orange-Lilies-Mixed-Roses-Pastel-Wildflowers-Bouquet-Delivery-Bangkok-FLB25-102-1-894x1024.jpg 894w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25153754/Flower-Arrangement-Orange-Lilies-Mixed-Roses-Pastel-Wildflowers-Bouquet-Delivery-Bangkok-FLB25-102-1-768x880.jpg 768w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25153754/Flower-Arrangement-Orange-Lilies-Mixed-Roses-Pastel-Wildflowers-Bouquet-Delivery-Bangkok-FLB25-102-1-600x688.jpg 600w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25153754/Flower-Arrangement-Orange-Lilies-Mixed-Roses-Pastel-Wildflowers-Bouquet-Delivery-Bangkok-FLB25-102-1-64x73.jpg 64w, https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/25153754/Flower-Arrangement-Orange-Lilies-Mixed-Roses-Pastel-Wildflowers-Bouquet-Delivery-Bangkok-FLB25-102-1.jpg 960w" sizes="(max-width: 300px) 100vw, 300px" alt="Front view of bouquet with orange lilies, mixed roses, lisianthus and wildflowers wrapped in cream paper." decoding="async" loading="lazy">
                                                                                            </a>

                                    <a href="https://basketeer.com/login" class="addToWishlist">
                                                    <img width="31" height="31" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/heart-empty.svg" alt="Front view of bouquet with orange lilies, mixed roses, lisianthus and wildflowers wrapped in cream paper." decoding="async" loading="lazy" />
                                                </a>



                                    <div class="product-tags">
                                        <div class="product-badge new-arrival">New Arrival</div>
                                    </div>

                                </div>
                                <div class="topSellingInfo d-flex">
                                    <div class="col-12 col-lg-9">


                                        <p class="topSellingproductCode">FLB25-102</p>

                                        <button onclick="addToCart(295697)" class="btnAdd"><i class="bi bi-plus"></i><span class="addToCart">ADD</span></button>
                                        <h4 class="topSellingTitle">
                                            <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/orange-lilies-mixed-roses-pastel-wildflowers-bouquet/">Orange Lilies, Mixed Roses &#038; Pastel Wildflowers Bouquet</a>
                                        </h4>
                                        <p class="topSellingPrice"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#3647;</span>2,295.00</bdi>
                                            </span>
                                        </p>


                                    </div>
                                </div>
                            </div>

                        </li>
                    </ul>
                </div>
            </div>
            <div class="mt-3 text-center">
                <a href="https://basketeer.com/flowers-by-basketeer/flower-gifts/all-bouquet-flowers/" class="d-inline-block btnBlack">View All</a>
            </div>
        </div>
    </section>
    <script>
        document.addEventListener("DOMContentLoaded", function($) {
            new Splide('.basketeer_splide_1749669115', {
                perPage: 5,
                perMove: 1,
                flickMaxPages: 3,
                updateOnMove: true,
                pagination: false,
                throttle: 300,
                gap: 16,
                arrows: {
                    prev: '<button class="prv"><i class="bi-chevron-left bi"></i></button>',
                    next: '<button class="nxt"><i class="bi-chevron-right bi"></i></button>'
                },
                breakpoints: {
                    991: {
                        perPage: 3,
                    },
                    767: {
                        perPage: 2,
                    },
                    575: {
                        drag: true,
                        fixedWidth: 170,
                        gap: 10,
                    },
                }
            }).mount();
        })
    </script>
    <div class="container-fluid">
        <style>
            /* Reusable grey tint for icons */

            .icon-grey {
                filter: brightness(0) saturate(100%) invert(45%) sepia(0%) saturate(0%) hue-rotate(180deg) brightness(90%) contrast(90%);
            }
        </style>

        <div class="cta">
            <div class="d-flex flex-column flex-lg-row align-items-center" style="background-color: #EEE4CE;">
                <div class="order-1 order-lg-2 p-0 cta-image" style="flex: 1;">
                    <img src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/29162506/Corporate20Banner20-20SCGJWD20-20Wooden.jpg" alt="" style="aspect-ratio: 100 / 66; object-fit: cover; width: 100%;">
                </div>
                <div class="order-2 order-lg-1 p-4 text-center cta-text" style="flex: 1;">
                    <h1 style="color: #777777;">
                        Corporate Gifting <br>
                        <span style="font-size: 80%; color: #6582A1;">Create Uniquely Memorable Gifts</span>
                    </h1>
                    <p style="color: #6582A1;">Fully Customizable Solutions For Our Corporate Clients</p>

                    <div class="d-flex flex-row justify-content-center mb-3">
                        <div class="mx-1 ms-xl-0 px-3" style="color: rgb(60, 60, 60);">
                            <img src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/29165224/Paper-Box-Custom-Basketeer-Corporate.png" alt="Paper Box Icon" class="icon-grey" style="max-width: 100px; width: 100%;"><br> Paper
                            Boxes
                        </div>

                        <div class="mx-1 px-3" style="color: rgb(60, 60, 60);">
                            <img src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/29165128/Wooden-Box-Custom-Basketeer-Corporate.png" alt="Wooden Box Icon" class="icon-grey" style="max-width: 100px; width: 100%;"><br> Wooden
                            Boxes
                        </div>

                        <div class="mx-1 px-3" style="color: rgb(60, 60, 60);">
                            <img src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/10/29165154/Ribbon-Custom-Basketeer-Corporate.png" alt="Ribbon Icon" class="icon-grey" style="max-width: 100px; width: 100%;"><br> Ribbons
                        </div>
                    </div>

                    <p class="pt-3 text-center">
                        <a href="https://basketeer.com/corporate-gift-baskets/" class="d-inline-block btnBlack">View all</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <section class="ourClients">
        <div class="ourClientsHeader">
            <div class="col-12 col-md-2">
                <h2 class="sectionHeading text-center text-md-start"><i>Our</i> Clients</h2>
            </div>
            <div class="clientLogos" style="background:#EDE4D380;">
                <div class="container-fluid d-flex justify-content-between align-items-center">
                    <img width="auto" height="auto" class="clientLogo" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/08/28021901/clientLogo6.png" alt="Audi">
                    <img width="auto" height="auto" class="clientLogo" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/08/28022018/clientLogo5.png" alt="brand">
                    <img width="auto" height="auto" class="clientLogo" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/08/28022108/clientLogo3.png" alt="TCC ASSETS">
                    <img width="auto" height="auto" class="clientLogo" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/08/28022148/clientLogo4.png" alt="brand">
                    <img width="auto" height="auto" class="clientLogo" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/08/28022253/clientLogo2.png" alt="brand">
                    <img width="auto" height="auto" class="clientLogo" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/08/28022329/clientLogo1.png" alt="brand">
                </div>
            </div>
        </div>

    </section>
    <!-- Blog Section -->
    <section class="ourJournals">
        <div class="container-fluid">
            <div class="text-center ourJournalsHeader">
                <h2 class="sectionHeading">Our Journal</h2>
                <h4 class="sectionSubHeading">Happiness guarantee</h4>
            </div>
            <div class="ourJournalsContent">
                <div class="d-flex align-items-start justify-content-center journals">
                    <div class="journal">
                        <a href="https://basketeer.com/flower-delivery-in-bangkok-how-flowers-by-basketeer-keeps-blooms-fresh-despite-heat-and-traffic/">
								<img class="journalImage" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/30094524/flowers-by-basketeer-flowers-white-lily-bouquet-express-delivery-bangkok-1024x683.jpeg" alt="A person wearing a helmet sits on a red motorbike, while a woman behind them holds a large bouquet of white lilies. They are outdoors near greenery and a pavement." width="100%" decoding="async" loading="lazy"></a>
                        <p class="journalSubHeading">

                            <a href="https://basketeer.com/category/flowers-post/">Flowers by Basketeer</a> </p>
                        <h5 class="journalSubHeading"><a href="https://basketeer.com/flower-delivery-in-bangkok-how-flowers-by-basketeer-keeps-blooms-fresh-despite-heat-and-traffic/">Flower Delivery in Bangkok: How Flowers by Basketeer. Keeps Blooms Fresh Despite Heat and Traffic</a></h5>
                        <p class="journalText">
                            Flowers by Basketeer offers fresh flower delivery in Bangkok, ensuring every bouquet arrives beautifully, even in hot weather and heavy traffic. Our EV Delivery also helps protect the environment. </p>
                        <p class="readmore"><a href="https://basketeer.com/flower-delivery-in-bangkok-how-flowers-by-basketeer-keeps-blooms-fresh-despite-heat-and-traffic/">Read More</a></p>
                    </div>
                    <div class="journal">
                        <a href="https://basketeer.com/heritage-you-can-taste-how-wartime-rationing-inspired-charlottes-spongecake/">
								<img class="journalImage" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/26141545/charlotte-chef-baking-class-whisk-flour-bangkok-1024x683.jpeg" alt="Two men, one in a chef’s uniform and the other in a white shirt and apron, stand in a white kitchen. The man in the shirt whisks a yellow mixture in a bowl whilst the chef gives instructions. Baking ingredients are on the worktop." width="100%" decoding="async" loading="lazy"></a>
                        <p class="journalSubHeading">

                            <a href="https://basketeer.com/category/charlotte-post/">Charlotte</a> </p>
                        <h5 class="journalSubHeading"><a href="https://basketeer.com/heritage-you-can-taste-how-wartime-rationing-inspired-charlottes-spongecake/">Heritage You Can Taste : How Wartime Rationing Inspired Charlottes Spongecake</a></h5>
                        <p class="journalText">
                            When people hear the word &#039;cake,&#039; many might think of sweetness, luxury at a party, or a staple on an afternoon tea table. But for us, cake is a story — a legacy that travels through time. </p>
                        <p class="readmore"><a href="https://basketeer.com/heritage-you-can-taste-how-wartime-rationing-inspired-charlottes-spongecake/">Read More</a></p>
                    </div>
                    <div class="journal">
                        <a href="https://basketeer.com/spongecake-and-decoration-in-dialogue-crafting-perfection-post/">
								<img class="journalImage" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/24164203/charlotte-spongecake-classic-cake-bangkok-1-1024x683.jpg" alt="A Victoria sponge cake with cream and jam filling sits on a white plate. Surrounding it are a teapot, a cup of tea, and white decorative plates, all set on a white tablecloth." width="100%" decoding="async" loading="lazy"></a>
                        <p class="journalSubHeading">

                            <a href="https://basketeer.com/category/charlotte-post/">Charlotte</a> </p>
                        <h5 class="journalSubHeading"><a href="https://basketeer.com/spongecake-and-decoration-in-dialogue-crafting-perfection-post/">Spongecake and Decoration in Dialogue: Crafting Perfection</a></h5>
                        <p class="journalText">
                            Discover the secret behind Charlotte&#039;s cakes where the soft, moist sponge is the heart, and the decoration is living art. Learn why our cakes are loved in Thailand. </p>
                        <p class="readmore"><a href="https://basketeer.com/spongecake-and-decoration-in-dialogue-crafting-perfection-post/">Read More</a></p>
                    </div>
                    <div class="journal">
                        <a href="https://basketeer.com/more-than-a-florist-a-storyteller-through-flowers/">
								<img class="journalImage" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/09/09133143/Florist20Scene1_MGL8096-1024x683.jpg" alt="A florist wearing a green apron arranges a white rose at a table filled with various flowers, ribbons, and wrapping paper. Shelves behind her display vases and glassware. The setting is bright and organised." width="100%" decoding="async" loading="lazy"></a>
                        <p class="journalSubHeading">

                            <a href="https://basketeer.com/category/flowers-post/">Flowers by Basketeer</a> </p>
                        <h5 class="journalSubHeading"><a href="https://basketeer.com/more-than-a-florist-a-storyteller-through-flowers/">More Than a Florist: A Storyteller Through Flowers</a></h5>
                        <p class="journalText">
                            When you hear the word florist, what comes to mind? For many, it’s simply someone who sells flowers or ties them into a neat bouquet. But in truth, being a florist goes far deeper than that. </p>
                        <p class="readmore"><a href="https://basketeer.com/more-than-a-florist-a-storyteller-through-flowers/">Read More</a></p>
                    </div>
                </div>
            </div>
            <div class="mt-4 text-center"><a class="btnBlack" href="https://basketeer.com/blogs/">Discover More</a></div>
        </div>
    </section>
    <section class="clientTestimonials" style="background:#EDE4D399">
        <div class="container-fluid">
            <div class="clientTestimonialsHeader text-center">
                <h2 class="sectionHeading">What People <i>Are</i> Saying</h2>
                <h4 class="sectionSubHeading">Trusted Google Reviews</h4>
            </div>


            <div data-src="https://cdn.trustindex.io/loader.js?8215cfd558388486cc06e9ba027"></div>
            <div class=" text-center" style="margin-bottom: 20px;">
                <a class="btnBlack" href="https://g.page/r/CdKLezQnBkV-EB0/review" target="_blank">See All Reviews</a>
            </div>

        </div>
    </section>
    <style>
        .ti-widget.ti-goog {
            margin-bottom: 50px;
        }
    </style>

    <section class="whyChooseUs">
        <div class="container-fluid">
            <div class="whyChooseusHeader text-center">
                <h2 class="sectionHeading">Why <i>Choose</i> Us?</h2>
                <h4 class="sectionSubHeading">Bangkok same day delivery</h4>
            </div>
            <div class="whyChooseUsFeatures justify-content-center align-items-start">
                <div class="whyChooseUsFeature text-center">
                    <img width="68" height="68" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/whyChooseUs4.svg" alt="Family Owned, Locally Grown & Always Fabulous">
                    <h5>Family Owned, Locally Grown & Always Fabulous</h5>
                    <p>Basketeer started just over a decade ago, it's an easy time to remember, not just because of starting my first business, but because I was still pregnant with Ray, who ended up being the driving force behind my determination to make
                        Basketeer the huge success it is today.</p>
                </div>
                <element class="d-none d-lg-block d-xl-block" style="place-self:end;"></element>
                <div class="whyChooseUsFeature text-center">
                    <img width="68" height="68" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/whyChooseUs1.svg" alt="Same Day and 2 Hour Express Delivery">
                    <h5>Same Day and 2 Hour Express Delivery</h5>
                    <p>With free hamper delivery everywhere in Bangkok, we know our luxury range offers amazing value and absolute convenience for our customers. We've decided NOT to partner with Bangkok's most extensive delivery networks. Instead we created
                        our own!</p>
                </div>
                <element class="d-none d-lg-block d-xl-block" style="place-self:end;"></element>
                <div class="whyChooseUsFeature text-center">
                    <img width="68" height="68" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/whyChooseUs2.svg" alt="Online Tracking">
                    <h5>Online Tracking <br>System</h5>
                    <p>Not in? Not a problem… We provide all customers with online tracking via email or sms updates. So you don't have to worry about popping out to Starbucks to get your morning latte or cancel or last minute hair appointment. Now you know
                        exactly where your hamper is and when it will be delivered.</p>
                </div>
                <element class="d-none d-lg-block d-xl-block" style="place-self:end;"></element>
                <div class="whyChooseUsFeature text-center">
                    <img width="68" height="68" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/whyChooseUs3.svg" alt="Personalised Gift Hampers">
                    <h5>Personalised Gift Hampers <br>Available</h5>
                    <p>Basketeer started just over a decade ago, it's an easy time to remember, not just because of starting my first business, but because I was still pregnant with Ray, who ended up being the driving force behind my determination to make
                        Basketeer the huge success it is today.</p>
                </div>
            </div>
        </div>
    </section>
    <!-- <section class="instagramImages">
	<div class="container-fluid">
		<div class="instaInfo d-lg-none text-center">
			<img width="22" max-width="22" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/instagramLogo.svg">
			<h3 class="instagramTitle">Follow US</h3>
			<p class="instagramHandle">@basketeer_thailand</p>
		</div>
		<div class="instaImages align-items-center">
			<a href="https://www.instagram.com/basketeer_thailand/">
				<div class="instaImage">

					<img width="100%" height="100%" decoding="async" loading="lazy" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/instaImage-1.webp" loading="lazy">

				</div>
			</a>
			<a href="https://www.instagram.com/basketeer_thailand/">
				<div class="instaImage">

					<img width="100%" height="100%" decoding="async" loading="lazy" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/instaImage-2.webp" loading="lazy">

				</div>
			</a>
			<a href="https://www.instagram.com/basketeer_thailand/">
				<div class="instaImage">

					<img width="100%" height="100%" decoding="async" loading="lazy" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/instaImage-3.webp" loading="lazy">

				</div>
			</a>
			<a href="https://www.instagram.com/basketeer_thailand/">
				<div class="instaImage">

					<img width="100%" height="100%" decoding="async" loading="lazy" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/instaImage-4.webp" loading="lazy">

				</div>
			</a>
			<a href="https://www.instagram.com/basketeer_thailand/">
				<div class="instaImage">

					<img width="100%" height="100%" decoding="async" loading="lazy" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/instaImage-5.webp" loading="lazy">

				</div>
			</a>
			<a href="https://www.instagram.com/basketeer_thailand/">
				<div class="instaImage">

					<img width="100%" height="100%" decoding="async" loading="lazy" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/instaImage-1.webp" loading="lazy">

				</div>
			</a>
			<a href="https://www.instagram.com/basketeer_thailand/">
				<div class="instaImage">

					<img width="100%" height="100%" decoding="async" loading="lazy" src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/instaImage-2.webp" loading="lazy">

				</div>
			</a>
		</div>
	</div>
</section> -->


    <section class="testimonials" style="background:#EDE4D380">
        <div class="container-fluid">
            <div class="testimonialsHeader text-center">
                <h2 class="sectionHeading">Testimonials</h2>
                <h4 class="sectionSubHeading"></h4>
            </div>
            <div class="testimonialItems">
                <div class="
                            ">

                    <img class="testimonialImage" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/11/17132426/Screen-Shot-2566-11-17-at-13.24.07.png" sizes="(max-width: 300px) 100vw, 300px" decoding="async" loading="lazy" alt="A sophisticated individual with flowing dark hair adorns a chic pink dress, accentuated by an elegant large red bow atop their head. They stand gracefully before a luxurious gold and black backdrop, which is artfully embellished with shimmering gold balloons and twinkling string lights, creating an inviting and celebratory ambiance. The scene subtly features the Basketeer brand logo amongst the décor elements, enhancing the overall sense of opulence and exclusivity."
                    />
                </div>
                <div class="
                            big">

                    <img class="testimonialImage" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/11/17124715/13023.jpg" sizes="(max-width: 300px) 100vw, 300px" decoding="async" loading="lazy" alt="Two elegant women grace the front of a luxurious house. One exudes joy as she holds an array of heart-shaped, pink balloons, while the other beams with delight, carrying an opulent large teddy bear and stylish gift bags adorned with the Basketeer logo. The scene is set against the backdrop of a sleek gray car and upscale neighboring residences, imbuing an air of sophistication and celebration."
                    />
                </div>
                <div class="
                            horizontal">

                    <img class="testimonialImage" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/11/17130139/S__13615115.jpg" sizes="(max-width: 300px) 100vw, 300px" decoding="async" loading="lazy" alt="A person, exuding chic style in a sunny yellow hat and sophisticated brown trousers, holds an exquisite Basketeer wicker basket. The luxurious basket overflows with premium jars of honey and an enchanting bouquet of fresh flowers, all elegantly tied together with a signature yellow ribbon bearing the Basketeer logo. The individual smiles warmly against the backdrop of a beautifully ornate black gate, creating an inviting and upscale scene."
                    />
                </div>
                <div class="
                            horizontal">

                    <img class="testimonialImage" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/11/13092724/Flower-in-basket-vase-and-box11.jpg" sizes="(max-width: 300px) 100vw, 300px" decoding="async" loading="lazy" alt="A luxurious bouquet of pastel-colored flowers featuring elegant white roses, charming pink gerbera daisies, and delicate light lilac blossoms. This sophisticated arrangement is presented in a clear vase, exquisitely adorned with a white ribbon showcasing the word "
                        FLOWERET " in refined black lettering. Set against a serene peach backdrop, this stunning floral display exudes timeless elegance and invites an air of opulence into any space." />
                </div>
                <div class="
                            vertical">

                    <img class="testimonialImage" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/11/16124752/1698203110460.jpg" sizes="(max-width: 300px) 100vw, 300px" decoding="async" loading="lazy" alt="Two elegant women stand side by side, radiating joy as they hold a beautifully curated basket adorned with the prestigious Basketeer logo. The basket overflows with vibrant, fresh flowers and premium packets of Chame Collagen supplements, a testament to luxury and wellness. The woman on the left showcases her style in a sophisticated brown and beige dress, while her companion exudes chic simplicity in a pristine beige blazer and top. Their smiles reflect the delight of indulging in such an exclusive gift from Basketeer."
                    />
                </div>
                <div class="
                            vertical">

                    <img class="testimonialImage" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/11/14100414/Flower-in-basket-vase-and-box37.jpg" sizes="(max-width: 300px) 100vw, 300px" decoding="async" loading="lazy" alt="A person elegantly cradles a lavish bouquet of blue, white, and green blooms, artfully wrapped in rich deep blue and translucent paper. The arrangement is adorned with an exquisite white and blue ribbon featuring the distinguished Basketeer logo. The mysterious giver is partially obscured behind the opulent floral masterpiece, donning a crisp white shirt complemented by a sophisticated watch."
                    />
                </div>
                <div class="
                            horizontal2">

                    <img class="testimonialImage" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/11/14091652/Flower-in-basket-vase-and-box25.jpg" sizes="(max-width: 300px) 100vw, 300px" decoding="async" loading="lazy" alt="A person elegantly cradles an opulent bouquet of magnificent blue roses, delicate pink blooms, and lush greenery against a minimalist backdrop. The luxurious arrangement is wrapped in a pastel pink paper and adorned with an exquisite ribbon. The bouquet emanates a sense of vibrant elegance and sophistication. Notably, the wrapping showcases the prestigious Basketeer logo, underscoring the brand's commitment to luxury and beauty in every detail."
                    />
                </div>
                <div class="
                            horizontal2">

                    <img class="testimonialImage" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/11/15125716/3700-1.png" sizes="(max-width: 300px) 100vw, 300px" decoding="async" loading="lazy" alt="A person elegantly holds a lavish bouquet, adorned with an exquisite array of pink, white, and yellow flowers. Nestled within the blossoms are sophisticated blue packages labeled "
                        Collagen " and adorable small yellow teddy bears. The arrangement is exquisitely wrapped in soft blue paper and gracefully tied with a luxurious blue ribbon bearing the Basketeer logo, epitomizing opulence and charm." />
                </div>
                <div class="
                            horizontal">

                    <img class="testimonialImage" srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/11/16125309/S__51200037.jpg" sizes="(max-width: 300px) 100vw, 300px" decoding="async" loading="lazy" alt="Two elegant women pose gracefully against an opulent blue backdrop adorned with the empowering words "
                        Women
                        's Power." The regal woman on the right, crowned in splendor, wears a stunning blue dress and cradles a lavish bouquet of vibrant red roses. Beside her stands another sophisticated woman in a pristine white suit, exuding confidence as she holds an exquisite bouquet of roses and beautifully wrapped Basketeer gift boxes. Each detail reflects the brand's commitment to luxury and refinement. " />
                        </div>
                                                    <div class=" horizontal ">

                            <img class="testimonialImage "
                                 srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/11/17124526/S__21069886.jpg "
                                 sizes="(max-width: 300px) 100vw, 300px " decoding="async " loading="lazy " alt="A woman with flowing black hair beams with joy as she cradles an opulent bouquet of vibrant red roses elegantly wrapped in crystal-clear
                        plastic. She is adorned in a chic, sleeveless grey dress and stands amidst a lush backdrop of greenery and blooming flowers. The bouquet exudes luxury, complete with a tasteful ribbon that bears the prestigious Basketeer logo, symbolizing
                        exquisite craftsmanship and elegance. " />
                        </div>
                                                    <div class=" ">

                            <img class="testimonialImage "
                                 srcset="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/11/16125755/S__22233145.jpg "
                                 sizes="(max-width: 300px) 100vw, 300px " decoding="async " loading="lazy " alt="Two elegant women are beaming with joy as they pose for a selfie, lovingly cradling a luxurious, round clear container brimming with an
                        exquisite selection of strawberries, blueberries, and other gourmet fruits. The backdrop is a vibrant and artful wall mural that enhances the richness of the scene. A sophisticated ribbon bearing the Basketeer logo elegantly adorns
                        the container, emphasizing the exclusivity and premium quality of this delightful offering. Thai text and charming heart emojis add an extra layer of warmth and affection to this inviting moment. " />
                        </div>
                                        </div>
                <a class="btnBlack " href="https://basketeer.com/testimonials ">Discover More</a>
            </div>
        </section>

    
<style>
    section.testimonials {
        text-align: center;
    width: 100%;
    display: inline-block;
}

section.testimonials a.btnBlack {
    display: inline-block;
    margin-top: 40px;
    margin-bottom: 20px;
}

.testimonialItems {
    margin-top: 20px;
}
    .testimonialItems {
        display: grid;
    grid-gap: 10px;
    grid-template-columns: repeat(auto-fit, minmax(165px, 1fr));
    grid-auto-rows: 250px;
}
.testimonialItems div {
    overflow: hidden;
    border-radius: 9px;
}
.horizontal {
grid-column: span 2;
}
.vertical {
grid-row: span 2;
}
.big {
grid-column: span 4;
grid-row: span 2;
}
.horizontal2 {
    grid-column: span 2;
    grid-row: span 2;
}
.testimonialItems img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}
@media screen and (min-width:1600px) and (max-width:1900px){
    .testimonialItems {
    grid-template-columns: repeat(auto-fit, minmax(9%, 1fr));
    grid-auto-rows: 250px;
    }
    
}
@media screen and (min-width:1200px) and (max-width:1600px){
    .testimonialItems {
    grid-template-columns: repeat(auto-fit, minmax(9%, 1fr));
    grid-auto-rows: 200px;
    }
    
}
@media screen and (min-width:960px) and (max-width:1200px){
.testimonialItems {
    display: grid;
    grid-gap: 10px;
    grid-template-columns: repeat(auto-fit, minmax(9%, 1fr));
    grid-auto-rows: 120px;
}
}
@media screen and (min-width:768px) and (max-width:959px){
    .testimonialItems {
        display: grid;
        grid-gap: 10px;
        grid-template-columns: repeat(auto-fit, minmax(8.5%, 1fr));
        grid-auto-rows: 100px;
    }
}
@media screen and (max-width:768px){

    .testimonialItems div {
    grid-column: span 1;
    grid-row: span 1;
}
.horizontal {grid-row: span 2 !important;grid-column: span 1 !important;}
.vertical {grid-row: span 1 !important;grid-column: span 0 !important;}
.big {grid-column: span 2 !IMPORTANT;grid-row: span 2 !important;}
.horizontal2 {
    grid-column: span 1 !IMPORTANT;
    grid-row: span 2 !important;
}
.testimonialItems {
    display: grid;
    grid-gap: 5px;
    grid-template-columns: repeat(auto-fit, minmax(23.5%, 1fr));
    grid-auto-rows: 90px;
}
.testimonialItems div {
    overflow: hidden;
    border-radius: 5px;
}
}

</style>
<style>
    #comments {
        display: none;
    }

    .footerTopLeft>h4 {
        font-family: 'EB Garamond';
        font-size: 28px;
        font-weight: 400;
        line-height: 33px;
        letter-spacing: 0.01em;
        text-align: left;
    }

    .footerTopLeft>h4>span {
        font-size: 26px;
    }

    .footerTopRight>h6 {
        font-family: EB Garamond;
        font-size: 20px;
        font-weight: 600;
        line-height: 24px;
        letter-spacing: 0em;
        text-align: right;
    }

    .footerTopRight>p {
        font-family: Montserrat;
        font-size: 12px;
        font-weight: 400;
        line-height: 20px;
        letter-spacing: 0em;
        text-align: right;
    }

    .footerTop {
        padding: 18px 0 14px;
    }

    .mainFooter {
        border-top: 1px solid #CBAB7C;
        padding: 35px 38px 84px 46px;
        position: relative;
    }

    .mainFooterLeft {
        padding-right: 48px !important;
        border-right: 1px solid #CBAB7C;
    }

    .mainFooterRight {
        padding-left: 41px !important;
    }

    .footerAbout {
        font-family: Montserrat;
        font-size: 14px;
        font-weight: 400;
        line-height: 24px;
        letter-spacing: 0em;
        margin-top: 16px;
        margin-bottom: 20px;
    }

    .footerTitle {
        font-family: EB Garamond;
        font-size: 16px;
        font-weight: 600;
        line-height: 21px;
        letter-spacing: 0em;
        text-align: left;
    }

    .footerAddress {
        font-family: Montserrat;
        font-size: 13px;
        font-weight: 600;
        line-height: 18px;
        letter-spacing: 0em;
        text-align: center;
        column-gap: 3px;
        margin-bottom: 24px;
    }

    .socialIcon {
        column-gap: 11px;
    }

    .footerTitle {
        font-family: EB Garamond;
        font-size: 17px;
        font-weight: 600;
        line-height: 21px;
        letter-spacing: 0em;
        text-align: left;
        margin-bottom: 11px;
        position: relative;
    }

    .footerLink {
        display: block;
        font-family: Montserrat;
        font-size: 13px;
        font-weight: 400;
        line-height: 28px !important;
        letter-spacing: 0em;
        text-align: left;
    }

    .footerLink:hover {
        text-decoration: underline;
        text-underline-offset: 3px;
    }

    .footerMenuBottom {
        margin-top: 31px;
    }

    .footerBottom h6 {
        margin-bottom: 0;
        font-family: EB Garamond;
        font-size: 14px;
        font-weight: 400;
        line-height: 18px;
        letter-spacing: 0em;
        text-align: left;
    }

    .socialLink {
        column-gap: 11px;
    }

    .footerBottom .container-fluid {
        padding-top: 0;
        padding-bottom: 0;
    }

    .footerBottomLeft,
    .footerBottomRight {
        column-gap: 15px;
    }

    .copywrite {
        padding: 4px 0 8px;
    }

    small {
        font-family: Montserrat;
        font-size: 11px;
        font-weight: 400;
        line-height: 18px;
        letter-spacing: 0em;
        text-align: center;
    }

    .footerCabImage {
        position: absolute;
        right: 0;
        bottom: 0;
    }

    .footerAddress p {
        margin-bottom: 0;
    }

    @media only screen and (max-width: 991px) {
        .footerMenuMobileTop {
            display: flex;
            justify-content: space-between;
        }

        .socialLink {
            column-gap: 11px;
            width: auto;
        }

    }


    @media only screen and (max-width: 767px) {
        /* === Footer Mobile === */

        section.footerBottom {
            padding: 20px 18px;
        }

        .footerMenuMobileTop {
            margin-top: 29px;
            margin-bottom: 20px;
        }

        .footerBottomLeft,
        .footerBottomRight {
            text-align-last: center;
        }

        .footerBottom h6 {
            font-size: 18px;
            margin-bottom: 10px;
        }

        .footerBottomLeft {
            margin-bottom: 12px;
        }

        .footerBottomRight {
            justify-content: center !important;
            align-items: baseline;
            column-gap: 6px;
        }

        .footerBottomRight img {
            width: 43px;
            height: 14px;
        }

        .socialLink {
            width: 50%;
        }
    }

    @media only screen and (max-width: 767px) {
        .payment-method {
            width: 100%;
        }
    }
</style>

<footer>
    <section class="d-lg-block d-xl-block footerTop d-none " style="background:#C09A5C ">
        <div class="container-fluid ">
            <div class="footerTopInfo ">
                <div class="d-flex flex-nowrap align-items-center justify-content-between ">
                    <div class="d-flex align-items-center px-0 footerTopLeft col-8 ">
                        <h4 class="text-white ">THE BIGGEST ONLINE GIFT STORE IN THAILAND</br>
                            <span>With excellent customer service and delivery teams</span>
                        </h4>
                    </div>
                    <div class="d-flex flex-column justify-content-end px-0 footerTopRight col-4 ">
                        <h6 class="text-white ">24/7 Delivery Service Team</h6>
                        <p class="text-white ">We're open 24 hours a day, everyday, for orders and delivery</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="d-md-block d-sm-block d-xs-block footerTopMobile d-lg-none d-xl-none " style="background:#C09A5C ">
        <div class="container-fluid ">
            <div class="footerTopMobileInfo ">
                <div class="text-center ">
                    <div class="align-items-center px-0 ">
                        <h4 class="text-white ">CAN WE HELP?</h4>
                        <div class="d-flex flex-wrap footerMenuMobileTop ">
                            <div class="d-flex align-items-center socialLink col-6 "><img width="16 " height="16 " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/whatsappIcon.svg " alt=" "><a href="https://wa.me/66939516639
                        " target="_blank " class="text-white footerLink ">whatsapp</a></div>
                            <div class="d-flex align-items-center socialLink col-6 "><img width="16 " height="16 " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/emailIcon.svg " alt=" "><a href="/cdn-cgi/l/email-protection#b2dbdcd4ddf2d0d3c1d9d7c6d7d7c09cd1dd9cc6da
                        " target="_blank " class="text-white footerLink "><span class="__cf_email__ " data-cfemail="feb7909891be9c9f8d959b8a9b9b8cd09d91d08a96 ">[email&#160;protected]</span></a></div>
                            <div class="d-flex align-items-center socialLink col-6 "><img width="16 " height="16 " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/messengerIcon.svg " alt=" "><a href="https://www.facebook.com/messages/t/166151743584888
                        " target="_blank " class="text-white footerLink ">Messenger</a></div>
                            <div class="d-flex align-items-center socialLink col-6 "><img width="16 " height="16 " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/lineIcon.svg " alt=" "><a href="http://line.me/ti/p/@basketeer
                        " target="_blank " class="text-white footerLink ">@Basketeer</a></div>
                            <div class="d-flex align-items-center socialLink col-6 "><img width="16 " height="16 " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/telephoneIcon.svg " alt=" "><a href="tel:+66028215042
                        " target="_blank " class="text-white footerLink ">+66(0)2 821 5042</a></div>
                        </div>
                        <hr class="hr hr-blurry " />
                        <div class="footerMenuMobileMid ">
                            <h6 class="text-white text-center ">24/7 Delivery Service Team</h6>
                            <p class="text-white text-center ">We're open 24 hours a day, everyday, for orders and delivery</p>
                        </div>
                        <div class="footerMenuMobileBottom ">
                            <div class="text-white text-center footerTitle ">Customer Support Hours</div>
                            <p class="text-white text-center footerLink ">Mon - Fri 08.00-18.00 </p>
                            <p class="text-white text-center footerLink ">Sat - Sun 08.00-17.00</p>
                        </div>
                        <img class="cabFooter " width="179 " height="94 " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/basketeerCab.svg " alt=" ">
                    </div>
                </div>
            </div>
            <div class="d-flex flex-column align-items-center px-0 footerMainMobile ">
                <img class="footerlogo " width="99 " height="136 " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/basketeerFooterLogo.svg " alt=" ">
                <p class="text-white text-center footerAbout ">
                    893 Pattanakarn RoadSoi Pattanakarn 11 Sub District Suanluang,District Suanluang, Bangkok 10250
                </p>
                <address class="d-flex align-items-center footerAddress ">
                    <img width="14 " height="16 " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/shopLocation.svg " alt=" ">
                    <p class="text-white "><a href="https://goo.gl/maps/CJ4XGVFmBFPgAN1j7 " target="_blank ">Shop Location</a></p>
                </address>
                <div class="d-flex align-items-center justify-content-center socialIcon ">
                    <a href="https://www.facebook.com/basketeer.co.th/ " target="_blank ">
                        <img width="26 " height="26 " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/facebookIcon.svg " alt=" ">
                    </a>
                    <a href="https://www.instagram.com/basketeer_thailand/ " target="_blank ">
                        <img width="26 " height="26 " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/instagramIcon.svg " alt=" ">
                    </a>
                    <a href="https://www.pinterest.com/basketeercoth/ " target="_blank ">
                        <img width="26 " height="26 " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/pinterestIcon.svg " alt=" ">
                    </a>
                </div>
            </div>
            <hr class="hr hr-blurry " />
            <div class="d-flex flex-row flex-wrap footerNavMobile ">
                <div class="footer_heading__ ">
                    <div class="text-white footerTitle ">Gift Baskets</div>
                    <div class="footerMenu ">
                        <a href="https://basketeer.com/product-category/fruit-baskets/ " class="text-white footerLink ">Fruit Baskets</a>
                       <!-- <a href="https://basketeer.com/product-category/wine-hampers/ " class="text-white footerLink " rel="nofollow ">Drink Hampers</a> -->
                        <a href="https://basketeer.com/product-category/bakery-gifts/ " class="text-white footerLink ">Bakery Gifts</a>
                        <a href="https://basketeer.com/product-category/flower-gifts/ " class="text-white footerLink ">Flower Gifts</a>
                        <a href="https://basketeer.com/product-category/balloon-gifts/ " class="text-white footerLink ">Balloon Gifts</a>
                        <a href="https://basketeer.com/product-category/gift-baskets/luxury-collection/ " class="text-white footerLink ">Luxury Hampers</a>
                    </div>
                </div>
                <div class="footer_heading__ ">
                    <div class="text-white footerTitle ">Services</div>
                    <div class="footerMenu ">
                        <a href="https://basketeer.com/corporate-gift-baskets/ " class="text-white footerLink ">Corporate Gift Baskets</a>
                        <a href="https://basketeer.com/gift-design-service/ " class="text-white footerLink ">Gift Design Services</a>
                    </div>
                </div>
                <div class="footer_heading__ ">
                    <div class="text-white footerTitle ">Occasions</div>
                    <div class="footerMenu ">
                        <a href="https://basketeer.com/product-category/bakery-gifts/birthday-cakes/ " class="text-white footerLink ">Birthday Cakes & Sweets</a>
                        <a href="https://basketeer.com/product-category/fruit-baskets/get-well-soon-fruit-baskets/ " class="text-white footerLink ">Get Well Soon</a>
                        <a href="https://basketeer.com/product-category/flower-gifts/romantic-flowers-for-her/ " class="text-white footerLink ">Valentine’s Day</a>
                        <a href="https://basketeer.com/product-category/gift-baskets/congratulations/ " class="text-white footerLink ">Congratulations</a>
                        <a href="https://basketeer.com/product-category/bakery-gifts/christmas-bakery/ " class="text-white footerLink ">Christmas</a>
                        <a href="https://basketeer.com/product-category/gift-baskets/chinese-new-year/ " class="text-white footerLink ">Chinese New Year</a>
                        <a href="https://basketeer.com/product-category/balloon-gifts/new-baby-born-balloon/ " class="text-white footerLink ">New Born Baby</a>
                        <a href="https://basketeer.com/product-category/fruit-baskets/thai-tropical-fruits/ " class="text-white footerLink ">Thai Summer Fruits</a>
                        <a href="https://basketeer.com/product-category/gift-baskets/gift-for-him/ " class="text-white footerLink ">Fathers Day</a>
                        <a href="https://basketeer.com/product-category/gift-baskets/mothers-day-gift-baskets/ " class="text-white footerLink ">Mothers Day</a>
                    </div>
                </div>
                <div class="footer_heading__ ">
                    <div class="text-white footerTitle ">Useful Links</div>
                    <div class="footerMenu ">
                        <a href="https://basketeer.com/how-to-pay/ " class="text-white footerLink ">How to Pay</a>
                        <a href="https://basketeer.com/how-to-order/ " class="text-white footerLink ">How to Order</a>
                        <a href="https://basketeer.com/payment-notification/ " class="text-white footerLink ">Notify the Payment</a>
                        <a href="https://basketeer.com/warranty-return-policy/ " class="text-white footerLink ">Warranty & Return Policy</a>
                        <a href="https://basketeer.com/track-your-order/ " class="text-white footerLink ">Track Your Order</a>
                        <a href="https://basketeer.com/faqs/ " class="text-white footerLink ">FAQs</a>
                        <a href="https://basketeer.com/promotions/ " class="text-white footerLink ">News & Promotions</a>
                        <a href="https://basketeer.com/blogs " class="text-white footerLink ">Blogs</a>
                        <a href="https://basketeer.com/contact-us " class="text-white footerLink ">Contact Us</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="d-lg-block d-xl-block mainFooter d-none " style="background:#C09A5C ">
        <img class="footerCabImage " width="178 " height="94 " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/basketeerCab.svg " alt=" ">
        <div class="container-fluid ">
            <div class="mainFooterInfo ">
                <div class="d-flex flex-nowrap justify-content-between ">
                    <div class="d-flex flex-column align-items-center px-0 mainFooterLeft col-3 ">
                        <a href="/ " rel="noopener noreferrer ">
                            <img class="footerlogo "width="99 " height="136 " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/basketeerFooterLogo.svg " alt=" ">
                        </a>
                        <p class="text-white text-center footerAbout ">
                            893 Pattanakarn RoadSoi Pattanakarn 11 Sub District Suanluang,District Suanluang, Bangkok 10250
                        </p>
                        <address class="d-flex align-items-center footerAddress ">
                            <img width="11 " height="14 " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/shopLocation.svg " alt=" ">
                            <p class="text-white "><a href="https://goo.gl/maps/CJ4XGVFmBFPgAN1j7 " target="_blank ">Shop Location</a></p>
                        </address>
                        <div class="d-flex align-items-center justify-content-center socialIcon ">
                            <a href="https://www.facebook.com/basketeer.co.th/ " target="_blank ">
                                <img width="26 " height="26 " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/facebookIcon.svg " alt=" ">
                            </a>
                            <a href="https://www.instagram.com/basketeer_thailand/ " target="_blank ">
                                <img width="26 " height="26 " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/instagramIcon.svg " alt=" ">
                            </a>
                            <a href="https://www.pinterest.com/basketeercoth/ " target="_blank ">
                                <img width="26 " height="26 " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/pinterestIcon.svg " alt=" ">
                            </a>
                        </div>
                    </div>
                    <div class="d-flex flex-column justify-content-end px-0 mainFooterRight col-9 ">
                        <div class="d-flex flex-nowrap justify-content-between " style="display: grid;grid-template-columns: auto auto auto auto;column-gap: 20px; ">
                            <div class="d-flex flex-column justify-content-between px-0 ">
                                <div class="footerMenuTop ">
                                    <div class="text-white footerTitle ">Gift Baskets</div>
                                    <a href="https://basketeer.com/product-category/fruit-baskets/ " class="text-white footerLink ">Fruit Baskets</a>
                                   <!-- <a href="https://basketeer.com/product-category/wine-hampers/ " class="text-white footerLink " rel="nofollow ">Drink Hampers</a> -->
                                    <a href="https://basketeer.com/product-category/bakery-gifts/ " class="text-white footerLink ">Bakery Gifts</a>
                                    <a href="https://basketeer.com/product-category/flower-gifts/ " class="text-white footerLink ">Flower Gifts</a>
                                    <a href="https://basketeer.com/product-category/balloon-gifts/ " class="text-white footerLink ">Balloon Gifts</a>
                                    <a href="https://basketeer.com/product-category/gift-baskets/luxury-collection/ " class="text-white footerLink ">Luxury Hampers</a>
                                </div>
                                <div class="footerMenuBottom ">
                                    <div class="text-white footerTitle ">Services</div>
                                    <a href="https://basketeer.com/corporate-gift-baskets/ " class="text-white footerLink ">Corporate Gift Baskets</a>
                                    <a href="https://basketeer.com/gift-design-service/ " class="text-white footerLink ">Gift Design Services</a>
                                </div>
                            </div>
                            <div class="px-0 ">
                                <div class="text-white footerTitle ">Occasions</div>
                                <a href="https://basketeer.com/product-category/bakery-gifts/birthday-cakes/ " class="text-white footerLink ">Birthday Cakes & Sweets</a>
                                <a href="https://basketeer.com/fruit-baskets/get-well-soon-fruit-baskets/ " class="text-white footerLink ">Get Well Soon</a>
                                <a href="https://basketeer.com/product-category/flower-gifts/romantic-flowers-for-her/ " class="text-white footerLink ">Valentine’s Day</a>
                                <a href="https://basketeer.com/product-category/gift-baskets/congratulations/ " class="text-white footerLink ">Congratulations</a>
                                <a href="https://basketeer.com/product-category/bakery-gifts/christmas-bakery/ " class="text-white footerLink ">Christmas</a>
                                <a href="https://basketeer.com/product-category/gift-baskets/chinese-new-year/ " class="text-white footerLink ">Chinese New Year</a>
                                <a href="https://basketeer.com/product-category/balloon-gifts/new-baby-born-balloon/ " class="text-white footerLink ">New Born Baby</a>
                                <a href="https://basketeer.com/product-category/fruit-baskets/thai-tropical-fruits/ " class="text-white footerLink ">Thai Summer Fruits</a>
                                <a href="https://basketeer.com/product-category/gift-baskets/gift-for-him/ " class="text-white footerLink ">Fathers Day</a>
                                <a href="https://basketeer.com/product-category/gift-baskets/mothers-day-gift-baskets/ " class="text-white footerLink ">Mothers Day</a>
                            </div>
                            <div class="px-0 ">
                                <div class="text-white footerTitle ">Useful Links</div>
                                <a href="https://basketeer.com/how-to-pay/ " class="text-white footerLink ">How to Pay</a>
                                <a href="https://basketeer.com/how-to-order/ " class="text-white footerLink ">How to Order</a>
                                <a href="https://basketeer.com/payment-notification/ " class="text-white footerLink ">Notify the Payment</a>
                                <a href="https://basketeer.com/track-your-order/ " class="text-white footerLink ">Track Your Order</a>
                                <a href="https://basketeer.com/warranty-return-policy/ " class="text-white footerLink ">Warranty & Return Policy</a>
                                <a href="https://basketeer.com/faqs/ " class="text-white footerLink ">FAQs</a>
                                <a href="https://basketeer.com/promotions/ " class="text-white footerLink ">News & Promotions</a>
                                <a href="https://basketeer.com/blogs/ " class="text-white footerLink ">Blogs</a>
                                <a href="https://basketeer.com/contact-us " class="text-white footerLink ">Contact Us</a>
                            </div>
                            <div class="d-flex flex-column justify-content-between px-0 ">
                                <div class="footerMenuTop ">
                                    <div class="text-white footerTitle ">Customer Service Team</div>
                                    <div class="d-flex align-items-center socialLink "><img width="16 " height="16 " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/whatsappIcon.svg " alt=" "><a href="https://wa.me/66939516639
                        " target="_blank " class="text-white footerLink ">whatsapp</a></div>
                                    <div class="d-flex align-items-center socialLink "><img width="16 " height="16 " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/messengerIcon.svg " alt=" "><a href="https://www.facebook.com/messages/t/166151743584888
                        " target="_blank " class="text-white footerLink ">Messenger</a></div>
                                    <div class="d-flex align-items-center socialLink "><img width="16 " height="16 " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/telephoneIcon.svg " alt=" "><a href="tel:+66028215042
                        " target="_blank " class="text-white footerLink ">+66(0)2 821 5042</a></div>
                                    <div class="d-flex align-items-center socialLink "><img width="16 " height="16 " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/emailIcon.svg " alt=" "><a href="/cdn-cgi/l/email-protection#0c65626a634c6e6d7f67697869697e226f63227864
                        " target="_blank " class="text-white footerLink "><span class="__cf_email__ " data-cfemail="b2fbdcd4ddf2d0d3c1d9d7c6d7d7c09cd1dd9cc6da ">[email&#160;protected]</span></a></div>
                                    <div class="d-flex align-items-center socialLink "><img width="16 " height="16 " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/lineIcon.svg " alt=" "><a href="http://line.me/ti/p/@basketeer
                        " target="_blank " class="text-white footerLink ">@Basketeer</a></div>
                                </div>
                                <div class="footerMenuBottom ">
                                    <div class="text-white footerTitle ">Customer Support Hours</div>
                                    <a class="text-white footerLink ">Mon - Fri 08.00-18.00</a>
                                    <a class="text-white footerLink ">Sat - Sun 08.00-17.00</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </section>
    <section class="d-lg-block d-xl-block footerBottom ">
        <div class="container-fluid ">
            <div class="footerBottomInfo ">
                <div class="d-block d-md-flex flex-nowrap align-items-center justify-content-between ">
                    <div class="d-block d-md-flex align-items-center px-0 footerBottomLeft col-12 col-md-9 ">
                        <h6 class=" " style="color:#8C8C8C ">We accept</h6>
                        <img width="318px " height="32px " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/payment-method-1.png " alt="payment-method-1 " class="d-md-none payment-method " />
                        <img width="143px " height="31px " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/07/payment-method-2.png " alt="payment-method-2 " class="d-md-none " />
                        <img width="545 " height="37 " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/paymentInfo.svg " alt="paymentInfo " class="d-md-block d-none ">
                    </div>
                    <div class="d-flex justify-content-end px-0 footerBottomRight col-12 col-md-3 ">
                        <h6 class=" " style="color:#8C8C8C ">Secure payment by</h6>
                        <img width="58 " height="19 " src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/07/25110832/stripe-logo.png " alt=" ">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="text-center copywrite " style="background:#C09A5C ">
        <small class="text-white ">© 2025 Basketeer. All rights reserved. Website Design Basketeer In-house Thailand</small>
    </section>
</footer>

<!-- Personalised Message Modal -->
<div class="modal fade " id="personalisedMessage " tabindex="-1 " aria-labelledby="personalisedMessageLabel " aria-hidden="true " data-backdrop="static " data-keyboard="false ">
    <div class="modal-dialog modal-dialog-centered ">
        <div class="modal-content ">
            <div class="modal-header ">
                <div class="close ">
                    <img src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/close-icon.svg " alt=" " class="close " onclick="closePersonalisedPopup(); " aria-label="Close ">
                </div>
                <h4 class="modal-title fs-5 " id="personalisedMessageLabel ">Personalised Message</h4>
            </div>
            <div class="modal-body ">
                <p class="ocaasionPersonalised ">Occasion: <span class="ocassionBody ">Birthday</span></p>
                <p class="cardMessagePersonalised ">Card Message: <span class="cardMessageBody "></span></p>
                <p class="salutationPersonalised "><span class="salutationBodyPersonalised ">Friend</span></p>
                <p class="messageBodyPersonalised ">Wishing my bestie, the absolute best on her best day of the year!
                    Cheers to more fun, more memories and cake! Happy birthday.</p>
                <p class="senderPersonalised "><span class="senderBodyPersonalised ">Friend</span></p>
            </div>
            <div class="modal-footer edit-message-section ">
                <input type="hidden " name="editcard_template " class="editcard_template " value=" " />
                <input type="hidden " name="editcard_salutation " class="editcard_salutation " value=" " />
                <input type="hidden " name="editcard_text " class="editcard_text " value=" " />
                <input type="hidden " name="editcard_sender " class="editcard_sender " value=" " />
                <input type="hidden " name="editcard_cart_id " class="editcard_cart_id " value=" " />
                <button class="btnBlack " type="button " onclick="editPersonalised(); ">Edit</button>
            </div>
        </div>
    </div>
</div>


<div class="modal fade " id="personalisedMessageEdit " tabindex="-1 " aria-labelledby="personalisedMessageLabel " aria-hidden="true " data-backdrop="static " data-keyboard="false ">
    <div class="modal-dialog modal-dialog-centered ">
        <div class="modal-content ">
            <div class="modal-header ">
                <div class="close ">
                    <img src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/close-icon.svg " alt=" " class="close " onclick="closeEditPersonalisedPopup(); " aria-label="Close ">
                </div>
                <h4 class="modal-title fs-5 " id="personalisedMessageLabel ">Personalised Message</h4>
            </div>
            <div class="modal-body ">
                <div class="product-options ">
                    <fieldset>
                        <div class="mb-3 ">
                            <label class="form-label ">Occasion</label>
                            <select id="edit_card_template " name="edit_card_template " class="form-select ">
                                <option value=" ">Select an option</option>
                                <option value="Happy Birthday ">Happy Birthday</option>
                                <option value="Get Well Soon ">Get Well Soon </option>
                                <option value="Congratulation ">Congratulation</option>
                                <option value="Thank you ">Thank you </option>
                                <option value="Happy New Year ">Happy New Year</option>
                                <option value="For You ">For You</option>
                            </select>
                        </div>
                    </fieldset>
                    <fieldset>
                        <label class="form-label ">Card Message</label>
                        <div id="cardInfo ">
                            <div class="cardinfoinside ">
                                <label for="salutation ">To</label>
                                <input type="text " id="edit_card_salutation " name="edit_card_salutation " placeholder="Wife, ">
                            </div>
                            <div class="cardinfoinside ">
                                <textarea name="edit_card_text " class="form-control " rows="5 " id="edit_card_text " placeholder="Your Message " style="resize: none; "></textarea>
                            </div>
                            <p id="edit_char_count "></p>
                            <div class="cardinfoinside ">
                                <label for="sender ">From</label>
                                <input type="text " id="edit_card_sender " name="edit_card_sender ">
                            </div>
                        </div>
                        <div class="button-div ">
                            <input type="hidden " id="edit_card_cart_id " name="edit_card_cart_id " value=" " />
                        </div>
                    </fieldset>
                </div>
            </div>
            <div class="modal-footer ">
                <button class="btnBlack " type="button " onclick="editCardMessage(); ">Submit</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade " id="editProductWiseSelectedOption " tabindex="-1 " aria-labelledby="personalisedMessageLabel " aria-hidden="true " data-backdrop="static " data-keyboard="false ">
    <div class="modal-dialog modal-dialog-centered ">
        <div class="modal-content ">
            <div class="modal-header ">
                <div class="close ">
                    <img src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/close-icon.svg " alt=" " class="close " onclick="closeProductWiseSelectedOptionPopup(); " aria-label="Close ">
                </div>
                <h4 class="modal-title fs-5 ProductWiseSelectedOptionLabel ">Select Other Options</h4>
            </div>
            <div class="modal-body ">
                <div class="ProductWiseSelectedOptionLists ">
                </div>
            </div>
            <div class="productoptionedit-message-section modal-footer ">
            </div>
        </div>
    </div>
</div>


<style>
  .woocommerce-mini-cart-item {
    display: grid;
    grid-template-columns: minmax(0, 34%) minmax(0, 46%) minmax(0, auto);
    column-gap: 15px;
  }

  h5#minicartSectionLabel {
    color: #333333;
    font-size: 30px;
    font-family: EB Garamond;
    font-weight: 400;
    word-wrap: break-word;
  }

  #mini-cart-content .cartTotal {
    background: #fff;
    width: 100%;
    position: fixed;
    bottom: 0;
    width: -webkit-fill-available;
  }

  .proInfo {
    display: flex;
    flex-direction: column;
  }

  .proInfo .qty-input.quantity {
    display: flex;
    align-items: initial;
  }

  button.qty-count.quantity-minus {
    line-height: 4px;
  }

  .proInfo button.qty-count.quantity-minus {
    border: 1px solid #E5E5E5;
    background: #fff;
    border-radius: 0px;
    padding: 6px;
  }

  .proInfo button.qty-count.quantity-plus {
    border: 1px solid #E5E5E5;
    background: #fff;
    border-radius: 0px;
    padding: 6px;
  }

  .proInfo .quantity .qty {
    min-width: 25px;
    max-width: 35px;
    text-align: center;
    font-size: 12px;
    line-height: 0px;
    border: 1px solid #E5E5E5;
    border-width: 1px 0 1px;
    width: 25px;
  }

  .prodShopOperation {
    display: grid;
    align-content: space-between;
    justify-items: end;
  }

  .proInfo .product-name {
    font-size: 14px;
    font-family: EB Garamond;
    font-weight: 500;
    line-height: 16px;
    margin-bottom: 4px;
  }

  .proInfo .product-sku {
    color: #8C8C8C;
    font-size: 12px;
    font-family: Montserrat;
    letter-spacing: 0.12px;
  }

  .proInfo .product-quantity {
    margin-top: auto;
  }

  .prodShopOperation span.woocommerce-Price-amount.amount {
    font-family: Montserrat;
    font-size: 14px;
    font-weight: 600;
    line-height: 20px;
    letter-spacing: 0em;
    color: #C09A5C;
  }

  .prodShopOperation del span.woocommerce-Price-amount.amount {
    color: #8c8c8c;
    font-weight: 400;
    font-size: 12px;
}

  .prodShopOperation del span.woocommerce-Price-currencySymbol {
    font-size: 12px;
  }

  .prodShopOperation span.woocommerce-Price-currencySymbol {
    font-family: 'Latin Modern Roman';
    font-size: 14px;
    font-weight: 100;
    line-height: 23px;
    letter-spacing: 0em;
  }

  #prodNote {
    color: #C09A5C;
    font-size: 12px;
    font-family: EB Garamond;
    font-weight: 500;
    text-decoration-line: underline;
    margin-bottom: 10px;
    cursor: pointer;
    display: flex;
    align-items: center;
    column-gap: 4px;
    white-space: nowrap;
  }

  .woocommerce-mini-cart {
    padding: 0 20px;
    margin-bottom: 203px;
  }

  .woocommerce-mini-cart-item.mini_cart_item {
    padding: 25px 0px;
  }

  .woocommerce-mini-cart-item.mini_cart_item:not(:last-child) {
    border-bottom: 1px solid #D9D9D9;
  }

  .woocommerce-mini-cart__buttons {
    display: grid;
    grid-template-columns: minmax(0, 40%) minmax(0, auto);
  }

  .woocommerce-mini-cart__buttons .wc-forward {
    color: #333;
    text-align: center;
    font-size: 14px;
    font-family: Montserrat;
    font-weight: 600;
    letter-spacing: 1.4px;
    text-transform: uppercase;
    padding-top: 18px;
    padding-bottom: 18px;
    border: 1px solid #333333;
    border-radius: 0px !important;
    z-index: 1;
    position: relative;
  }

  .woocommerce-mini-cart__buttons .wc-forward:hover {
    background: #ffffff00;
    color: #fff!important;
    transition: 0.3s ease-in-out;
    border: 1px solid #c09a5c;
  }

  .woocommerce-mini-cart__buttons .wc-forward:before {
    content: " ";
    position: absolute;
    bottom: 0;
    left: 0;
    width: 0%;
    height: 100%;
    background-color: #c09a5c;
    transition: all 0.3s;
    z-index: -1;
  }

  .woocommerce-mini-cart__buttons .wc-forward:hover:before {
    width: 100%;
  }

  .woocommerce-mini-cart__buttons .wc-forward:after {
    content: " ";
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: -2;
  }

  .woocommerce-mini-cart__buttons .checkout:hover,
  .woocommerce-mini-cart__buttons_single:hover {
    color: #333;
    background: #fff;
  }

  .woocommerce-mini-cart__buttons .checkout,
  .woocommerce-mini-cart__buttons_single {
    background: #333333;
    color: #fff;
  }

  .woocommerce-mini-cart__buttons .checkout:hover,
  .woocommerce-mini-cart__buttons_single:hover {
    background: #ffffff00;
    color: #ffffff;
    transition: 0.3s ease-in-out;
  }

  .woocommerce-mini-cart__buttons .checkout:before,
  .woocommerce-mini-cart__buttons_single:before {
    content: " ";
    position: absolute;
    bottom: 0;
    left: 0;
    width: 0%;
    height: 100%;
    background-color: #c09a5c;
    transition: all 0.3s;
    z-index: -1;
  }

  .woocommerce-mini-cart__buttons .checkout:hover:before,
  .woocommerce-mini-cart__buttons_single:hover:before {
    width: 100%;
  }

  .woocommerce-mini-cart__buttons .checkout:after,
  .woocommerce-mini-cart__buttons_single:after {
    content: " ";
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: #333;
    z-index: -2;
  }

  .woocommerce-mini-cart__buttons_single {
    width: 100%;
    display: block;
    padding: 24px 0;
    color: #FFF;
    text-align: center;
    font-family: Montserrat;
    font-size: 14px;
    font-style: normal;
    font-weight: 600;
    line-height: normal;
    letter-spacing: 1.4px;
    text-transform: uppercase;
  }

  .woocommerce-mini-cart__total.total {
    display: flex;
    justify-content: space-between;
    padding: 22px 20px;
    border-bottom: 1px solid #d9d9d9;
    align-items: center;
  }

  .woocommerce-mini-cart__total p,
  .woocommerce-mini-cart__total h3 {
    margin-bottom: 0;
  }

  .woocommerce-mini-cart__total h3 {
    font-size: 30px;
    font-family: EB Garamond;
  }

  .woocommerce-mini-cart__total span.woocommerce-Price-amount.amount {
    font-size: 18px;
    font-family: 'Montserrat';
    font-weight: 500;
  }

  .woocommerce-mini-cart__total span.woocommerce-Price-currencySymbol {
    font-size: 18px;
    font-family: 'Latin Modern Roman';
    font-weight: 400;
  }

  #mini-cart-content .cartTotal .shipNote {
    padding: 21px 20px 24px;
    color: #8C8C8C;
    font-size: 12px;
    font-family: Montserrat;
    letter-spacing: 0.12px;
  }

  .additinal-addons .woocommerce-mini-cart-item {
    display: grid;
    grid-template-columns: minmax(0, auto);
    column-gap: 15px;
    border-bottom: 0px !important;
    position: relative;
    padding: 0px 0px;
  }

  .additinal-addons {
    display: grid;
    grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
    column-gap: 10px;
    position: relative;
    row-gap: 12px;
    border-bottom: 1px solid #D9D9D9;
    padding: 25px 0;
  }

  .additinal-addons .product-thumbnail img {
    aspect-ratio: 1/1;
  }

  .additinal-addons span.woocommerce-Price-amount.amount {
    font-size: 12px;
  }

  .additinal-addons span.woocommerce-Price-currencySymbol {
    font-size: 12px;
    font-family: 'Latin Modern Roman';
  }

  .additinal-addons .product-remove {
    position: absolute !important;
    top: 2px;
    right: 6px;
  }

  .additinal-addons .quantity {
    font-family: 'Montserrat';
    font-size: 12px;
    margin-top: 7px;
  }

  .woocommerce-mini-cart__empty-message {
    padding: 55px 90px;
  }

  .woocommerce-mini-cart__empty-message h5 {
    color: #333;
    font-family: EB Garamond;
    font-size: 24px;
    font-style: normal;
    font-weight: 400;
    line-height: normal;
    letter-spacing: 0.24px;
    margin-top: 20px;
  }

  .woocommerce-mini-cart__empty-message p {
    color: #333;
    text-align: center;
    font-family: Montserrat;
    font-size: 12px;
    font-style: normal;
    font-weight: 400;
    line-height: 20px;
    /* 166.667% */
    letter-spacing: 0.36px;
  }

  @media only screen and (min-width: 1920px) {}

  @media only screen and (max-width: 1300px) {}

  @media only screen and (max-width: 991px) {}

  @media only screen and (max-width: 767px) {



    .woocommerce-mini-cart-item {
      display: grid;
      grid-template-columns: minmax(0, 33%) minmax(0, 28%) minmax(0, auto);
      column-gap: 20px;
    }

    h5#minicartSectionLabel {
      font-size: 26px;
      font-weight: 400;
      letter-spacing: 0.26px;
    }

    .product-thumbnail {
      aspect-ratio: 1/1;
    }

    .woocommerce-mini-cart__total h3 {
      font-size: 20px;
      font-weight: 400;
    }

  }
</style>

<!-- Mini Cart Template -->
<div class="offcanvas offcanvas-end " tabindex="-1 " id="minicartSection " aria-labelledby="minicartSectionLabel ">
  <div class="offcanvas-header ">
    <h5 class="offcanvas-title " id="minicartSectionLabel ">Shopping Cart</h5>
    <button type="button " class="btn-close " data-bs-dismiss="offcanvas " aria-label="Close "></button>
  </div>
  <div class="offcanvas-body ">
    <div id="mini-cart-content "></div>
  </div>
  <div class="offcanvas-Footer "></div>
</div>
<!-- End Mini Cart Template -->

<script data-cfasync="false " src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js "></script><script>
  //Resize window
  function resize() {
    if (jQuery(window).width() < 767) {
      jQuery('#minicartSection').removeClass('offcanvas-end').addClass('offcanvas-bottom');
    } else {
      jQuery('#minicartSection').removeClass('offcanvas-bottom').addClass('offcanvas-end');
    }
  }

  //watch window resize
  jQuery(window).on('load resize', function() {
    resize();
  });
</script>
<script src="https://basketeer.com/wp-content/themes/baskettheme/js/external/slick.min.js "></script>
<!-- <script src="https://cdn.jsdelivr.net/npm/@splidejs/splide@1.3.3/dist/js/splide.min.js "></script> -->
<script src="https://basketeer.com/wp-content/themes/baskettheme/js/external/select.min.js "></script>
<!--<script src="https://basketeer.com/wp-content/themes/baskettheme/js/external/custom.js "></script>-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.13/js/intlTelInput-jquery.min.js "></script>


<script>
    jQuery('.dgwt-wcas-search-icon').html('<svg fill="none " viewBox="0 0 20 20 "><path fill="#333 " d="M19.53 18.47l-4.694-4.693a8.26 8.26 0 10-1.06 1.06l4.693 4.694a.75.75 0 101.06-1.061zM1.75 8.5a6.75 6.75 0 116.75 6.75A6.758 6.758 0 011.75 8.5z "/></svg>');
    jQuery('.dgwt-wcas-search-submit').html('<svg fill="none " viewBox="0 0 20 20 "><path fill="#333 " d="M19.53 18.47l-4.694-4.693a8.26 8.26 0 10-1.06 1.06l4.693 4.694a.75.75 0 101.06-1.061zM1.75 8.5a6.75 6.75 0 116.75 6.75A6.758 6.758 0 011.75 8.5z "/></svg>');
</script>

<script>
    // Function to hide the preloader once the page is fully loaded
    window.onload = function() {
        var preloader = document.querySelector('.preloader');
        preloader.style.display = 'none';
        document.body.style.overflow = 'auto'; // Re-enable scrolling

        function adjustParagraphHeights() {
            // Reset min-height to auto before calculating new height
            jQuery('p.giftServiceText').css('min-height', 'auto');

            var maxParagraphHeight = 0;

            // Loop through each paragraph to find the maximum height
            jQuery('p.giftServiceText').each(function() {
                var height = jQuery(this).outerHeight(true);
                maxParagraphHeight = Math.max(maxParagraphHeight, height);
            });

            // Set the min-height of each paragraph individually
            jQuery('p.giftServiceText').css('min-height', maxParagraphHeight + 'px');
        }

        // Initial adjustment on page load
        adjustParagraphHeights();

        // Adjust positions on window resize
        jQuery(window).resize(function() {
            adjustParagraphHeights();
        });

    };

    document.addEventListener("DOMContentLoaded ", function($) {

        let isOffcanvasOpen = false;


        // function openModal() {
        //     jQuery('#personalisedMessage').modal('show');
        // }

        // function closeModal() {
        //     jQuery('#personalisedMessage').modal('hide');
        // }

        // jQuery('#minicartSection').on('shown.bs.offcanvas', function() {
        //     isOffcanvasOpen = true; 
        // });

        // // Handle modal show event
        // jQuery('#personalisedMessage').on('show.bs.modal', function() {
        //     if (isOffcanvasOpen) {
        //         jQuery('#minicartSection').offcanvas('hide');
        //     }
        // });

        // jQuery('#personalisedMessage').on('hidden.bs.modal', function(e) {
        //     if (isOffcanvasOpen) {
        //         jQuery('#minicartSection').offcanvas('show');
        //     }
        // });

        var editmyText = document.getElementById("edit_card_text ");
        var editwordCount = document.getElementById("edit_char_count ");

        editmyText.addEventListener("keyup ", function() {
            var characters = editmyText.value.split('');
            editwordCount.innerText = `${characters.length}/250`;
            if (characters.length > 250) {
                editmyText.value = editmyText.value.substring(0, 250);
                editwordCount.innerText = 250;
            }
        });

        const myOffcanvas = document.getElementById('minicartSection')
        myOffcanvas.addEventListener('hidden.bs.offcanvas', event => {
            resetBodyOverflow();
        })

      
        

        jQuery('.single-product .topSellingItems').slick({
            dots: false,
            infinite: false,
            slidesToShow: 4,
            slidesToScroll: 1,
            arrows: true,
            prevArrow: '<button class="prv "><i class="bi-chevron-left bi "></i></button>',
            nextArrow: '<button class="nxt "><i class="bi-chevron-right bi "></i></button>',
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 4,
                        slidesToScroll: 1,
                        infinite: false,
                        dots: false
                    }
                }, {
                    breakpoint: 991,
                    settings: {
                        slidesToShow: 3,
                    }
                },
                {
                    breakpoint: 767,
                    settings: {
                        slidesToShow: 2.3,
                        arrows: false,
                    }
                }
            ]
        });

        

        jQuery('.product-gallery-images').slick({
            dots: false,
            infinite: false,
            slidesToShow: 4,
            slidesToScroll: 1,
            arrows: true,
            prevArrow: '<button class="prv "><i class="bi-chevron-left bi "></i></button>',
            nextArrow: '<button class="nxt "><i class="bi-chevron-right bi "></i></button>',
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 4,
                        slidesToScroll: 1,
                        infinite: false,
                        dots: false
                    }
                }, {
                    breakpoint: 991,
                    settings: {
                        slidesToShow: 3,
                    }
                },
                {
                    breakpoint: 767,
                    settings: {
                        slidesToShow: 2.3,
                        arrows: false,
                    }
                }
            ]
        });

      /*  jQuery('.occasionItems').slick({
            dots: false,
            infinite: false,
            slidesToShow: 5,
            arrows: true,
            slidesToScroll: 2,
            focusOnSelect: true,
            prevArrow: '<button class="prv "><i class="bi-chevron-left bi "></i></button>',
            nextArrow: '<button class="nxt "><i class="bi-chevron-right bi "></i></button>',
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 4,
                     
                        infinite: false,
                        dots: false
                    }
                }, {
                    breakpoint: 991,
                    settings: {
                        slidesToShow: 3,
                    }
                },
                {
                    breakpoint: 767,
                    settings: {
                        slidesToShow: 2.3,
                        arrows: false,
                    }
                }
            ]
        });*/

        if(jQuery('.occasionItems').length){
            new Splide( '.occasionItems', {
                perPage    : 4,
                interval: 8000,
                flickMaxPages: 3,
                updateOnMove: true,
                pagination: false,
                throttle: 300,
                gap       : 21,
                arrows: { prev: '<button class="prv "><i class="bi-chevron-left bi "></i></button>', 
                        next: '<button class="nxt "><i class="bi-chevron-right bi "></i></button>' 
                        },
                breakpoints: {
                    991: {
                        perPage: 3,
                    },
                    767: {
                        perPage: 2,
                        gap       : 13,
                    },
                }
            }).mount();
        }

        jQuery('.testimonial').on('init', function(event, slick) {
            var slideCount = slick.slideCount;
            var slidesToShowCount = 3;

            slick.options.dots = slideCount > slidesToShowCount;
            slick.refresh();
        });


        var giftServicesItemTotalSlides = jQuery('.giftService').length;
        var giftServicesItem_showDots = giftServicesItemTotalSlides > 3;

        jQuery('.giftServicesItems').slick({
            infinite: false,
            slidesToShow: 3,
            slidesToScroll: 1,
            arrows: false,
            dots: false,
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                        dots: false,
                        arrows: true,
                        prevArrow: '<button class="prv "><i class="bi-chevron-left bi "></i></button>',
                        nextArrow: '<button class="nxt "><i class="bi-chevron-right bi "></i></button>'
                    }
                },
                {
                    breakpoint: 767,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        dots: false,
                        arrows: true,
                        prevArrow: '<button class="prv "><i class="bi-chevron-left bi "></i></button>',
                        nextArrow: '<button class="nxt "><i class="bi-chevron-right bi "></i></button>'
                    }
                }
            ]
        });

        jQuery('.journals').slick({
            infinite: false,
            slidesToShow: 4,
            slidesToScroll: 1,
            arrows: false,
            dots: false,
            responsive: [{
                    breakpoint: 991,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                        dots: false,
                        arrows: false,
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1.3,
                        slidesToScroll: 1,
                        dots: false,
                        arrows: false,
                    }
                }
            ]
        });

        jQuery('.testimonial').slick({
            infinite: false,
            slidesToShow: 3,
            slidesToScroll: 1,
            arrows: false,
            dots: true,
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                        infinite: true,
                        dots: true
                    }
                },
                {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        infinite: true,
                        dots: true
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }
            ]
        });

        jQuery('.instaImages').slick({
            slidesToShow: 5,
            slidesToScroll: 1,
            arrows: false,
            dots: false,
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 1,
                        infinite: true,
                        dots: false
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 2.7,
                        slidesToScroll: 1,
                        centerMode: false,
                        infinite: false,
                    }
                }
            ]
        });
    });
</script>

<script>
    document.addEventListener("DOMContentLoaded ", function($) {
        // productDescriptionPage

        jQuery('.slider-single').slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: false,
            fade: true,
            infinite: false,
            speed: 1000,
            asNavFor: '.slider-nav',
            responsive: [{
                breakpoint: 992,
                settings: {
                    dots: true
                }
            }]
        });
        jQuery('.slider-nav').slick({
            slidesToShow: 4,
            slidesToScroll: 4,
            asNavFor: '.slider-single',
            dots: false,
            focusOnSelect: true,
            infinite: false,
            arrows: true,
            prevArrow: '<button class="prv "><i class="bi-chevron-left bi "></i></button>',
            nextArrow: '<button class="nxt "><i class="bi-chevron-right bi "></i></button>',
            // responsive: [{
            //         breakpoint: 992,
            //         settings: {
            //             vertical: false,
            //         }
            //     },
            //     {
            //         breakpoint: 768,
            //         settings: {
            //             vertical: false,
            //         }
            //     },
            //     {
            //         breakpoint: 580,
            //         settings: {
            //             vertical: false,
            //             slidesToShow: 3,
            //         }
            //     },
            //     {
            //         breakpoint: 380,
            //         settings: {
            //             vertical: false,
            //             slidesToShow: 2,
            //         }
            //     }
            // ]
        });

        jQuery('.addOnitems').slick({
            slidesToShow: 5,
            prevArrow: '<a class="prv "><i class="bi-chevron-left bi "></i></a>',
            nextArrow: '<a class="nxt "><i class="bi-chevron-right bi "></i></a>',
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3,
                        infinite: true,
                        arrows: false
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3,
                        arrows: false
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 4,
                        slidesToScroll: 4,
                        arrows: false
                    }
                }
            ]
        });

        jQuery('.product_custom_options_lists_options').slick({
            slidesToShow: 4,
            prevArrow: '<a class="prv "><i class="bi-chevron-left bi "></i></a>',
            nextArrow: '<a class="nxt "><i class="bi-chevron-right bi "></i></a>',
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3,
                        infinite: true,
                        arrows: false
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3,
                        arrows: false
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 4,
                        slidesToScroll: 4,
                        arrows: false
                    }
                }
            ]
        });

        // jQuery('.includedItem').slick({
        //     slidesToShow: 8,
        //     dots:false,
        //     arrows:false,
        // });

    });
</script>

<script>
    jQuery(document).ready(function() {


        jQuery('.gift-boxslideinner').slick({
            dots: false,
            infinite: false,
            speed: 300,
            slidesToShow: 4,
            slidesToScroll: 4,
            prevArrow: '<button class="prv "><i class="bi-chevron-left bi "></i></button>',
            nextArrow: '<button class="nxt "><i class="bi-chevron-right bi "></i></button>',
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 4,
                        slidesToScroll: 4,
                        infinite: true,
                        dots: true
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2
                    }
                }
                // You can unslick at a given breakpoint now by adding:
                // settings: "unslick "
                // instead of a settings object
            ]
        });

    });
</script>

<script>
    jQuery(document).ready(function($) {
        jQuery('.woof_submit_search_form_container').remove();
    });
</script>

<script>
    jQuery(function($) {
        $('.orderby').select2({
            minimumResultsForSearch: Infinity
        });
    });
</script>

<script>
    jQuery('.footer_heading').each(function(index) {
        var $title = jQuery(this).find('.footerTitle');
        var $menu = jQuery(this).find('.footerMenu');

        // Open the first footerMenu by default
        if (index === 0) {
            $menu.slideDown();
            $title.addClass('active');
        } else {
            $menu.slideUp();
            $title.removeClass('active');
        }

        $title.on('click', function() {
            // Slide up all other footerMenus and remove active class
            jQuery('.footerMenu').not($menu).slideUp();
            jQuery('.footerTitle').not($title).removeClass('active');

            // Toggle the visibility of the clicked footerMenu and toggle active class
            $menu.slideToggle();
            $title.toggleClass('active');
        });
    });
</script>

<script>
    document.addEventListener("DOMContentLoaded ", function($) {
        jQuery('.icon').slick({
            dots: false,
            infinite: true,
            speed: 300,
            slidesToShow: 3,
            slidesToScroll: 1,
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3,
                        infinite: true,
                        dots: true
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2.5,
                        slidesToScroll: 2.5
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 2.5,
                        slidesToScroll: 2.5
                    }
                }
                // You can unslick at a given breakpoint now by adding:
                // settings: "unslick "
                // instead of a settings object
            ]
        });

        jQuery('.icon-1').slick({
            dots: false,
            infinite: true,
            speed: 300,
            slidesToShow: 4,
            slidesToScroll: 4,
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 4,
                        slidesToScroll: 4,
                        infinite: true,
                        dots: true
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2.5,
                        slidesToScroll: 2.5
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 2.5,
                        slidesToScroll: 2.5
                    }
                }
                // delivery service slider
            ]
        });
    });
</script>

<script>
    //add to cart using ajax on listing pages
    function addToCart(productId) {

        jQuery.ajax({
            url: wc_add_to_cart_params.ajax_url,
            type: 'POST',
            data: {
                action: 'woocommerce_add_to_cart', // WooCommerce AJAX action
                product_id: productId // ID of the product to add
            },
            success: function(response) {

                if (response && response.fragments) {

                    jQuery('#minicartSection').offcanvas('show');

                    var counterValue = parseInt(jQuery('.cart-count').html()) + 1;
                    jQuery('.cart-count').html('');
                    jQuery('.cart-count').html(counterValue);

                    jQuery.each(response.fragments, function(key, value) {
                        jQuery(key).replaceWith(value);
                    });

                    if (response.fragments['div.widget_shopping_cart_content']) {

                        var cartItems = response.fragments['div.widget_shopping_cart_content'];
                        // Display the updated cart items in the specified div
                        jQuery('#mini-cart-content').html(cartItems);
                    }
                }

                if (response['error'] == true) {
                    window.location.href = response['product_url'];
                }
            },
            error: function(error) {
                console.log('Error adding product to cart: ' + error.statusText);
            }
        });
    }

    function addToCartWithVariation(product_id, variation_id) {
        jQuery.ajax({
            url: wc_add_to_cart_params.ajax_url,
            type: 'POST',
            data: {
                action: 'add_variation_to_cart',
                product_id: product_id,
                variation_id: variation_id
            },
            success: function(response) {
                jQuery('#minicartSection').offcanvas('show');

                var counterValue = parseInt(jQuery('.cart-count').html()) + 1;
                jQuery('.cart-count').html('');
                jQuery('.cart-count').html(counterValue);

                refreshMinicartItem();   

            },
            error: function(error) {
                console.log('Error adding product to cart: ' + error.statusText);
            }
        });
    }

    function closeMiniCart() {
        jQuery('#minicartSection').offcanvas('hide');
        refreshMinicartItem();
    }

    function openMiniCart() {
        jQuery('#minicartSection').offcanvas('show');
        refreshMinicartItem();
    }

    //refresh cart items on page load
    jQuery(document).ready(function($) {

        jQuery('.variation-CardTemplate').remove();
        jQuery('.variation-CardSalutation').remove();
        jQuery('.variation-CardMessage').remove();
        jQuery('.variation-CardSender').remove();

    });

    function refreshMinicartItem() {

        jQuery.ajax({
            url: 'https://basketeer.com/wp-admin/admin-ajax.php',
            type: 'POST',
            data: {
                action: 'get_refreshed_fragments_custom'
            },
            success: function(response) {

                if (response && response.fragments && response.fragments['div.widget_shopping_cart_content']) {
                    var cartItems = response.fragments['div.widget_shopping_cart_content'];

                    // Display the updated cart items in the specified div
                    jQuery('#mini-cart-content').html(cartItems);
                }
                //console.log('Cart items updated and displayed successfully!');
            },
            error: function(error) {
                console.log('Error updating and displaying cart items: ' + error.statusText);
            }
        });
    }


    

    // faq mobile accordion js 
    jq = jQuery;
    jq(document).ready(function($) {
        jq(".mainaccordion ").click(function() {
            // jq('.accc-container').slideUp();
            jq(this).toggleClass('active').siblings('.accc-container').slideToggle().parents(".tab-pane ").siblings('.tab-pane').find('.accc-container').slideUp().siblings('.mainaccordion').removeClass('active');
        })
    });


    function closePersonalisedPopup() {

        jQuery('#personalisedMessage').modal('hide');

        // setTimeout(function() {
        //     resetBodyOverflow();
        // }, 1000); // 3000 milliseconds (3 seconds) delay


    }

    function closeProductWiseSelectedOptionPopup(){
        
        jQuery('#editProductWiseSelectedOption').modal('hide');
    }

    function closeEditPersonalisedPopup() {

        jQuery('#personalisedMessageEdit').modal('hide');

        // setTimeout(function() {
        //     resetBodyOverflow();
        // }, 1000); // 3000 milliseconds (3 seconds) delay


    }

    jQuery('#personalisedMessage').on('hidden.bs.modal', function() {
        resetBodyOverflow();
    });

    jQuery('#minicartSection').on('hidden.bs.modal', function() {
        resetBodyOverflow();
    });



    function resetBodyOverflow() {
        jQuery('body').css('overflow', 'auto');
    }
</script>

<script>
    // jQuery(document).ready(function($) {
    //     $("input#phone_number ").intlTelInput({
    //         separateDialCode: true,
    //         showFlags: false,
    //         preferredCountries: [" "],
    //         onlyCountries: ["us ","th ","in "],
    //         geoIpLookup: callback => {
    //             fetch("https://ipapi.co/json ")
    //                 .then(res => res.json())
    //                 .then(data => callback(data.country_code))
    //                 .catch(() => callback("th "));
    //         }
    //     });
    // });
</script>

<!-- Add custom.js script -->
<script src="https://basketeer.com/wp-content/themes/baskettheme/js/external/custom.js "></script>
<script>
    console.log("Manual custom.js loaded. ");
</script>

</body>
	    <template id="tmpl-age-gate "  class=" ">        
<div class="age-gate__wrapper ">            <div class="age-gate__loader ">    
        <svg version="1.1 " id="L5 " xmlns="http://www.w3.org/2000/svg " xmlns:xlink="http://www.w3.org/1999/xlink " x="0px " y="0px " viewBox="0 0 100 100 " enable-background="new 0 0 0 0 " xml:space="preserve ">
            <circle fill="currentColor " stroke="none " cx="6 " cy="50 " r="6 ">
                <animateTransform attributeName="transform " dur="1s " type="translate " values="0 15 ; 0 -15; 0 15 " repeatCount="indefinite " begin="0.1 "/>
            </circle>
            <circle fill="currentColor " stroke="none " cx="30 " cy="50 " r="6 ">
                <animateTransform attributeName="transform " dur="1s " type="translate " values="0 10 ; 0 -10; 0 10 " repeatCount="indefinite " begin="0.2 "/>
            </circle>
            <circle fill="currentColor " stroke="none " cx="54 " cy="50 " r="6 ">
                <animateTransform attributeName="transform " dur="1s " type="translate " values="0 5 ; 0 -5; 0 5 " repeatCount="indefinite " begin="0.3 "/>
            </circle>
        </svg>
    </div>
        <div class="age-gate__background-color "></div>    <div class="age-gate__background ">            </div>
    
    <div class="age-gate " role="dialog " aria-modal="true " aria-label=" ">    <form method="post " class="age-gate__form ">
<div class="age-gate__heading ">            <img src="https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2025/07/30110120/basketeer-logo-600.png " width="622 " height="135 " alt="Basketeer - The Art Of Giving "class="age-gate__heading-title
                        age-gate__heading-title--logo " />    </div>
<p class="age-gate__subheadline ">    </p>
<div class="age-gate__fields ">        
<p class="age-gate__challenge ">    Are you over 20 years of age?
</p>
<div class="age-gate__buttons ">        <button type="submit " class="age-gate__submit age-gate__submit--yes " data-submit="yes " value="1 " name="age_gate[confirm] ">Yes</button>            <button class="age-gate__submit age-gate__submit--no
                        " data-submit="no " value="0 " name="age_gate[confirm] " type="submit ">No</button>    </div>
    </div>

<input type="hidden " name="age_gate[age] " value="B4Y+gsvuh3K8RnpRngrCdw==" />
<input type=" hidden " name="age_gate[lang] " value="en " />
    <input type="hidden " name="age_gate[confirm] " />
    <div class="age-gate__remember-wrapper ">        <label class="age-gate__remember ">            <input type="checkbox " class="age-gate__remember-field " name="age_gate[remember] " value="1 "  /> <span type="checkbox " class="age-gate__remember-text ">Remember me</span>        </label>
    </div>
    <div class="age-gate__errors "></div></form>
    </div>
    </div>
    </template>
<script type="speculationrules ">
{"prefetch ":[{"source ":"document ","where ":{"and ":[{"href_matches ":"\/* "},{"not ":{"href_matches ":["\/wp-*.php ","\/wp-admin\/* ","\/wp-content\/uploads\/* ","\/wp-content\/* ","\/wp-content\/plugins\/* ","\/wp-content\/themes\/baskettheme\/*
                        ","\/*\\?(.+) "]}},{"not ":{"selector_matches ":"a[rel~=\ "nofollow\"] "}},{"not ":{"selector_matches ":".no-prefetch, .no-prefetch a "}}]},"eagerness ":"conservative "}]}
</script>
<script id="ckyBannerTemplate " type="text/template "><div class="cky-overlay cky-hide "></div><div class="cky-btn-revisit-wrapper cky-revisit-hide " data-cky-tag="revisit-consent " data-tooltip="Consent Preferences " style="background-color:#c09a5c
                        "> <button class="cky-btn-revisit " aria-label="Consent Preferences "> <img src="https://eadn-wc04-9792563.nxedge.io/wp-content/plugins/cookie-law-info/lite/frontend/images/revisit.svg " alt="Revisit consent button "> </button></div><div class="cky-consent-container
                        cky-hide " tabindex="0 "> <div class="cky-consent-bar " data-cky-tag="notice " style="background-color:#FFFFFF;border-color:#F4F4F4 ">  <div class="cky-notice "> <p class="cky-title " role="heading " aria-level="1 " data-cky-tag="title
                        " style="color:#212121 ">We value your privacy</p><div class="cky-notice-group "> <div class="cky-notice-des " data-cky-tag="description " style="color:#212121
                        "> <p>We use cookies to enhance your browsing experience, serve personalised ads or content, and analyse our traffic. By clicking "Accept All ", you consent to our use of cookies.</p> </div><div class="cky-notice-btn-wrapper " data-cky-tag="notice-buttons "> <button class="cky-btn cky-btn-customize " aria-label="Customise " data-cky-tag="settings-button
                        " style="color:#c09a5c;background-color:transparent;border-color:#c09a5c ">Customise</button> <button class="cky-btn cky-btn-reject " aria-label="Reject All " data-cky-tag="reject-button " style="color:#c09a5c;background-color:transparent;border-color:#c09a5c
                        ">Reject All</button> <button class="cky-btn cky-btn-accept " aria-label="Accept All " data-cky-tag="accept-button " style="color:#FFFFFF;background-color:#c09a5c;border-color:#c09a5c ">Accept All</button>  </div></div></div></div></div><div class="cky-modal
                        " tabindex="0 "> <div class="cky-preference-center " data-cky-tag="detail " style="color:#212121;background-color:#FFFFFF;border-color:#F4F4F4 "> <div class="cky-preference-header "> <span class="cky-preference-title " role="heading
                        " aria-level="1 " data-cky-tag="detail-title " style="color:#212121 ">Customise Consent Preferences</span> <button class="cky-btn-close " aria-label="[cky_preference_close_label] " data-cky-tag="detail-close "> <img src="https://eadn-wc04-9792563.nxedge.io/wp-content/plugins/cookie-law-info/lite/frontend/images/close.svg
                        " alt="Close "> </button> </div><div class="cky-preference-body-wrapper "> <div class="cky-preference-content-wrapper " data-cky-tag="detail-description " style="color:#212121
                        "> <p>We use cookies to help you navigate efficiently and perform certain functions. You will find detailed information about all cookies under each consent category below.</p><p>The cookies that are categorised as "Necessary
                        " are stored on your browser as they are essential for enabling the basic functionalities of the site. </p><p>We also use third-party cookies that help us analyse how you use this website, store your preferences, and provide the content and advertisements that are relevant to you. These cookies will only be stored in your browser with your prior consent.</p><p>You can choose to enable or disable some or all of these cookies but disabling some of them may affect your browsing experience.</p> </div><div class="cky-accordion-wrapper " data-cky-tag="detail-categories "> <div class="cky-accordion " id="ckyDetailCategorynecessary "> <div class="cky-accordion-item "> <div class="cky-accordion-chevron "><i class="cky-chevron-right
                        "></i></div> <div class="cky-accordion-header-wrapper "> <div class="cky-accordion-header "><button class="cky-accordion-btn " aria-label="Necessary " data-cky-tag="detail-category-title " style="color:#212121 ">Necessary</button><span class="cky-always-active
                        ">Always Active</span> <div class="cky-switch " data-cky-tag="detail-category-toggle "><input type="checkbox " id="ckySwitchnecessary "></div> </div> <div class="cky-accordion-header-des " data-cky-tag="detail-category-description " style="color:#212121
                        "> <p>Necessary cookies are required to enable the basic features of this site, such as providing secure log-in or adjusting your consent preferences. These cookies do not store any personally identifiable data.</p></div> </div> </div> <div class="cky-accordion-body "> <div class="cky-audit-table " data-cky-tag="audit-table " style="color:#212121;background-color:#f4f4f4;border-color:#ebebeb "><p class="cky-empty-cookies-text
                        ">No cookies to display.</p></div> </div> </div><div class="cky-accordion " id="ckyDetailCategoryfunctional "> <div class="cky-accordion-item "> <div class="cky-accordion-chevron "><i class="cky-chevron-right "></i></div> <div class="cky-accordion-header-wrapper "> <div class="cky-accordion-header
                        "><button class="cky-accordion-btn " aria-label="Functional " data-cky-tag="detail-category-title " style="color:#212121 ">Functional</button><span class="cky-always-active ">Always Active</span> <div class="cky-switch " data-cky-tag="detail-category-toggle
                        "><input type="checkbox " id="ckySwitchfunctional "></div> </div> <div class="cky-accordion-header-des " data-cky-tag="detail-category-description " style="color:#212121
                        "> <p>Functional cookies help perform certain functionalities like sharing the content of the website on social media platforms, collecting feedback, and other third-party features.</p></div> </div> </div> <div class="cky-accordion-body "> <div class="cky-audit-table " data-cky-tag="audit-table " style="color:#212121;background-color:#f4f4f4;border-color:#ebebeb "><p class="cky-empty-cookies-text
                        ">No cookies to display.</p></div> </div> </div><div class="cky-accordion " id="ckyDetailCategoryanalytics "> <div class="cky-accordion-item "> <div class="cky-accordion-chevron "><i class="cky-chevron-right "></i></div> <div class="cky-accordion-header-wrapper "> <div class="cky-accordion-header
                        "><button class="cky-accordion-btn " aria-label="Analytics " data-cky-tag="detail-category-title " style="color:#212121 ">Analytics</button><span class="cky-always-active ">Always Active</span> <div class="cky-switch " data-cky-tag="detail-category-toggle
                        "><input type="checkbox " id="ckySwitchanalytics "></div> </div> <div class="cky-accordion-header-des " data-cky-tag="detail-category-description " style="color:#212121
                        "> <p>Analytical cookies are used to understand how visitors interact with the website. These cookies help provide information on metrics such as the number of visitors, bounce rate, traffic source, etc.</p></div> </div> </div> <div class="cky-accordion-body "> <div class="cky-audit-table " data-cky-tag="audit-table " style="color:#212121;background-color:#f4f4f4;border-color:#ebebeb "><p class="cky-empty-cookies-text
                        ">No cookies to display.</p></div> </div> </div><div class="cky-accordion " id="ckyDetailCategoryperformance "> <div class="cky-accordion-item "> <div class="cky-accordion-chevron "><i class="cky-chevron-right "></i></div> <div class="cky-accordion-header-wrapper "> <div class="cky-accordion-header
                        "><button class="cky-accordion-btn " aria-label="Performance " data-cky-tag="detail-category-title " style="color:#212121 ">Performance</button><span class="cky-always-active ">Always Active</span> <div class="cky-switch " data-cky-tag="detail-category-toggle
                        "><input type="checkbox " id="ckySwitchperformance "></div> </div> <div class="cky-accordion-header-des " data-cky-tag="detail-category-description " style="color:#212121
                        "> <p>Performance cookies are used to understand and analyse the key performance indexes of the website which helps in delivering a better user experience for the visitors.</p></div> </div> </div> <div class="cky-accordion-body "> <div class="cky-audit-table " data-cky-tag="audit-table " style="color:#212121;background-color:#f4f4f4;border-color:#ebebeb "><p class="cky-empty-cookies-text
                        ">No cookies to display.</p></div> </div> </div><div class="cky-accordion " id="ckyDetailCategoryadvertisement "> <div class="cky-accordion-item "> <div class="cky-accordion-chevron "><i class="cky-chevron-right "></i></div> <div class="cky-accordion-header-wrapper "> <div class="cky-accordion-header
                        "><button class="cky-accordion-btn " aria-label="Advertisement " data-cky-tag="detail-category-title " style="color:#212121 ">Advertisement</button><span class="cky-always-active ">Always Active</span> <div class="cky-switch " data-cky-tag="detail-category-toggle
                        "><input type="checkbox " id="ckySwitchadvertisement "></div> </div> <div class="cky-accordion-header-des " data-cky-tag="detail-category-description " style="color:#212121
                        "> <p>Advertisement cookies are used to provide visitors with customised advertisements based on the pages you visited previously and to analyse the effectiveness of the ad campaigns.</p></div> </div> </div> <div class="cky-accordion-body "> <div class="cky-audit-table " data-cky-tag="audit-table " style="color:#212121;background-color:#f4f4f4;border-color:#ebebeb "><p class="cky-empty-cookies-text
                        ">No cookies to display.</p></div> </div> </div> </div></div><div class="cky-footer-wrapper "> <span class="cky-footer-shadow "></span> <div class="cky-prefrence-btn-wrapper " data-cky-tag="detail-buttons "> <button class="cky-btn cky-btn-reject " aria-label="Reject All " data-cky-tag="detail-reject-button
                        " style="color:#c09a5c;background-color:transparent;border-color:#c09a5c "> Reject All </button> <button class="cky-btn cky-btn-preferences " aria-label="Save My Preferences " data-cky-tag="detail-save-button " style="color:#c09a5c;background-color:transparent;border-color:#c09a5c
                        "> Save My Preferences </button> <button class="cky-btn cky-btn-accept " aria-label="Accept All " data-cky-tag="detail-accept-button " style="color:#FFFFFF;background-color:#c09a5c;border-color:#c09a5c "> Accept All </button> </div></div></div></div></script>		<script type="text/javascript ">
			function dnd_cf7_generateUUIDv4() {
				const bytes = new Uint8Array(16);
				crypto.getRandomValues(bytes);
				bytes[6] = (bytes[6] & 0x0f) | 0x40; // version 4
				bytes[8] = (bytes[8] & 0x3f) | 0x80; // variant 10
				const hex = Array.from(bytes, b => b.toString(16).padStart(2, "0 ")).join(" ");
				return hex.replace(/^(.{8})(.{4})(.{4})(.{4})(.{12})$/, "$1-$2-$3-$4-$5 ");
			}

			document.addEventListener("DOMContentLoaded ", function() {
				if ( ! document.cookie.includes("wpcf7_guest_user_id ")) {
					document.cookie = "wpcf7_guest_user_id=" + dnd_cf7_generateUUIDv4() + " ; path=/; max-age=" + (12 * 3600) + " ; samesite=Lax ";
				}
			});
		</script>
			<script type='text/javascript'>
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})();
	</script>
	<link rel='stylesheet' id='wc-blocks-style-css' href='https://basketeer.com/wp-content/plugins/woocommerce/assets/client/blocks/wc-blocks.css?ver=wc-9.5.1' type='text/css' media='all' />
<link rel='stylesheet' id='woof_sections_style-css' href='https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/sections/css/sections.css?ver=1.3.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='ion.range-slider-css' href='https://basketeer.com/wp-content/plugins/woocommerce-products-filter/js/ion.range-slider/css/ion.rangeSlider.css?ver=1.3.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='woof-front-builder-css-css' href='https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/front_builder/css/front-builder.css?ver=1.3.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='woof-slideout-tab-css-css' href='https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/slideout/css/jquery.tabSlideOut.css?ver=1.3.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='woof-slideout-css-css' href='https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/slideout/css/slideout.css?ver=1.3.7.1' type='text/css' media='all' />
<script type="text/javascript " id="woof_front-js-extra ">
/* <![CDATA[ */
var woof_filter_titles = {"by_price ":"by_price ","songkran-specials ":"Songkran Specials ","product_custom_content ":"Contents ","fruit_custom_type ":"Fruit types ","bakery_type_custom ":"Bakery Type ","basket_custom_type ":"Basket types ","delivery_option
                        ":"Delivery Option ","product_custom_type ":"Product types ","product_custom_theme ":"Themes ","product_custom_recipient ":"Recipients ","product_custom_occasion ":"Occasions ","combo_custom_type ":"Combo types ","flavors_custom_product
                        ":"Flavors ","dietary_restrictions_custom ":"Dietary Restrictions ","flower_type_custom ":"Flower Type ","numbers_of_Balloons_custom ":"# Of Balloons ","size_type_custom ":"Size ","color_type_custom ":"Color ","pa_flower_colour ":"Product
                        Flower Colour ","flower_ranges ":"Flower Ranges "};
var woof_ext_filter_titles = {"woof_author ":"By author ","product_visibility ":"Featured products ","stock ":"In stock ","onsales ":"On sale ","byrating ":"By rating ","woof_text ":"By text "};
/* ]]> */
</script>
<script type="text/javascript " id="woof_front-js-before ">
/* <![CDATA[ */
        const woof_front_nonce = "81c5dd9be0 ";
        var woof_is_permalink =1;
        var woof_shop_page = " ";
                var woof_m_b_container =".woocommerce-products-header ";
        var woof_really_curr_tax = {};
        var woof_current_page_link = location.protocol + '//' + location.host + location.pathname;
        /*lets remove pagination from woof_current_page_link*/
        woof_current_page_link = woof_current_page_link.replace(/\page\/[0-9]+/, " ");
                        woof_current_page_link = "https://basketeer.com/shop/ ";
                        var woof_link = 'https://basketeer.com/wp-content/plugins/woocommerce-products-filter/';
        
        var woof_ajaxurl = "https://basketeer.com/wp-admin/admin-ajax.php ";

        var woof_lang = {
        'orderby': "orderby ",
        'date': "date ",
        'perpage': "per page ",
        'pricerange': "price range ",
        'menu_order': "menu order ",
        'popularity': "popularity ",
        'rating': "rating ",
        'price': "price low to high ",
        'price-desc': "price high to low ",
        'clear_all': "Clear All ",
        'list_opener': "Сhild list opener ",
        };

        if (typeof woof_lang_custom == 'undefined') {
        var woof_lang_custom = {};/*!!important*/
        }

        var woof_is_mobile = 0;
                    woof_is_mobile = 1;
        


        var woof_show_price_search_button = 0;
        var woof_show_price_search_type = 0;
        
        var woof_show_price_search_type = 5;
        var swoof_search_slug = "swoof ";

        
        var icheck_skin = {};
                    icheck_skin = 'none';
        
        var woof_select_type = 'native';


                var woof_current_values = '[]';
                var woof_lang_loading = "Loading ... ";

        
        var woof_lang_show_products_filter = "show products filter ";
        var woof_lang_hide_products_filter = "hide products filter ";
        var woof_lang_pricerange = "price range ";

        var woof_use_beauty_scroll =0;

        var woof_autosubmit =1;
        var woof_ajaxurl = "https://basketeer.com/wp-admin/admin-ajax.php ";
        /*var woof_submit_link = " ";*/
        var woof_is_ajax = 0;
        var woof_ajax_redraw = 0;
        var woof_ajax_page_num =1;
        var woof_ajax_first_done = false;
        var woof_checkboxes_slide_flag = 0;


        /*toggles*/
        var woof_toggle_type = "image ";

        var woof_toggle_closed_text = "+ ";
        var woof_toggle_opened_text = "- ";

        var woof_toggle_closed_image = "https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/toggle-up.svg ";
        var woof_toggle_opened_image = "https://basketeer.s3.ap-south-1.amazonaws.com/wp-content/uploads/2023/06/toggle-up.svg ";

        var woof_save_state_checkbox = 1;

        /*indexes which can be displayed in red buttons panel*/
                var woof_accept_array = ["min_price ", "orderby ", "perpage ", "woof_author ","featured ","stock ","onsales ","byrating ","woof_text ","min_rating ","discount ","delivery_option ","product_badge ","product_custom_option ","product_custom_type
                        ","product_custom_theme ","product_custom_recipient ","product_custom_occasion ","product_custom_alcohol ","product_custom_alcohol_type ","product_custom_content ","fruit_custom_type ","basket_custom_type ","combo_custom_type ","wine_custom_type
                        ","grape_custom_variety ","country_of_origin_custom ","numbers_of_wine_custom ","flavors_custom_product ","bakery_type_custom ","dietary_restrictions_custom ","flower_type_custom ","numbers_of_Balloons_custom ","size_type_custom ","color_type_custom
                        ","product_visibility ","product_cat ","product_tag ","pa_alcohol-type ","pa_brand ","pa_cake-flovour ","pa_cake-size ","pa_color ","pa_color-cake ","pa_flower_colour ","pa_size ","pa_wine ","flower_ranges ","songkran-specials "];

        
        /*for extensions*/

        var woof_ext_init_functions = null;
                    woof_ext_init_functions = '{"by_author ":"woof_init_author ","by_featured ":"woof_init_featured ","by_instock ":"woof_init_instock ","by_onsales ":"woof_init_onsales ","by_text ":"woof_init_text ","label ":"woof_init_labels ","select_radio_check
                        ":"woof_init_select_radio_check "}';
        

        
        var woof_overlay_skin = "default ";

        
 function woof_js_after_ajax_done() { jQuery(document).trigger('woof_ajax_done'); 

}
 var woof_front_sd_is_a=1;var woof_front_show_notes=1;var woof_lang_front_builder_del="Are you sure you want to delete this filter-section? ";var woof_lang_front_builder_options="Options ";var woof_lang_front_builder_option="Option
                        ";var woof_lang_front_builder_section_options="Section Options ";var woof_lang_front_builder_description="Description ";var woof_lang_front_builder_close="Close ";var woof_lang_front_builder_suggest="Suggest the feature ";var woof_lang_front_builder_good_to_use="good to use in
                        content areas ";var woof_lang_front_builder_confirm_sd="Smart Designer item will be created and attached to this filter section and will cancel current type, proceed? ";var woof_lang_front_builder_creating="Creating
                        ";var woof_lang_front_builder_shortcode="Shortcode ";var woof_lang_front_builder_layout="Layout ";var woof_lang_front_builder_filter_section="Section options ";var woof_lang_front_builder_filter_redrawing="filter redrawing ";var woof_lang_front_builder_filter_redrawn="redrawn
                        ";var woof_lang_front_builder_filter_redrawn="redrawn ";var woof_lang_front_builder_title_top_info="this functionality is only visible for the site administrator ";var woof_lang_front_builder_title_top_info_demo="demo mode is activated, and results are visible only to you
                        ";;var woof_lang_front_builder_select="+ Add filter section ";
/* ]]> */
</script>
<script type="text/javascript " src="https://basketeer.com/wp-content/plugins/woocommerce-products-filter/js/front.js?ver=1.3.7.1 " id="woof_front-js "></script>
<script type="text/javascript " id="woof_url_parser-js-extra ">
/* <![CDATA[ */
var url_parser_data = {"filters ":{"by_price ":"price ","songkran-specials ":"songkran-specials ","product_custom_content ":"product_custom_content ","fruit_custom_type ":"fruit_custom_type ","bakery_type_custom ":"bakery_type_custom ","basket_custom_type
                        ":"basket_custom_type ","delivery_option ":"delivery_option ","product_cat ":"product_cat ","discount ":"discount ","woof_text ":"name ","by_text ":"by_text ","pa_cake-size ":"cake-size ","woof_author ":"author ","by_author ":"by_author
                        ","by_instock ":"by_instock ","by_onsales ":"by_onsales ","min_rating ":"min_rating ","by_rating ":"by_rating ","product_badge ":"product_badge ","product_visibility ":"product_visibility ","product_tag ":"product_tag ","pa_brand ":"brand
                        ","pa_cake-flovour ":"cake-flovour ","pa_size ":"size ","pa_wine ":"wine ","product_custom_option ":"product_custom_option ","by_featured ":"by_featured ","product_custom_type ":"product_custom_type ","product_custom_theme ":"product_custom_theme
                        ","product_custom_recipient ":"product_custom_recipient ","product_custom_occasion ":"product_custom_occasion ","product_custom_alcohol ":"product_custom_alcohol ","product_custom_alcohol_type ":"product_custom_alcohol_type ","combo_custom_type
                        ":"combo_custom_type ","wine_custom_type ":"wine_custom_type ","grape_custom_variety ":"grape_custom_variety ","country_of_origin_custom ":"country_of_origin_custom ","numbers_of_wine_custom ":"numbers_of_wine_custom ","flavors_custom_product
                        ":"flavors_custom_product ","dietary_restrictions_custom ":"dietary_restrictions_custom ","flower_type_custom ":"flower_type_custom ","numbers_of_Balloons_custom ":"numbers_of_Balloons_custom ","size_type_custom ":"size_type_custom
                        ","color_type_custom ":"color_type_custom ","pa_alcohol-type ":"alcohol-type ","pa_flower_colour ":"flower_colour ","pa_color ":"color ","flower_ranges ":"flower_ranges ","pa_color-cake ":"color-cake ","instock ":"instock ","onsale
                        ":"onsale ","featured ":"featured ","backorder_not_in ":"backorder_not_in ","rev_songkran-specials ":"songkran-specials ","rev_product_custom_content ":"product_custom_content ","rev_fruit_custom_type ":"fruit_custom_type ","rev_bakery_type_custom
                        ":"bakery_type_custom ","rev_basket_custom_type ":"basket_custom_type ","rev_delivery_option ":"delivery_option ","rev_product_cat ":"product_cat ","rev_discount ":"discount ","rev_pa_cake-size ":"cake-size ","rev_product_badge ":"product_badge
                        ","rev_product_visibility ":"product_visibility ","rev_product_tag ":"product_tag ","rev_pa_brand ":"brand ","rev_pa_cake-flovour ":"cake-flovour ","rev_pa_size ":"size ","rev_pa_wine ":"wine ","rev_product_custom_option ":"product_custom_option
                        ","rev_product_custom_type ":"product_custom_type ","rev_product_custom_theme ":"product_custom_theme ","rev_product_custom_recipient ":"product_custom_recipient ","rev_product_custom_occasion ":"product_custom_occasion ","rev_product_custom_alcohol
                        ":"product_custom_alcohol ","rev_product_custom_alcohol_type ":"product_custom_alcohol_type ","rev_combo_custom_type ":"combo_custom_type ","rev_wine_custom_type ":"wine_custom_type ","rev_grape_custom_variety ":"grape_custom_variety
                        ","rev_country_of_origin_custom ":"country_of_origin_custom ","rev_numbers_of_wine_custom ":"numbers_of_wine_custom ","rev_flavors_custom_product ":"flavors_custom_product ","rev_dietary_restrictions_custom ":"dietary_restrictions_custom
                        ","rev_flower_type_custom ":"flower_type_custom ","rev_numbers_of_Balloons_custom ":"numbers_of_Balloons_custom ","rev_size_type_custom ":"size_type_custom ","rev_color_type_custom ":"color_type_custom ","rev_pa_alcohol-type ":"alcohol-type
                        ","rev_pa_flower_colour ":"flower_colour ","rev_pa_color ":"color ","rev_flower_ranges ":"flower_ranges ","rev_pa_color-cake ":"color-cake "},"special ":{"stock ":"instock ","onsales ":"onsale ","product_visibility ":"featured ","backorder
                        ":"backorder_not_in "}};
/* ]]> */
</script>
<script type="text/javascript " src="https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/url_request/js/url_parser.js?ver=1.3.7.1 " id="woof_url_parser-js "></script>
<script type="text/javascript " src="https://basketeer.com/wp-content/themes/baskettheme/js/classlist-guard.js " id="classlist-guard-js "></script>
<script type="text/javascript " src="https://basketeer.com/wp-content/themes/baskettheme/js/single-article.js " id="single-article-js "></script>
<script type="text/javascript " src="https://basketeer.com/wp-content/plugins/yith-woocommerce-wishlist/assets/js/jquery.selectBox.min.js?ver=1.2.0 " id="jquery-selectBox-js "></script>
<script type="text/javascript " src="//basketeer.com/wp-content/plugins/woocommerce/assets/js/prettyPhoto/jquery.prettyPhoto.min.js?ver=3.1.6 " id="prettyPhoto-js " data-wp-strategy="defer "></script>
<script type="text/javascript " id="jquery-yith-wcwl-js-extra ">
/* <![CDATA[ */
var yith_wcwl_l10n = {"ajax_url ":"\/wp-admin\/admin-ajax.php ","redirect_to_cart ":"no ","yith_wcwl_button_position ":"shortcode ","multi_wishlist ":" ","hide_add_button ":"1 ","enable_ajax_loading ":" ","ajax_loader_url ":"https:\/\/eadn-wc04-9792563.nxedge.io\/wp-content\/plugins\/yith-woocommerce-wishlist\/assets\/images\/ajax-loader-alt.svg
                        ","remove_from_wishlist_after_add_to_cart ":"1 ","is_wishlist_responsive ":"1 ","time_to_close_prettyphoto ":"3000 ","fragments_index_glue ":". ","reload_on_found_variation ":"1 ","mobile_media_query ":"768 ","labels ":{"cookie_disabled
                        ":"We are sorry, but this feature is available only if cookies on your browser are enabled. ","added_to_cart_message ":"<div class=\ "woocommerce-notices-wrapper\">
                    <div class=\ "woocommerce-message\" role=\
                        "alert\">Product added to cart successfully
                        <\/div>
                            <\/div>"},"actions":{"add_to_wishlist_action":"add_to_wishlist","remove_from_wishlist_action":"remove_from_wishlist","reload_wishlist_and_adding_elem_action":"reload_wishlist_and_adding_elem","load_mobile_action":"load_mobile","delete_item_action":"delete_item","save_title_action":"save_title","save_privacy_action":"save_privacy","load_fragments":"load_fragments"},"nonce":{"add_to_wishlist_nonce":"ac128f1e70","remove_from_wishlist_nonce":"af20440c6c","reload_wishlist_and_adding_elem_nonce":"c23b521763","load_mobile_nonce":"2a6629b3b2","delete_item_nonce":"c6c227c620","save_title_nonce":"7402dd3271","save_privacy_nonce":"ccc84747d0","load_fragments_nonce":"e7f89434db"},"redirect_after_ask_estimate":"","ask_estimate_redirect_url":"https:\/\/basketeer.com"};
                                /* ]]> */
                                </script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/yith-woocommerce-wishlist/assets/js/jquery.yith-wcwl.min.js?ver=4.9.0" id="jquery-yith-wcwl-js"></script>
                                <script type="text/javascript" id="age-gate-all-js-extra">
                                    /* <![CDATA[ */
                                    var age_gate_common = {
                                        "cookies": "Your browser does not support cookies, you may experience problems entering this site",
                                        "simple": ""
                                    };
                                    /* ]]> */
                                </script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/age-gate/dist/all.js?ver=3.7.1" id="age-gate-all-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-includes/js/dist/hooks.min.js?ver=4d63a3d491d11ffd8ac6" id="wp-hooks-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-includes/js/dist/i18n.min.js?ver=5e580eb46a90c2b997e6" id="wp-i18n-js"></script>
                                <script type="text/javascript" id="wp-i18n-js-after">
                                    /* <![CDATA[ */
                                    wp.i18n.setLocaleData({
                                        'text direction\u0004ltr': ['ltr']
                                    });
                                    /* ]]> */
                                </script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=6.1.2" id="swv-js"></script>
                                <script type="text/javascript" id="contact-form-7-js-before">
                                    /* <![CDATA[ */
                                    var wpcf7 = {
                                        "api": {
                                            "root": "https:\/\/basketeer.com\/wp-json\/",
                                            "namespace": "contact-form-7\/v1"
                                        }
                                    };
                                    /* ]]> */
                                </script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=6.1.2" id="contact-form-7-js"></script>
                                <script type="text/javascript" id="codedropz-uploader-js-extra">
                                    /* <![CDATA[ */
                                    var dnd_cf7_uploader = {
                                        "ajax_url": "https:\/\/basketeer.com\/wp-admin\/admin-ajax.php",
                                        "ajax_nonce": "3b3657da39",
                                        "drag_n_drop_upload": {
                                            "tag": "h3",
                                            "text": "Drag & Drop Files Here",
                                            "or_separator": "or",
                                            "browse": "Browse Files",
                                            "server_max_error": "The uploaded file exceeds the maximum upload size of your server.",
                                            "large_file": "Uploaded file is too large",
                                            "inavalid_type": "Uploaded file is not allowed for file type",
                                            "max_file_limit": "Note : Some of the files are not uploaded ( Only %count% files allowed )",
                                            "required": "This field is required.",
                                            "delete": {
                                                "text": "deleting",
                                                "title": "Remove"
                                            }
                                        },
                                        "dnd_text_counter": "of",
                                        "disable_btn": ""
                                    };
                                    /* ]]> */
                                </script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/drag-and-drop-multiple-file-upload-contact-form-7/assets/js/codedropz-uploader-min.js?ver=1.3.9.1" id="codedropz-uploader-js"></script>
                                <script type="text/javascript" id="magni-image-js-js-extra">
                                    /* <![CDATA[ */
                                    var magniimage_vars = {
                                        "dotvalue": "no",
                                        "imgeffect": "fade",
                                        "activedotcolor": "#100e0e",
                                        "inactivedotcolor": "#b2b2ad",
                                        "speed": "200",
                                        "dotposition": "topleft",
                                        "loop": "yes"
                                    };
                                    /* ]]> */
                                </script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/magni-image-flip-for-woocommerce/assets/js/magniimage.js?ver=1.0.0" id="magni-image-js-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/magni-image-flip-for-woocommerce/assets/js/jquery.cycle2.js?ver=1.0.0" id="wcmi-jquery-cycle2-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/magni-image-flip-for-woocommerce/assets/js/jquery.cycle2.scrollVert.js?ver=1.0.0" id="woomi-jquery-cycle2-scrollvert-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/magni-image-flip-for-woocommerce/assets/js/jquery.cycle2.flip.js?ver=1.0.0" id="woomi-jquery-cycle2-flipvert-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-includes/js/jquery/ui/core.min.js?ver=1.13.3" id="jquery-ui-core-js"></script>
                                <script type="text/javascript" id="jquery-ui-datepicker-js-before">
                                    /* <![CDATA[ */
                                    var blockedDates = ["2025-01-06", "2025-01-07", "2025-01-20", "2025-01-26", "2025-01-27", "2025-01-28", "2025-01-29", "2025-02-13", "2025-02-14", "2025-02-15", "2025-03-14", "2025-03-15", "2025-03-16"];
                                    /* ]]> */
                                </script>
                                <script type="text/javascript" src="https://basketeer.com/wp-includes/js/jquery/ui/datepicker.min.js?ver=1.13.3" id="jquery-ui-datepicker-js"></script>
                                <script type="text/javascript" id="jquery-ui-datepicker-js-after">
                                    /* <![CDATA[ */
                                    jQuery(function(jQuery) {
                                        jQuery.datepicker.setDefaults({
                                            "closeText": "Close",
                                            "currentText": "Today",
                                            "monthNames": ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                                            "monthNamesShort": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                                            "nextText": "Next",
                                            "prevText": "Previous",
                                            "dayNames": ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                                            "dayNamesShort": ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
                                            "dayNamesMin": ["S", "M", "T", "W", "T", "F", "S"],
                                            "dateFormat": "MM d, yy",
                                            "firstDay": 1,
                                            "isRTL": false
                                        });
                                    });
                                    /* ]]> */
                                </script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/duracelltomi-google-tag-manager/dist/js/gtm4wp-ecommerce-generic.js?ver=1.22.1" id="gtm4wp-ecommerce-generic-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/duracelltomi-google-tag-manager/dist/js/gtm4wp-woocommerce.js?ver=1.22.1" id="gtm4wp-woocommerce-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-includes/js/underscore.min.js?ver=1.13.7" id="underscore-js"></script>
                                <script type="text/javascript" id="wp-util-js-extra">
                                    /* <![CDATA[ */
                                    var _wpUtilSettings = {
                                        "ajax": {
                                            "url": "\/wp-admin\/admin-ajax.php"
                                        }
                                    };
                                    /* ]]> */
                                </script>
                                <script type="text/javascript" src="https://basketeer.com/wp-includes/js/wp-util.min.js?ver=6.8.3" id="wp-util-js"></script>
                                <script type="text/javascript" id="wp-api-request-js-extra">
                                    /* <![CDATA[ */
                                    var wpApiSettings = {
                                        "root": "https:\/\/basketeer.com\/wp-json\/",
                                        "nonce": "62245f99f2",
                                        "versionString": "wp\/v2\/"
                                    };
                                    /* ]]> */
                                </script>
                                <script type="text/javascript" src="https://basketeer.com/wp-includes/js/api-request.min.js?ver=6.8.3" id="wp-api-request-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0" id="wp-polyfill-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-includes/js/dist/url.min.js?ver=c2964167dfe2477c14ea" id="wp-url-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-includes/js/dist/api-fetch.min.js?ver=3623a576c78df404ff20" id="wp-api-fetch-js"></script>
                                <script type="text/javascript" id="wp-api-fetch-js-after">
                                    /* <![CDATA[ */
                                    wp.apiFetch.use(wp.apiFetch.createRootURLMiddleware("https://basketeer.com/wp-json/"));
                                    wp.apiFetch.nonceMiddleware = wp.apiFetch.createNonceMiddleware("62245f99f2");
                                    wp.apiFetch.use(wp.apiFetch.nonceMiddleware);
                                    wp.apiFetch.use(wp.apiFetch.mediaUploadMiddleware);
                                    wp.apiFetch.nonceEndpoint = "https://basketeer.com/wp-admin/admin-ajax.php?action=rest-nonce";
                                    /* ]]> */
                                </script>
                                <script type="text/javascript" id="woo-variation-swatches-js-extra">
                                    /* <![CDATA[ */
                                    var woo_variation_swatches_options = {
                                        "show_variation_label": "1",
                                        "clear_on_reselect": "",
                                        "variation_label_separator": ":",
                                        "is_mobile": "1",
                                        "show_variation_stock": "",
                                        "stock_label_threshold": "5",
                                        "cart_redirect_after_add": "no",
                                        "enable_ajax_add_to_cart": "yes",
                                        "cart_url": "https:\/\/basketeer.com\/cart\/",
                                        "is_cart": ""
                                    };
                                    /* ]]> */
                                </script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/woo-variation-swatches/assets/js/frontend.min.js?ver=1759825192" id="woo-variation-swatches-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/themes/baskettheme/js/bootstrap.bundle.min.js?ver=5.2.3" id="bootstrap-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/themes/baskettheme/js/app.js?ver=1.0.3.202509081524" id="site-js"></script>
                                <script type="text/javascript" id="my-ajax-script-js-extra">
                                    /* <![CDATA[ */
                                    var my_ajax_object = {
                                        "ajaxurl": "https:\/\/basketeer.com\/wp-admin\/admin-ajax.php",
                                        "nonce": "3c1f58d7fc"
                                    };
                                    /* ]]> */
                                </script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/themes/baskettheme/js/external/custom.js?ver=1.0" id="my-ajax-script-js"></script>
                                <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/js/splide.min.js?ver=4.1.4" id="splide-js-js"></script>
                                <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/algoliasearch@4/dist/algoliasearch-lite.umd.js" id="algolia-client-js"></script>
                                <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/instantsearch.js@4" id="instantsearch-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/themes/baskettheme/js/algolia-search.js" id="algolia-search-js"></script>
                                <script type="text/javascript" id="chaty-front-end-js-extra">
                                    /* <![CDATA[ */
                                    var chaty_settings = {
                                        "ajax_url": "https:\/\/basketeer.com\/wp-admin\/admin-ajax.php",
                                        "analytics": "0",
                                        "capture_analytics": "0",
                                        "token": "9a8ce11d75",
                                        "chaty_widgets": [{
                                            "id": 0,
                                            "identifier": 0,
                                            "settings": {
                                                "cta_type": "simple-view",
                                                "cta_body": "",
                                                "cta_head": "",
                                                "cta_head_bg_color": "",
                                                "cta_head_text_color": "",
                                                "show_close_button": 1,
                                                "position": "right",
                                                "custom_position": 1,
                                                "bottom_spacing": "25",
                                                "side_spacing": "25",
                                                "icon_view": "vertical",
                                                "default_state": "open",
                                                "cta_text": "",
                                                "cta_text_color": "#333333",
                                                "cta_bg_color": "#ffffff",
                                                "show_cta": "all_time",
                                                "is_pending_mesg_enabled": "off",
                                                "pending_mesg_count": "",
                                                "pending_mesg_count_color": "#ffffff",
                                                "pending_mesg_count_bgcolor": "#dd0000",
                                                "widget_icon": "chat-base",
                                                "widget_icon_url": "",
                                                "font_family": "-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen-Sans,Ubuntu,Cantarell,Helvetica Neue,sans-serif",
                                                "widget_size": "54",
                                                "custom_widget_size": "54",
                                                "is_google_analytics_enabled": 0,
                                                "close_text": "Hide",
                                                "widget_color": "#FF6060",
                                                "widget_icon_color": "#ffffff",
                                                "widget_rgb_color": "255,96,96",
                                                "has_custom_css": 0,
                                                "custom_css": "",
                                                "widget_token": "14bba20ec2",
                                                "widget_index": "",
                                                "attention_effect": ""
                                            },
                                            "triggers": {
                                                "has_time_delay": 1,
                                                "time_delay": "1",
                                                "exit_intent": 1,
                                                "has_display_after_page_scroll": 0,
                                                "display_after_page_scroll": "0",
                                                "auto_hide_widget": 0,
                                                "hide_after": 0,
                                                "show_on_pages_rules": [],
                                                "time_diff": 0,
                                                "has_date_scheduling_rules": 0,
                                                "date_scheduling_rules": {
                                                    "start_date_time": "",
                                                    "end_date_time": ""
                                                },
                                                "date_scheduling_rules_timezone": 0,
                                                "day_hours_scheduling_rules_timezone": 0,
                                                "has_day_hours_scheduling_rules": [],
                                                "day_hours_scheduling_rules": [],
                                                "day_time_diff": 0,
                                                "show_on_direct_visit": 0,
                                                "show_on_referrer_social_network": 0,
                                                "show_on_referrer_search_engines": 0,
                                                "show_on_referrer_google_ads": 0,
                                                "show_on_referrer_urls": [],
                                                "has_show_on_specific_referrer_urls": 0,
                                                "has_traffic_source": 0,
                                                "has_countries": 0,
                                                "countries": [],
                                                "has_target_rules": 0
                                            },
                                            "channels": [{
                                                "channel": "Line",
                                                "value": "https:\/\/lin.ee\/sjxB7It",
                                                "hover_text": "Line",
                                                "chatway_position": "",
                                                "svg_icon": "<svg width=\"39\" height=\"39\" viewBox=\"0 0 39 39\" fill=\"none\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\"><circle class=\"color-element\" cx=\"19.4395\" cy=\"19.4395\" r=\"19.4395\" fill=\"#38B900\"><\/circle><path d=\"M24 9.36561C24 4.19474 18.6178 0 12 0C5.38215 0 0 4.19474 0 9.36561C0 13.9825 4.25629 17.8606 10.0229 18.5993C10.4073 18.6785 10.9565 18.8368 11.0664 19.1797C11.1762 19.4699 11.1487 19.9184 11.0938 20.235C11.0938 20.235 10.9565 21.0528 10.9291 21.2111C10.8741 21.5013 10.6819 22.3456 11.9725 21.8443C13.2632 21.3167 18.8924 17.9398 21.3913 15.1433C23.1487 13.2702 24 11.4234 24 9.36561Z\" transform=\"translate(7 10)\" fill=\"white\"><\/path><path d=\"M1.0984 0H0.24714C0.10984 0 -2.09503e-07 0.105528 -2.09503e-07 0.211056V5.22364C-2.09503e-07 5.35555 0.10984 5.43469 0.24714 5.43469H1.0984C1.2357 5.43469 1.34554 5.32917 1.34554 5.22364V0.211056C1.34554 0.105528 1.2357 0 1.0984 0Z\" transform=\"translate(15.4577 16.8593)\" fill=\"#38B900\" class=\"color-element\"><\/path><path d=\"M4.66819 0H3.81693C3.67963 0 3.56979 0.105528 3.56979 0.211056V3.19222L1.18078 0.0791458C1.18078 0.0791458 1.18078 0.0527642 1.15332 0.0527642C1.15332 0.0527642 1.15332 0.0527641 1.12586 0.0263821C1.12586 0.0263821 1.12586 0.0263821 1.0984 0.0263821H0.247139C0.10984 0.0263821 4.19006e-07 0.13191 4.19006e-07 0.237438V5.25002C4.19006e-07 5.38193 0.10984 5.46108 0.247139 5.46108H1.0984C1.2357 5.46108 1.34554 5.35555 1.34554 5.25002V2.26885L3.73455 5.38193C3.76201 5.40831 3.76201 5.43469 3.78947 5.43469C3.78947 5.43469 3.78947 5.43469 3.81693 5.43469C3.81693 5.43469 3.81693 5.43469 3.84439 5.43469C3.87185 5.43469 3.87185 5.43469 3.89931 5.43469H4.75057C4.88787 5.43469 4.99771 5.32917 4.99771 5.22364V0.211056C4.91533 0.105528 4.80549 0 4.66819 0Z\" transform=\"translate(17.6819 16.8593)\" fill=\"#38B900\" class=\"color-element\"><\/path><path d=\"M3.62471 4.22112H1.34554V0.237438C1.34554 0.105528 1.2357 0 1.0984 0H0.24714C0.10984 0 -5.23757e-08 0.105528 -5.23757e-08 0.237438V5.25002C-5.23757e-08 5.30278 0.0274599 5.35555 0.0549198 5.40831C0.10984 5.43469 0.16476 5.46108 0.21968 5.46108H3.56979C3.70709 5.46108 3.78947 5.35555 3.78947 5.22364V4.4058C3.87185 4.32665 3.76201 4.22112 3.62471 4.22112Z\" transform=\"translate(10.8993 16.8593)\" fill=\"#38B900\" class=\"color-element\"><\/path><path d=\"M3.56979 1.29272C3.70709 1.29272 3.78947 1.18719 3.78947 1.05528V0.237438C3.78947 0.105528 3.67963 -1.00639e-07 3.56979 -1.00639e-07H0.219679C0.164759 -1.00639e-07 0.10984 0.0263821 0.0549199 0.0527641C0.02746 0.105528 -2.09503e-07 0.158292 -2.09503e-07 0.211056V5.22364C-2.09503e-07 5.2764 0.02746 5.32917 0.0549199 5.38193C0.10984 5.40831 0.164759 5.43469 0.219679 5.43469H3.56979C3.70709 5.43469 3.78947 5.32917 3.78947 5.19726V4.37941C3.78947 4.2475 3.67963 4.14198 3.56979 4.14198H1.29062V3.29775H3.56979C3.70709 3.29775 3.78947 3.19222 3.78947 3.06031V2.24247C3.78947 2.11056 3.67963 2.00503 3.56979 2.00503H1.29062V1.16081H3.56979V1.29272Z\" transform=\"translate(23.421 16.8329)\" fill=\"#38B900\" class=\"color-element\"><\/path><\/svg>",
                                                "is_desktop": 1,
                                                "is_mobile": 1,
                                                "icon_color": "#38B900",
                                                "icon_rgb_color": "56,185,0",
                                                "channel_type": "Line",
                                                "custom_image_url": "",
                                                "order": "",
                                                "pre_set_message": "",
                                                "is_use_web_version": "1",
                                                "is_open_new_tab": "1",
                                                "is_default_open": "0",
                                                "has_welcome_message": "0",
                                                "emoji_picker": "1",
                                                "input_placeholder": "Write your message...",
                                                "chat_welcome_message": "",
                                                "wp_popup_headline": "",
                                                "wp_popup_nickname": "",
                                                "wp_popup_profile": "",
                                                "wp_popup_head_bg_color": "#4AA485",
                                                "qr_code_image_url": "",
                                                "mail_subject": "",
                                                "channel_account_type": "personal",
                                                "contact_form_settings": [],
                                                "contact_fields": [],
                                                "url": "https:\/\/lin.ee\/sjxB7It",
                                                "mobile_target": "_blank",
                                                "desktop_target": "_blank",
                                                "target": "_blank",
                                                "is_agent": 0,
                                                "agent_data": [],
                                                "header_text": "",
                                                "header_sub_text": "",
                                                "header_bg_color": "",
                                                "header_text_color": "",
                                                "widget_token": "14bba20ec2",
                                                "widget_index": "",
                                                "click_event": "",
                                                "viber_url": ""
                                            }, {
                                                "channel": "Phone",
                                                "value": "+6628215042",
                                                "hover_text": "Phone",
                                                "chatway_position": "",
                                                "svg_icon": "<svg width=\"39\" height=\"39\" viewBox=\"0 0 39 39\" fill=\"none\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\"><circle class=\"color-element\" cx=\"19.4395\" cy=\"19.4395\" r=\"19.4395\" fill=\"#03E78B\"\/><path d=\"M19.3929 14.9176C17.752 14.7684 16.2602 14.3209 14.7684 13.7242C14.0226 13.4259 13.1275 13.7242 12.8292 14.4701L11.7849 16.2602C8.65222 14.6193 6.11623 11.9341 4.47529 8.95057L6.41458 7.90634C7.16046 7.60799 7.45881 6.71293 7.16046 5.96705C6.56375 4.47529 6.11623 2.83435 5.96705 1.34259C5.96705 0.596704 5.22117 0 4.47529 0H0.745882C0.298353 0 5.69062e-07 0.298352 5.69062e-07 0.745881C5.69062e-07 3.72941 0.596704 6.71293 1.93929 9.3981C3.87858 13.575 7.30964 16.8569 11.3374 18.7962C14.0226 20.1388 17.0061 20.7355 19.9896 20.7355C20.4371 20.7355 20.7355 20.4371 20.7355 19.9896V16.4094C20.7355 15.5143 20.1388 14.9176 19.3929 14.9176Z\" transform=\"translate(9.07179 9.07178)\" fill=\"white\"\/><\/svg>",
                                                "is_desktop": 1,
                                                "is_mobile": 1,
                                                "icon_color": "#03E78B",
                                                "icon_rgb_color": "3,231,139",
                                                "channel_type": "Phone",
                                                "custom_image_url": "",
                                                "order": "",
                                                "pre_set_message": "",
                                                "is_use_web_version": "1",
                                                "is_open_new_tab": "1",
                                                "is_default_open": "0",
                                                "has_welcome_message": "0",
                                                "emoji_picker": "1",
                                                "input_placeholder": "Write your message...",
                                                "chat_welcome_message": "",
                                                "wp_popup_headline": "",
                                                "wp_popup_nickname": "",
                                                "wp_popup_profile": "",
                                                "wp_popup_head_bg_color": "#4AA485",
                                                "qr_code_image_url": "",
                                                "mail_subject": "",
                                                "channel_account_type": "personal",
                                                "contact_form_settings": [],
                                                "contact_fields": [],
                                                "url": "tel:+6628215042",
                                                "mobile_target": "",
                                                "desktop_target": "",
                                                "target": "",
                                                "is_agent": 0,
                                                "agent_data": [],
                                                "header_text": "",
                                                "header_sub_text": "",
                                                "header_bg_color": "",
                                                "header_text_color": "",
                                                "widget_token": "14bba20ec2",
                                                "widget_index": "",
                                                "click_event": "",
                                                "viber_url": ""
                                            }, {
                                                "channel": "Whatsapp",
                                                "value": "66939516639",
                                                "hover_text": "WhatsApp",
                                                "chatway_position": "",
                                                "svg_icon": "<svg width=\"39\" height=\"39\" viewBox=\"0 0 39 39\" fill=\"none\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\"><circle class=\"color-element\" cx=\"19.4395\" cy=\"19.4395\" r=\"19.4395\" fill=\"#49E670\"\/><path d=\"M12.9821 10.1115C12.7029 10.7767 11.5862 11.442 10.7486 11.575C10.1902 11.7081 9.35269 11.8411 6.84003 10.7767C3.48981 9.44628 1.39593 6.25317 1.25634 6.12012C1.11674 5.85403 2.13001e-06 4.39053 2.13001e-06 2.92702C2.13001e-06 1.46351 0.83755 0.665231 1.11673 0.399139C1.39592 0.133046 1.8147 1.01506e-06 2.23348 1.01506e-06C2.37307 1.01506e-06 2.51267 1.01506e-06 2.65226 1.01506e-06C2.93144 1.01506e-06 3.21063 -2.02219e-06 3.35022 0.532183C3.62941 1.19741 4.32736 2.66092 4.32736 2.79397C4.46696 2.92702 4.46696 3.19311 4.32736 3.32616C4.18777 3.59225 4.18777 3.59224 3.90858 3.85834C3.76899 3.99138 3.6294 4.12443 3.48981 4.39052C3.35022 4.52357 3.21063 4.78966 3.35022 5.05576C3.48981 5.32185 4.18777 6.38622 5.16491 7.18449C6.42125 8.24886 7.39839 8.51496 7.81717 8.78105C8.09636 8.91409 8.37554 8.9141 8.65472 8.648C8.93391 8.38191 9.21309 7.98277 9.49228 7.58363C9.77146 7.31754 10.0507 7.1845 10.3298 7.31754C10.609 7.45059 12.2841 8.11582 12.5633 8.38191C12.8425 8.51496 13.1217 8.648 13.1217 8.78105C13.1217 8.78105 13.1217 9.44628 12.9821 10.1115Z\" transform=\"translate(12.9597 12.9597)\" fill=\"#FAFAFA\"\/><path d=\"M0.196998 23.295L0.131434 23.4862L0.323216 23.4223L5.52771 21.6875C7.4273 22.8471 9.47325 23.4274 11.6637 23.4274C18.134 23.4274 23.4274 18.134 23.4274 11.6637C23.4274 5.19344 18.134 -0.1 11.6637 -0.1C5.19344 -0.1 -0.1 5.19344 -0.1 11.6637C-0.1 13.9996 0.624492 16.3352 1.93021 18.2398L0.196998 23.295ZM5.87658 19.8847L5.84025 19.8665L5.80154 19.8788L2.78138 20.8398L3.73978 17.9646L3.75932 17.906L3.71562 17.8623L3.43104 17.5777C2.27704 15.8437 1.55796 13.8245 1.55796 11.6637C1.55796 6.03288 6.03288 1.55796 11.6637 1.55796C17.2945 1.55796 21.7695 6.03288 21.7695 11.6637C21.7695 17.2945 17.2945 21.7695 11.6637 21.7695C9.64222 21.7695 7.76778 21.1921 6.18227 20.039L6.17557 20.0342L6.16817 20.0305L5.87658 19.8847Z\" transform=\"translate(7.7758 7.77582)\" fill=\"white\" stroke=\"white\" stroke-width=\"0.2\"\/><\/svg>",
                                                "is_desktop": 1,
                                                "is_mobile": 1,
                                                "icon_color": "#49E670",
                                                "icon_rgb_color": "73,230,112",
                                                "channel_type": "Whatsapp",
                                                "custom_image_url": "",
                                                "order": "",
                                                "pre_set_message": "",
                                                "is_use_web_version": "1",
                                                "is_open_new_tab": "1",
                                                "is_default_open": "0",
                                                "has_welcome_message": "0",
                                                "emoji_picker": "1",
                                                "input_placeholder": "Write your message...",
                                                "chat_welcome_message": "<p>How can I help you? :)<\/p>",
                                                "wp_popup_headline": "",
                                                "wp_popup_nickname": "",
                                                "wp_popup_profile": "",
                                                "wp_popup_head_bg_color": "#4AA485",
                                                "qr_code_image_url": "",
                                                "mail_subject": "",
                                                "channel_account_type": "personal",
                                                "contact_form_settings": [],
                                                "contact_fields": [],
                                                "url": "https:\/\/web.whatsapp.com\/send?phone=66939516639",
                                                "mobile_target": "",
                                                "desktop_target": "_blank",
                                                "target": "_blank",
                                                "is_agent": 0,
                                                "agent_data": [],
                                                "header_text": "",
                                                "header_sub_text": "",
                                                "header_bg_color": "",
                                                "header_text_color": "",
                                                "widget_token": "14bba20ec2",
                                                "widget_index": "",
                                                "click_event": "",
                                                "viber_url": ""
                                            }]
                                        }],
                                        "data_analytics_settings": "off",
                                        "lang": {
                                            "whatsapp_label": "WhatsApp Message",
                                            "hide_whatsapp_form": "Hide WhatsApp Form",
                                            "emoji_picker": "Show Emojis"
                                        },
                                        "has_chatway": ""
                                    };
                                    /* ]]> */
                                </script>
                                <script defer type="text/javascript" src="https://basketeer.com/wp-content/plugins/chaty/js/cht-front-script.min.js?ver=3.4.81712882197" id="chaty-front-end-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/woocommerce/assets/js/sourcebuster/sourcebuster.min.js?ver=9.5.1" id="sourcebuster-js-js"></script>
                                <script type="text/javascript" id="wc-order-attribution-js-extra">
                                    /* <![CDATA[ */
                                    var wc_order_attribution = {
                                        "params": {
                                            "lifetime": 1.0000000000000001e-5,
                                            "session": 30,
                                            "base64": false,
                                            "ajaxurl": "https:\/\/basketeer.com\/wp-admin\/admin-ajax.php",
                                            "prefix": "wc_order_attribution_",
                                            "allowTracking": true
                                        },
                                        "fields": {
                                            "source_type": "current.typ",
                                            "referrer": "current_add.rf",
                                            "utm_campaign": "current.cmp",
                                            "utm_source": "current.src",
                                            "utm_medium": "current.mdm",
                                            "utm_content": "current.cnt",
                                            "utm_id": "current.id",
                                            "utm_term": "current.trm",
                                            "utm_source_platform": "current.plt",
                                            "utm_creative_format": "current.fmt",
                                            "utm_marketing_tactic": "current.tct",
                                            "session_entry": "current_add.ep",
                                            "session_start_time": "current_add.fd",
                                            "session_pages": "session.pgs",
                                            "session_count": "udata.vst",
                                            "user_agent": "udata.uag"
                                        }
                                    };
                                    /* ]]> */
                                </script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/woocommerce/assets/js/frontend/order-attribution.min.js?ver=9.5.1" id="wc-order-attribution-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/woocommerce-products-filter/js/html_types/radio.js?ver=1.3.7.1" id="woof_radio_html_items-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/woocommerce-products-filter/js/html_types/checkbox.js?ver=1.3.7.1" id="woof_checkbox_html_items-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/woocommerce-products-filter/js/html_types/select.js?ver=1.3.7.1" id="woof_select_html_items-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/woocommerce-products-filter/js/html_types/mselect.js?ver=1.3.7.1" id="woof_mselect_html_items-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/by_author/js/by_author.js?ver=1.3.7.1" id="woof_by_author_html_items-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/by_featured/js/by_featured.js?ver=1.3.7.1" id="woof_by_featured_html_items-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/by_instock/js/by_instock.js?ver=1.3.7.1" id="woof_by_instock_html_items-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/by_onsales/js/by_onsales.js?ver=1.3.7.1" id="woof_by_onsales_html_items-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/by_text/assets/js/front.js?ver=1.3.7.1" id="woof_by_text_html_items-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/label/js/html_types/label.js?ver=1.3.7.1" id="woof_label_html_items-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/sections/js/sections.js?ver=1.3.7.1" id="woof_sections_html_items-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/select_radio_check/js/html_types/select_radio_check.js?ver=1.3.7.1" id="woof_select_radio_check_html_items-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/smart_designer/js/front.js?ver=1.3.7.1" id="woof_sd_html_items-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/woocommerce-products-filter/js/ion.range-slider/js/ion.rangeSlider.min.js?ver=1.3.7.1" id="ion.range-slider-js"></script>
                                <script type="text/javascript" id="gt_widget_script_34366255-js-before">
                                    /* <![CDATA[ */
                                    window.gtranslateSettings = /* document.write */ window.gtranslateSettings || {};
                                    window.gtranslateSettings['34366255'] = {
                                        "default_language": "en",
                                        "languages": ["en", "th"],
                                        "url_structure": "sub_directory",
                                        "flag_style": "2d",
                                        "flag_size": 24,
                                        "wrapper_selector": "#gt-wrapper-34366255",
                                        "alt_flags": [],
                                        "switcher_open_direction": "bottom",
                                        "switcher_horizontal_position": "inline",
                                        "switcher_text_color": "#666",
                                        "switcher_arrow_color": "#666",
                                        "switcher_border_color": "#ccc",
                                        "switcher_background_color": "#fff",
                                        "switcher_background_shadow_color": "#efefef",
                                        "switcher_background_hover_color": "#fff",
                                        "dropdown_text_color": "#000",
                                        "dropdown_hover_color": "#fff",
                                        "dropdown_background_color": "#eee",
                                        "flags_location": "\/wp-content\/plugins\/gtranslate\/flags\/"
                                    };
                                    /* ]]> */
                                </script>
                                <script src="https://basketeer.com/wp-content/plugins/gtranslate/js/dwf.js?ver=6.8.3" data-no-optimize="1" data-no-minify="1" data-gt-orig-url="/" data-gt-orig-domain="basketeer.com" data-gt-widget-id="34366255"
                                    defer></script>
                                <script type="text/javascript" id="jquery-dgwt-wcas-js-extra">
                                    /* <![CDATA[ */
                                    var dgwt_wcas = {
                                        "labels": {
                                            "product_plu": "Products",
                                            "vendor": "Vendor",
                                            "vendor_plu": "Vendors",
                                            "sku_label": "SKU:",
                                            "sale_badge": "Sale",
                                            "vendor_sold_by": "Sold by:",
                                            "featured_badge": "Featured",
                                            "in": "in",
                                            "read_more": "continue reading",
                                            "no_results": "\"No results found\"",
                                            "no_results_default": "No results",
                                            "show_more": "See all products...",
                                            "show_more_details": "See all products...",
                                            "search_placeholder": "Search...",
                                            "submit": "",
                                            "search_hist": "Your search history",
                                            "search_hist_clear": "Clear",
                                            "mob_overlay_label": "Open search in the mobile overlay",
                                            "post_type_post_plu": "Posts",
                                            "post_type_post": "Post",
                                            "post_type_page_plu": "Pages",
                                            "post_type_page": "Page",
                                            "tax_product_cat_plu": "Categories",
                                            "tax_product_cat": "Category",
                                            "tax_product_tag_plu": "Tags",
                                            "tax_product_tag": "Tag"
                                        },
                                        "ajax_search_endpoint": "https:\/\/basketeer.com\/wp-content\/plugins\/ajax-search-for-woocommerce-premium\/includes\/Engines\/TNTSearchMySQL\/Endpoints\/search.php",
                                        "ajax_details_endpoint": "\/?wc-ajax=dgwt_wcas_result_details",
                                        "ajax_prices_endpoint": "\/?wc-ajax=dgwt_wcas_get_prices",
                                        "action_search": "dgwt_wcas_ajax_search",
                                        "action_result_details": "dgwt_wcas_result_details",
                                        "action_get_prices": "dgwt_wcas_get_prices",
                                        "min_chars": "3",
                                        "width": "auto",
                                        "show_details_panel": "",
                                        "show_images": "1",
                                        "show_price": "1",
                                        "show_desc": "",
                                        "show_sale_badge": "",
                                        "show_featured_badge": "",
                                        "dynamic_prices": "",
                                        "is_rtl": "",
                                        "show_preloader": "",
                                        "show_headings": "1",
                                        "preloader_url": "",
                                        "taxonomy_brands": "",
                                        "img_url": "https:\/\/basketeer.com\/wp-content\/plugins\/ajax-search-for-woocommerce-premium\/assets\/img\/",
                                        "is_premium": "1",
                                        "layout_breakpoint": "1198",
                                        "mobile_overlay_breakpoint": "1198",
                                        "mobile_overlay_wrapper": "body",
                                        "mobile_overlay_delay": "0",
                                        "debounce_wait_ms": "100",
                                        "send_ga_events": "1",
                                        "enable_ga_site_search_module": "",
                                        "magnifier_icon": "\t\t\t\t<svg class=\"\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\"\n\t\t\t\t\t xmlns:xlink=\"http:\/\/www.w3.org\/1999\/xlink\" x=\"0px\" y=\"0px\"\n\t\t\t\t\t viewBox=\"0 0 51.539 51.361\" xml:space=\"preserve\">\n\t\t             <path \t\t\t\t\t\t d=\"M51.539,49.356L37.247,35.065c3.273-3.74,5.272-8.623,5.272-13.983c0-11.742-9.518-21.26-21.26-21.26 S0,9.339,0,21.082s9.518,21.26,21.26,21.26c5.361,0,10.244-1.999,13.983-5.272l14.292,14.292L51.539,49.356z M2.835,21.082 c0-10.176,8.249-18.425,18.425-18.425s18.425,8.249,18.425,18.425S31.436,39.507,21.26,39.507S2.835,31.258,2.835,21.082z\"\/>\n\t\t\t\t<\/svg>\n\t\t\t\t",
                                        "magnifier_icon_pirx": "\t\t\t\t<svg class=\"\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\" width=\"18\" height=\"18\" viewBox=\"0 0 18 18\">\n\t\t\t\t\t<path  d=\" M 16.722523,17.901412 C 16.572585,17.825208 15.36088,16.670476 14.029846,15.33534 L 11.609782,12.907819 11.01926,13.29667 C 8.7613237,14.783493 5.6172703,14.768302 3.332423,13.259528 -0.07366363,11.010358 -1.0146502,6.5989684 1.1898146,3.2148776\n\t\t\t\t\t\t  1.5505179,2.6611594 2.4056498,1.7447266 2.9644271,1.3130497 3.4423015,0.94387379 4.3921825,0.48568469 5.1732652,0.2475835 5.886299,0.03022609 6.1341883,0 7.2037391,0 8.2732897,0 8.521179,0.03022609 9.234213,0.2475835 c 0.781083,0.23810119 1.730962,0.69629029 2.208837,1.0654662\n\t\t\t\t\t\t  0.532501,0.4113763 1.39922,1.3400096 1.760153,1.8858877 1.520655,2.2998531 1.599025,5.3023778 0.199549,7.6451086 -0.208076,0.348322 -0.393306,0.668209 -0.411622,0.710863 -0.01831,0.04265 1.065556,1.18264 2.408603,2.533307 1.343046,1.350666 2.486621,2.574792 2.541278,2.720279 0.282475,0.7519\n\t\t\t\t\t\t  -0.503089,1.456506 -1.218488,1.092917 z M 8.4027892,12.475062 C 9.434946,12.25579 10.131043,11.855461 10.99416,10.984753 11.554519,10.419467 11.842507,10.042366 12.062078,9.5863882 12.794223,8.0659672 12.793657,6.2652398 12.060578,4.756293 11.680383,3.9737304 10.453587,2.7178427\n\t\t\t\t\t\t  9.730569,2.3710306 8.6921295,1.8729196 8.3992147,1.807606 7.2037567,1.807606 6.0082984,1.807606 5.7153841,1.87292 4.6769446,2.3710306 3.9539263,2.7178427 2.7271301,3.9737304 2.3469352,4.756293 1.6138384,6.2652398 1.6132726,8.0659672 2.3454252,9.5863882 c 0.4167354,0.8654208 1.5978784,2.0575608\n\t\t\t\t\t\t  2.4443766,2.4671358 1.0971012,0.530827 2.3890403,0.681561 3.6130134,0.421538 z\n\t\t\t\t\t\"\/>\n\t\t\t\t<\/svg>\n\t\t\t\t",
                                        "history_icon": "\t\t\t\t<svg class=\"\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\" width=\"18\" height=\"16\">\n\t\t\t\t\t<g transform=\"translate(-17.498822,-36.972165)\">\n\t\t\t\t\t\t<path \t\t\t\t\t\t\td=\"m 26.596964,52.884295 c -0.954693,-0.11124 -2.056421,-0.464654 -2.888623,-0.926617 -0.816472,-0.45323 -1.309173,-0.860824 -1.384955,-1.145723 -0.106631,-0.400877 0.05237,-0.801458 0.401139,-1.010595 0.167198,-0.10026 0.232609,-0.118358 0.427772,-0.118358 0.283376,0 0.386032,0.04186 0.756111,0.308336 1.435559,1.033665 3.156285,1.398904 4.891415,1.038245 2.120335,-0.440728 3.927688,-2.053646 4.610313,-4.114337 0.244166,-0.737081 0.291537,-1.051873 0.293192,-1.948355 0.0013,-0.695797 -0.0093,-0.85228 -0.0806,-1.189552 -0.401426,-1.899416 -1.657702,-3.528366 -3.392535,-4.398932 -2.139097,-1.073431 -4.69701,-0.79194 -6.613131,0.727757 -0.337839,0.267945 -0.920833,0.890857 -1.191956,1.27357 -0.66875,0.944 -1.120577,2.298213 -1.120577,3.35859 v 0.210358 h 0.850434 c 0.82511,0 0.854119,0.0025 0.974178,0.08313 0.163025,0.109516 0.246992,0.333888 0.182877,0.488676 -0.02455,0.05927 -0.62148,0.693577 -1.32651,1.40957 -1.365272,1.3865 -1.427414,1.436994 -1.679504,1.364696 -0.151455,-0.04344 -2.737016,-2.624291 -2.790043,-2.784964 -0.05425,-0.16438 0.02425,-0.373373 0.179483,-0.477834 0.120095,-0.08082 0.148717,-0.08327 0.970779,-0.08327 h 0.847035 l 0.02338,-0.355074 c 0.07924,-1.203664 0.325558,-2.153721 0.819083,-3.159247 1.083047,-2.206642 3.117598,-3.79655 5.501043,-4.298811 0.795412,-0.167616 1.880855,-0.211313 2.672211,-0.107576 3.334659,0.437136 6.147035,3.06081 6.811793,6.354741 0.601713,2.981541 -0.541694,6.025743 -2.967431,7.900475 -1.127277,0.871217 -2.441309,1.407501 -3.893104,1.588856 -0.447309,0.05588 -1.452718,0.06242 -1.883268,0.01225 z m 3.375015,-5.084703 c -0.08608,-0.03206 -2.882291,-1.690237 -3.007703,-1.783586 -0.06187,-0.04605 -0.160194,-0.169835 -0.218507,-0.275078 L 26.639746,45.549577 V 43.70452 41.859464 L 26.749,41.705307 c 0.138408,-0.195294 0.31306,-0.289155 0.538046,-0.289155 0.231638,0 0.438499,0.109551 0.563553,0.298452 l 0.10019,0.151342 0.01053,1.610898 0.01053,1.610898 0.262607,0.154478 c 1.579961,0.929408 2.399444,1.432947 2.462496,1.513106 0.253582,0.322376 0.140877,0.816382 -0.226867,0.994404 -0.148379,0.07183 -0.377546,0.09477 -0.498098,0.04986 z\"\/>\n\t\t\t\t\t<\/g>\n\t\t\t\t<\/svg>\n\t\t\t\t",
                                        "close_icon": "\t\t\t\t<svg class=\"\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\" height=\"24\" viewBox=\"0 0 24 24\"\n\t\t\t\t\t width=\"24\">\n\t\t\t\t\t<path \t\t\t\t\t\td=\"M18.3 5.71c-.39-.39-1.02-.39-1.41 0L12 10.59 7.11 5.7c-.39-.39-1.02-.39-1.41 0-.39.39-.39 1.02 0 1.41L10.59 12 5.7 16.89c-.39.39-.39 1.02 0 1.41.39.39 1.02.39 1.41 0L12 13.41l4.89 4.89c.39.39 1.02.39 1.41 0 .39-.39.39-1.02 0-1.41L13.41 12l4.89-4.89c.38-.38.38-1.02 0-1.4z\"\/>\n\t\t\t\t<\/svg>\n\t\t\t\t",
                                        "back_icon": "\t\t\t\t<svg class=\"\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\" viewBox=\"0 0 16 16\">\n\t\t\t\t\t<path \t\t\t\t\t\td=\"M14 6.125H3.351l4.891-4.891L7 0 0 7l7 7 1.234-1.234L3.35 7.875H14z\" fill-rule=\"evenodd\"\/>\n\t\t\t\t<\/svg>\n\t\t\t\t",
                                        "preloader_icon": "\t\t\t\t<svg class=\"dgwt-wcas-loader-circular \" viewBox=\"25 25 50 50\">\n\t\t\t\t\t<circle class=\"dgwt-wcas-loader-circular-path\" cx=\"50\" cy=\"50\" r=\"20\" fill=\"none\"\n\t\t\t\t\t\t stroke-miterlimit=\"10\"\/>\n\t\t\t\t<\/svg>\n\t\t\t\t",
                                        "voice_search_inactive_icon": "\t\t\t\t<svg class=\"dgwt-wcas-voice-search-mic-inactive\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\" height=\"24\" width=\"24\">\n\t\t\t\t\t<path \t\t\t\t\t\td=\"M12 14q-1.25 0-2.125-.875T9 11V5q0-1.25.875-2.125T12 2q1.25 0 2.125.875T15 5v6q0 1.25-.875 2.125T12 14Zm0-6Zm-1 13v-3.075q-2.6-.35-4.3-2.325Q5 13.625 5 11h2q0 2.075 1.463 3.537Q9.925 16 12 16t3.538-1.463Q17 13.075 17 11h2q0 2.625-1.7 4.6-1.7 1.975-4.3 2.325V21Zm1-9q.425 0 .713-.288Q13 11.425 13 11V5q0-.425-.287-.713Q12.425 4 12 4t-.712.287Q11 4.575 11 5v6q0 .425.288.712.287.288.712.288Z\"\/>\n\t\t\t\t<\/svg>\n\t\t\t\t",
                                        "voice_search_active_icon": "\t\t\t\t<svg class=\"dgwt-wcas-voice-search-mic-active\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\" height=\"24\"\n\t\t\t\t\t width=\"24\">\n\t\t\t\t\t<path \t\t\t\t\t\td=\"M12 14q-1.25 0-2.125-.875T9 11V5q0-1.25.875-2.125T12 2q1.25 0 2.125.875T15 5v6q0 1.25-.875 2.125T12 14Zm-1 7v-3.075q-2.6-.35-4.3-2.325Q5 13.625 5 11h2q0 2.075 1.463 3.537Q9.925 16 12 16t3.538-1.463Q17 13.075 17 11h2q0 2.625-1.7 4.6-1.7 1.975-4.3 2.325V21Z\"\/>\n\t\t\t\t<\/svg>\n\t\t\t\t",
                                        "voice_search_disabled_icon": "\t\t\t\t<svg class=\"dgwt-wcas-voice-search-mic-disabled\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\" height=\"24\" width=\"24\">\n\t\t\t\t\t<path \t\t\t\t\t\td=\"M17.75 14.95 16.3 13.5q.35-.575.525-1.2Q17 11.675 17 11h2q0 1.1-.325 2.087-.325.988-.925 1.863Zm-2.95-3L9 6.15V5q0-1.25.875-2.125T12 2q1.25 0 2.125.875T15 5v6q0 .275-.062.5-.063.225-.138.45ZM11 21v-3.1q-2.6-.35-4.3-2.312Q5 13.625 5 11h2q0 2.075 1.463 3.537Q9.925 16 12 16q.85 0 1.613-.262.762-.263 1.387-.738l1.425 1.425q-.725.575-1.587.962-.863.388-1.838.513V21Zm8.8 1.6L1.4 4.2l1.4-1.4 18.4 18.4Z\"\/>\n\t\t\t\t<\/svg>\n\t\t\t\t",
                                        "custom_params": {},
                                        "convert_html": "1",
                                        "suggestions_wrapper": "body",
                                        "show_product_vendor": "",
                                        "disable_hits": "",
                                        "disable_submit": "",
                                        "fixer": {
                                            "broken_search_ui": true,
                                            "broken_search_ui_ajax": true,
                                            "broken_search_ui_hard": false,
                                            "broken_search_elementor_popups": true,
                                            "broken_search_jet_mobile_menu": true,
                                            "broken_search_browsers_back_arrow": true,
                                            "force_refresh_checkout": true
                                        },
                                        "voice_search_enabled": "",
                                        "voice_search_lang": "en-US",
                                        "show_recently_searched_products": "",
                                        "show_recently_searched_phrases": "",
                                        "go_to_first_variation_on_submit": "1"
                                    };
                                    /* ]]> */
                                </script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/ajax-search-for-woocommerce-premium/assets/js/search.min.js?ver=1.31.0" id="jquery-dgwt-wcas-js"></script>
                                <script type="text/javascript" id="gt_widget_script_88349573-js-before">
                                    /* <![CDATA[ */
                                    window.gtranslateSettings = /* document.write */ window.gtranslateSettings || {};
                                    window.gtranslateSettings['88349573'] = {
                                        "default_language": "en",
                                        "languages": ["en", "th"],
                                        "url_structure": "sub_directory",
                                        "flag_style": "2d",
                                        "flag_size": 24,
                                        "wrapper_selector": "#gt-wrapper-88349573",
                                        "alt_flags": [],
                                        "switcher_open_direction": "bottom",
                                        "switcher_horizontal_position": "inline",
                                        "switcher_text_color": "#666",
                                        "switcher_arrow_color": "#666",
                                        "switcher_border_color": "#ccc",
                                        "switcher_background_color": "#fff",
                                        "switcher_background_shadow_color": "#efefef",
                                        "switcher_background_hover_color": "#fff",
                                        "dropdown_text_color": "#000",
                                        "dropdown_hover_color": "#fff",
                                        "dropdown_background_color": "#eee",
                                        "flags_location": "\/wp-content\/plugins\/gtranslate\/flags\/"
                                    };
                                    /* ]]> */
                                </script>
                                <script src="https://basketeer.com/wp-content/plugins/gtranslate/js/dwf.js?ver=6.8.3" data-no-optimize="1" data-no-minify="1" data-gt-orig-url="/" data-gt-orig-domain="basketeer.com" data-gt-widget-id="88349573"
                                    defer></script>
                                <script type="text/javascript" src="https://cdn.trustindex.io/loader.js" id="trustindex-loader-js-js" async="async" data-wp-strategy="async"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/slideout/js/jquery.tabSlideOut.js?ver=1.3.7.1" id="woof-slideout-js-js"></script>
                                <script type="text/javascript" src="https://basketeer.com/wp-content/plugins/woocommerce-products-filter/ext/slideout/js/slideout.js?ver=1.3.7.1" id="woof-slideout-init-js"></script>
                                <!-- WooCommerce JavaScript -->
                                <script type="text/javascript">
                                    jQuery(function($) {
                                        (function() {

                                            function trackEvents() {

                                                ga('send', 'pageview');

                                                ga('send', {
                                                    "hitType": "event",
                                                    "eventCategory": "Homepage",
                                                    "eventAction": "viewed homepage",
                                                    "eventLabel": null,
                                                    "eventValue": null,
                                                    "nonInteraction": true
                                                });
                                            }

                                            if ('undefined' !== typeof ga) {
                                                trackEvents();
                                            } else {
                                                // avoid using jQuery in case it's not available when this script is loaded
                                                document.addEventListener('wc_google_analytics_pro_loaded', trackEvents);
                                            }

                                        })();

                                    });
                                </script>
</body>

</html>

<!-- plugin=object-cache-pro client=phpredis metric#hits=59672 metric#misses=369 metric#hit-ratio=99.4 metric#bytes=18012116 metric#prefetches=5249 metric#store-reads=629 metric#store-writes=9 metric#store-hits=5779 metric#store-misses=359 metric#sql-queries=31 metric#ms-total=891.53 metric#ms-cache=103.91 metric#ms-cache-avg=0.1631 metric#ms-cache-ratio=11.7 -->