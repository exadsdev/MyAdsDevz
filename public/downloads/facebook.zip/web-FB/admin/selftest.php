<?php
// UTF-8 (NO BOM)
declare(strict_types=1);
ini_set('display_errors','1'); ini_set('display_startup_errors','1'); error_reporting(E_ALL);
header('Content-Type: text/plain; charset=UTF-8');
echo "SELFTEST => PHP executed\n";
echo "PHP_VERSION: ".PHP_VERSION."\n";
echo "SAPI       : ".PHP_SAPI."\n";
echo "php.ini    : ".(php_ini_loaded_file() ?: '-')."\n";
echo "doc_root   : ".($_SERVER['DOCUMENT_ROOT'] ?? '-')."\n";
echo "request_uri: ".($_SERVER['REQUEST_URI'] ?? '-')."\n";
