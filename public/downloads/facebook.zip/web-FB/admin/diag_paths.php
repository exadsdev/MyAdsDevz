<?php
// UTF-8 (NO BOM)
require __DIR__ . '/helpers.php';
$c = cfg();
$d = read_db();

$uploadUrl = $c['upload_url'];
$uploadDir = $c['upload_dir'];
$jsonPath  = $c['json_path'];

$first = $d['items'][0]['filename'] ?? null;

header('Content-Type: text/plain; charset=UTF-8');
echo "FULL_BASE : " . ($c['full_base'] ?? '-') . PHP_EOL;
echo "UPLOAD_URL: " . $uploadUrl . PHP_EOL;
echo "UPLOAD_DIR: " . $uploadDir . PHP_EOL;
echo "JSON_PATH : " . $jsonPath . PHP_EOL;
echo "Has JSON? : " . (file_exists($jsonPath) ? "YES" : "NO") . PHP_EOL;
echo "Has UPDIR?: " . (is_dir($uploadDir) ? "YES" : "NO") . PHP_EOL;

if ($first) {
  $fs = $uploadDir . DIRECTORY_SEPARATOR . $first;
  $url= rtrim($uploadUrl,'/') . '/' . $first;
  echo "First file : " . $first . PHP_EOL;
  echo "FS exists? : " . (file_exists($fs) ? "YES" : "NO") . PHP_EOL;
  echo "FS path    : " . $fs . PHP_EOL;
  echo "URL check  : " . $url . PHP_EOL;
} else {
  echo "No items in images.json" . PHP_EOL;
}
