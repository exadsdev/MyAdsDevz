<?php
// UTF-8 (NO BOM)
declare(strict_types=1);

function cfg(): array {
  static $c;
  if (!$c) $c = require __DIR__ . '/config.php';
  return $c;
}

function ensure_paths(): void {
  $c = cfg();
  $dataDir = dirname($c['json_path']);
  if (!is_dir($dataDir)) @mkdir($dataDir, 0775, true);
  if (!file_exists($c['json_path'])) {
    @file_put_contents($c['json_path'], json_encode([
      'items' => [],
      'global_link' => '',
      'buttons' => [],
      'background' => null,
      'facebook_pixel_id' => '',
      'metrics' => [
        'totals' => ['visits' => 0, 'clicks' => 0],
        'visits' => [],
        'clicks' => [],
      ],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
  }
  if (!is_dir($c['upload_dir'])) @mkdir($c['upload_dir'], 0775, true);
  if (!is_dir(dirname($c['log_path']))) @mkdir(dirname($c['log_path']), 0775, true);
  if (!file_exists($c['log_path'])) @file_put_contents($c['log_path'], '');
}

function log_line(string $msg): void {
  $c = cfg();
  @file_put_contents($c['log_path'], '['.date('Y-m-d H:i:s').'] '.$msg.PHP_EOL, FILE_APPEND);
}

function read_db(): array {
  $c = cfg();
  ensure_paths();
  $raw = @file_get_contents($c['json_path']);
  $data = json_decode($raw, true);
  if (!is_array($data)) $data = [];
  $data['items'] = isset($data['items']) && is_array($data['items']) ? $data['items'] : [];
  $data['global_link'] = $data['global_link'] ?? '';
  $data['buttons'] = isset($data['buttons']) && is_array($data['buttons']) ? $data['buttons'] : [];
  if (count($data['buttons']) > 2) $data['buttons'] = array_slice($data['buttons'], 0, 2);
  $data['background'] = $data['background'] ?? null;
  $data['facebook_pixel_id'] = $data['facebook_pixel_id'] ?? '';
  if (!isset($data['metrics']) || !is_array($data['metrics'])) {
    $data['metrics'] = ['totals'=>['visits'=>0,'clicks'=>0],'visits'=>[],'clicks'=>[]];
  } else {
    $data['metrics']['totals'] = $data['metrics']['totals'] ?? ['visits'=>0,'clicks'=>0];
    $data['metrics']['visits'] = isset($data['metrics']['visits']) && is_array($data['metrics']['visits']) ? $data['metrics']['visits'] : [];
    $data['metrics']['clicks'] = isset($data['metrics']['clicks']) && is_array($data['metrics']['clicks']) ? $data['metrics']['clicks'] : [];
  }
  return $data;
}

function write_db(array $data): void {
  $c = cfg();
  ensure_paths();
  $fp = fopen($c['json_path'], 'c+');
  if (!$fp) throw new Exception('Cannot open JSON file');
  if (!flock($fp, LOCK_EX)) { fclose($fp); throw new Exception('Cannot lock JSON'); }
  ftruncate($fp, 0);
  fwrite($fp, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
  fflush($fp);
  flock($fp, LOCK_UN);
  fclose($fp);
}

function uuidv4(): string {
  $d = random_bytes(16);
  $d[6] = chr((ord($d[6]) & 0x0f) | 0x40);
  $d[8] = chr((ord($d[8]) & 0x3f) | 0x80);
  return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($d), 4));
}

function sanitize_text(?string $s, int $max=1000): string {
  return mb_substr(trim($s ?? ''), 0, $max);
}

function require_login(): void {
  session_start();
  if (($_SESSION['logged_in'] ?? false) !== true) {
    header('Location: login.php'); exit;
  }
}

function detect_mime(string $tmp): ?string {
  if (function_exists('finfo_open')) {
    $fi = @finfo_open(FILEINFO_MIME_TYPE);
    if ($fi) {
      $m = @finfo_file($fi, $tmp);
      @finfo_close($fi);
      if ($m) return $m;
    }
  }
  $gi = @getimagesize($tmp);
  if ($gi && isset($gi['mime'])) return $gi['mime'];
  return null;
}

function is_image_mime_allowed(string $mime): bool { return isset(cfg()['allowed_mimes'][$mime]); }
function ext_for_mime(string $mime): ?string { return cfg()['allowed_mimes'][$mime] ?? null; }

function safe_move_uploaded_file(string $src, string $dst): bool {
  if (@move_uploaded_file($src, $dst)) return true;
  return @copy($src, $dst);
}

/** โซนเวลาหน้า Admin */
function display_timezone(): DateTimeZone {
  $tz = cfg()['display_timezone'] ?? 'Asia/Bangkok';
  try { return new DateTimeZone($tz); } catch (\Throwable $e) { return new DateTimeZone('Asia/Bangkok'); }
}
function format_local_time(?int $ts): string {
  if (!$ts) return '';
  $dt = new DateTime('@'.$ts);
  $dt->setTimezone(display_timezone());
  return $dt->format('Y-m-d H:i:s');
}

/** ✅ สำคัญ: IP ผู้ใช้ (ต้องมีใช้ใน /api/*.php) */
function client_ip(): string {
  $keys = ['HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'];
  foreach ($keys as $k) {
    $v = $_SERVER[$k] ?? '';
    if ($v) {
      $ip = trim(explode(',', $v)[0]);
      if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
    }
  }
  return '0.0.0.0';
}
