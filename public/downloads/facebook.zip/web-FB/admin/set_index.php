<?php
// UTF-8 (NO BOM)
require __DIR__ . '/helpers.php';
require_login();

try {
  if (!isset($_POST['active_index'])) {
    header('Location: ./index.php?err=' . urlencode('ไม่มีข้อมูล active_index'));
    exit;
  }
  $val = $_POST['active_index'] === '2' ? '2' : '1';

  $data = read_db();
  $data['active_index'] = $val;

  // กันกรณียังไม่มีคีย์อื่น ๆ
  if (!isset($data['metrics'])) $data['metrics'] = ['totals'=>['visits'=>0,'clicks'=>0]];
  if (!isset($data['items']))   $data['items']   = [];
  if (!isset($data['buttons'])) $data['buttons'] = [];

  write_db($data);

  header('Location: ./index.php?ok=1');
  exit;
} catch (Throwable $e) {
  header('Location: ./index.php?err=' . urlencode($e->getMessage()));
  exit;
}
