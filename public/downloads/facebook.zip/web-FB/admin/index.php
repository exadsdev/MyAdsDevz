<?php
// UTF-8 (NO BOM)
require __DIR__ . '/helpers.php';
require_login();
$c = cfg();
$data = read_db();

$link    = $data['global_link'] ?? '';
$buttons = $data['buttons'] ?? [];
$bg      = $data['background'] ?? null;
$pixel   = $data['facebook_pixel_id'] ?? '';

$items = $data['items'] ?? [];
usort($items, fn($a,$b)=>strcmp($b['created_at'] ?? '', $a['created_at'] ?? ''));

// Metrics
$mt     = $data['metrics']['totals'] ?? ['visits'=>0,'clicks'=>0];
$visits = array_reverse($data['metrics']['visits'] ?? []); // ใหม่ก่อน
$clicks = array_reverse($data['metrics']['clicks'] ?? []);
$recentLimit = 20;

// Active Index (default = "1")
$activeIndex = ($data['active_index'] ?? '1') === '2' ? '2' : '1';

// Labels
$btn1_label_val = $buttons[0]['label'] ?? '>> สมัครสมาชิก <<';
$btn1_url_val   = $buttons[0]['url']   ?? '';
$btn2_label_val = $buttons[1]['label'] ?? '>> ติดต่อAdmin <<';
$btn2_url_val   = $buttons[1]['url']   ?? '';
?>
<!doctype html>
<html lang="th">
<head>
  <meta charset="utf-8">
  <title>Sell Page Admin — Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="./admin.css" rel="stylesheet">
  <style>
    .btn-xs{padding:.15rem .4rem;font-size:.75rem;line-height:1;border-radius:.2rem}
    .upload-box{border:2px dashed #bbb;border-radius:12px;padding:28px;text-align:center;color:#666}
    .upload-box.dragover{border-color:#0d6efd;color:#0d6efd;background:#eef5ff}
    .upload-box input[type=file]{display:none}
    .upload-box label{display:flex;gap:.6rem;flex-direction:column;align-items:center;justify-content:center;cursor:pointer}
    .upload-box svg{width:42px;height:42px;opacity:.75}
    .preview-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
    @media(min-width:992px){.preview-grid{grid-template-columns:repeat(3,minmax(0,1fr))}}
    .pitem{border:1px solid #eee;border-radius:10px;overflow:hidden;position:relative;background:#fff}
    .pimg{display:block;width:100%;height:220px;object-fit:cover}
    .edit-fab{position:absolute;right:10px;top:10px;background:#0d6efd;color:#fff;border-radius:999px;padding:.35rem .5rem;font-size:.85rem;cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,.2)}
    .bgbox{position:relative;border:1px solid #eee;border-radius:10px;overflow:hidden}
    .bgbox img{width:100%;height:auto;display:block}
    .bg-fab{position:absolute;right:10px;top:10px}
  </style>
</head>
<body>
<nav class="navbar navbar-dark bg-dark">
  <div class="container-fluid">
    <span class="navbar-brand">Sell Page Admin</span>
 
    <div class="d-flex gap-2">

       <span class="navbar-brand"> <?php echo $activeIndex==='2'?'หน้า ขาว เปิดอยู่':'หน้า เทา เปิดอยู่'; ?></span>

        <form action="set_index_toggle.php" method="post" class="mb-0">
          <button class="btn btn-primary btn-lg">
           <?php echo $activeIndex==='2'?'ขาวเปิดอยู่':'เทาเปิดอยู่'; ?>
          </button>
        </form>

      <a href="../" target="_blank" class="btn btn-outline-light btn-sm">ดูหน้าหลัก</a>
      <a href="logout.php" class="btn btn-outline-light btn-sm">ออกจากระบบ</a>
    </div>
  </div>
</nav>

<div class="container-fluid py-4">

  <?php if (isset($_GET['ok']) && $_GET['ok'] === '1'): ?>
    <div class="alert alert-success">บันทึกสำเร็จ — ตอนนี้ใช้ <strong><?php echo (($_GET['active'] ?? $activeIndex) === '2') ? 'Index 2' : 'Index 1'; ?></strong></div>
  <?php endif; ?>
  <?php if (isset($_GET['err']) && $_GET['err'] !== ''): ?>
    <div class="alert alert-danger">เกิดข้อผิดพลาด: <?php echo htmlspecialchars($_GET['err']); ?></div>
  <?php endif; ?>

  <!-- SUMMARY (บนสุด) -->
  <div class="row g-4 mb-2">
    <div class="col-lg-6">
      <div class="card stat-card shadow-sm h-100">
        <div class="card-body d-flex align-items-center justify-content-between">
          <div>
            <div class="text-muted small">จำนวนผู้เข้าชมหน้าเว็บ</div>
            <div class="display-6 mb-0"><?php echo (int)($mt['visits'] ?? 0); ?></div>
          </div>
          <a href="#visits-list" class="btn btn-primary btn-sm">ดูรายการ IP ผู้เข้าชม</a>
        </div>
      </div>
    </div>
    <div class="col-lg-6">
      <div class="card stat-card shadow-sm h-100">
        <div class="card-body d-flex align-items-center justify-content-between">
          <div>
            <div class="text-muted small">จำนวนคนที่คลิกลิงก์/รูป</div>
            <div class="display-6 mb-0"><?php echo (int)($mt['clicks'] ?? 0); ?></div>
          </div>
          <a href="#clicks-list" class="btn btn-success btn-sm">ดูรายการ IP ที่คลิก</a>
        </div>
      </div>
    </div>
  </div>

   </div> <!-- ปิด SUMMARY -->

  <!-- ปุ่มล้าง metrics ทั้งหมด -->
  <div class="mb-4">
    <form action="clear_metrics.php" method="post"
          onsubmit="return confirm('ยืนยันลบข้อมูลสถิติ IP ทั้งหมด (ผู้เข้าชม + คลิก) ?');">
      <button class="btn btn-outline-danger">
        ลบข้อมูล IP ทั้งหมด (ผู้เข้าชม + คลิก)
      </button>
    </form>
  </div>

  <!-- ปุ่มเดียวสำหรับสลับหน้าแรก -->
  <div class="mb-4">
    ...


  <div class="row g-4">

    <!-- ซ้าย: อัปโหลดรูป + กริดรูป -->
    <section class="col-lg-4">
      <div class="card shadow-sm h-100">
        <div class="card-header bg-primary text-white"><strong>รูปภาพสินค้า/โปรโมชัน</strong></div>
        <div class="card-body">

          <form id="uploadForm" method="post" enctype="multipart/form-data" action="upload.php" class="mb-4">
            <div class="upload-box" id="dropZone">
              <input type="file" id="imageInput" name="image" accept="image/*" required>
              <label for="imageInput">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                </svg>
                คลิกเพื่อเลือก หรือ ลากรูปมาวางที่นี่
              </label>
            </div>
            <div class="d-grid mt-3">
              <button class="btn btn-success btn-lg">อัปโหลด</button>
            </div>
          </form>

          <div class="preview-grid">
            <?php foreach ($items as $it): $imgId = htmlspecialchars($it['id']); ?>
              <div class="pitem">
                <form method="post" action="update.php" enctype="multipart/form-data" class="pitem-form" id="f-<?php echo $imgId; ?>">
                  <input type="hidden" name="id" value="<?php echo $imgId; ?>">
                  <img class="pimg" src="../uploads/<?php echo htmlspecialchars($it['filename']); ?>" alt="">
                  <label class="edit-fab" for="file-<?php echo $imgId; ?>" title="แทนที่รูป">✎</label>
                  <input type="file" id="file-<?php echo $imgId; ?>" name="replace" accept="image/*" class="d-none"
                         onchange="document.getElementById('f-<?php echo $imgId; ?>').submit()">
                  <div class="mt-2 d-flex gap-2">
                    <a class="btn btn-outline-danger btn-sm flex-fill"
                       href="delete.php?id=<?php echo urlencode($it['id']); ?>"
                       onclick="return confirm('ลบรูปนี้?')">ลบ</a>
                  </div>
                </form>
              </div>
            <?php endforeach; ?>
            <?php if (!count($items)): ?>
              <div class="text-muted">ยังไม่มีรูป — อัปโหลดด้านบน</div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </section>

    <!-- กลาง: Background -->
    <section class="col-lg-4">
      <div class="card shadow-sm h-100">
        <div class="card-header bg-warning"><strong>Background</strong></div>
        <div class="card-body">
          <form method="post" enctype="multipart/form-data" action="upload_bg.php" class="row g-2 mb-3">
            <div class="col-md-8"><input type="file" name="bg" accept="image/*" required class="form-control"></div>
            <div class="col-md-4 d-grid"><button class="btn btn-success">อัปโหลดพื้นหลัง</button></div>
          </form>

          <?php if ($bg && !empty($bg['filename'])): ?>
            <form method="post" action="upload_bg.php" enctype="multipart/form-data" id="form-bg">
              <div class="bgbox">
                <img src="../uploads/<?php echo htmlspecialchars($bg['filename']); ?>" alt="">
                <label class="edit-fab bg-fab" for="file-bg" title="แทนที่พื้นหลัง">✎</label>
              </div>
              <input type="file" id="file-bg" name="bg" accept="image/*" class="d-none"
                     onchange="document.getElementById('form-bg').submit()">
            </form>
            <div class="mt-2 d-flex">
              <a class="btn btn-outline-danger btn-sm" href="delete_bg.php" onclick="return confirm('เอาพื้นหลังออก?')">ลบพื้นหลัง</a>
            </div>
          <?php else: ?>
            <div class="text-muted">ยังไม่ตั้งค่าพื้นหลัง</div>
          <?php endif; ?>
        </div>
      </div>
    </section>

    <!-- ขวา: ลิงก์ + Pixel -->
    <section class="col-lg-4">
      <div class="card shadow-sm h-100">
        <div class="card-header bg-success text-white"><strong>ลิงก์ & Facebook Pixel</strong></div>
        <div class="card-body">
          <form action="update_link.php" method="post" class="row g-3">
            <div class="col-12">
              <label class="form-label">1. ลิงก์ รูปทั้งหมด </label>
              <input type="url" name="global_link" class="form-control" placeholder="https://example.com" value="<?php echo htmlspecialchars($link); ?>">
            </div>
            <hr>
            <div class="col-12">
              <label class="form-label">ตั้งปุ่มชื่อได้</label>
              <div class="row g-2">
                <div class="col-sm-5">
                  <input type="text" name="btn1_label" class="form-control" placeholder=">> สมัครสมาชิก <<" value="<?php echo htmlspecialchars($btn1_label_val); ?>">
                </div>
                <div class="col-sm-7">
                  <input type="url" name="btn1_url" class="form-control" placeholder="https://your-website.com" value="<?php echo htmlspecialchars($btn1_url_val); ?>">
                </div>
              </div>
              <div class="form-text"> >> สมัครสมาชิก << </div>
            </div>
            <hr>
            <div class="col-12">
              <label class="form-label">ตั้งปุ่มชื่อได้ </label>
              <div class="row g-2">
                <div class="col-sm-5">
                  <input type="text" name="btn2_label" class="form-control" placeholder="ชื่อปุ่ม (เช่น Add LINE ติดต่อ Admin)" value="<?php echo htmlspecialchars($btn2_label_val); ?>">
                </div>
                <div class="col-sm-7">
                  <input type="url" name="btn2_url" class="form-control" placeholder="https://line.me/ti/p/xxxxxxxx" value="<?php echo htmlspecialchars($btn2_url_val); ?>">
                </div>
              </div>
              <div class="form-text"> >> ติดต่อAdmin << </div>
            </div>
            <hr>
            <div class="col-12">
              <label class="form-label">Facebook Pixel ID</label>
              <input type="text" name="facebook_pixel_id" class="form-control" placeholder="เช่น 123456789012345" value="<?php echo htmlspecialchars($pixel); ?>">
              <div class="form-text">ใส่เฉพาะเลขไอดี ไม่ต้องวางโค้ดเต็ม</div>
            </div>
            <div class="col-12 d-grid">
              <button class="btn btn-primary">บันทึกการตั้งค่า</button>
            </div>
          </form>
        </div>
      </div>
    </section>

    <!-- สถิติ -->
    <section class="col-12">
      <div class="card shadow-sm">
        <div class="card-header bg-light">
          <strong>สถิติ</strong> — ผู้เข้ามาหน้าเว็บ / คนที่คลิกปุ่มหรือรูป
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-lg-6" id="visits-list">
              <h6 class="d-flex align-items-center gap-2">
                รายการผู้เข้าชมล่าสุด
                <a href="#top" class="btn btn-outline-secondary btn-xs ms-auto">↑ กลับขึ้นบน</a>
              </h6>
              <div class="table-responsive">
                <table class="table table-sm table-striped mb-4">
                  <thead>
                    <tr>
                      <th style="width:72px;">ลำดับ</th>
                      <th>วันเวลา (<?php echo htmlspecialchars(cfg()['display_timezone'] ?? 'Asia/Bangkok'); ?>)</th>
                      <th>IP</th>
                      <th>แหล่งที่มา</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                      $rows = array_slice($visits, 0, $recentLimit);
                      if (!count($rows)):
                    ?>
                      <tr><td colspan="4" class="text-muted">ยังไม่มีข้อมูล</td></tr>
                    <?php
                      else:
                        $seq = 1;
                        foreach ($rows as $v):
                          $ts   = isset($v['ts']) ? (int)$v['ts'] : (($v['at'] ?? '') ? strtotime($v['at']) : null);
                          $when = $ts ? format_local_time($ts) : htmlspecialchars((string)($v['at'] ?? ''));
                          $ip   = (string)($v['ip'] ?? '');
                          $ref  = trim((string)($v['ref'] ?? ''));
                          if ($ref === '') $ref = '-';
                          $refShort = mb_substr($ref, 0, 80);
                    ?>
                      <tr>
                        <td><?php echo $seq++; ?></td>
                        <td><?php echo htmlspecialchars($when); ?></td>
                        <td><?php echo htmlspecialchars($ip); ?></td>
                        <td title="<?php echo htmlspecialchars($ref); ?>"><?php echo htmlspecialchars($refShort); ?></td>
                      </tr>
                    <?php endforeach; endif; ?>
                  </tbody>
                </table>
              </div>
            </div>

            <div class="col-lg-6" id="clicks-list">
              <h6 class="d-flex align-items-center gap-2">
                รายการคลิกล่าสุด
                <a href="#top" class="btn btn-outline-secondary btn-xs ms-auto">↑ กลับขึ้นบน</a>
              </h6>
              <div class="table-responsive">
                <table class="table table-sm table-striped mb-0">
                  <thead>
                    <tr>
                      <th style="width:72px;">ลำดับ</th>
                      <th>วันเวลา (<?php echo htmlspecialchars(cfg()['display_timezone'] ?? 'Asia/Bangkok'); ?>)</th>
                      <th>IP</th>
                      <th>ประเภท</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                      $rows = array_slice($clicks, 0, $recentLimit);
                      if (!count($rows)):
                    ?>
                      <tr><td colspan="4" class="text-muted">ยังไม่มีข้อมูล</td></tr>
                    <?php
                      else:
                        $seq = 1;
                        foreach ($rows as $v):
                          $ts   = isset($v['ts']) ? (int)$v['ts'] : (($v['at'] ?? '') ? strtotime($v['at']) : null);
                          $when = $ts ? format_local_time($ts) : htmlspecialchars((string)($v['at'] ?? ''));
                          $ip   = (string)($v['ip'] ?? '');
                          $tg   = (string)($v['target'] ?? '');
                    ?>
                      <tr>
                        <td><?php echo $seq++; ?></td>
                        <td><?php echo htmlspecialchars($when); ?></td>
                        <td><?php echo htmlspecialchars($ip); ?></td>
                        <td><?php echo htmlspecialchars($tg); ?></td>
                      </tr>
                    <?php endforeach; endif; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <p class="text-muted small mt-3 mb-0">
            * ระบบแสดงเวลาตามโซน <strong><?php echo htmlspecialchars(cfg()['display_timezone'] ?? 'Asia/Bangkok'); ?></strong>
          </p>
        </div>
      </div>
    </section>

  </div>
</div>
<a id="top"></a>

<script>
const dropZone = document.getElementById('dropZone');
const imageInput = document.getElementById('imageInput');
if (dropZone && imageInput) {
  dropZone.addEventListener('dragover', (e) => { e.preventDefault(); dropZone.classList.add('dragover'); });
  dropZone.addEventListener('dragleave', () => { dropZone.classList.remove('dragover'); });
  dropZone.addEventListener('drop', (e) => {
    e.preventDefault(); dropZone.classList.remove('dragover');
    if (e.dataTransfer.files.length > 0) { imageInput.files = e.dataTransfer.files; }
  });
}
</script>
</body>
</html>
