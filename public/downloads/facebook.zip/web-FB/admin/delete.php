<?php
// UTF-8 (NO BOM)
require __DIR__ . '/helpers.php';
require_login();
$c = cfg();

try {
  $id = $_GET['id'] ?? '';
  if (!$id) throw new Exception('ไม่พบไอดี');

  $data = read_db();
  $dir = rtrim($c['upload_dir'], '/\\');
  $new = [];
  foreach ($data['items'] as $it) {
    if (($it['id'] ?? '') === $id) {
      $p = $dir.'/'.($it['filename'] ?? '');
      if (is_file($p)) @unlink($p);
    } else {
      $new[] = $it;
    }
  }
  $data['items'] = $new;
  write_db($data);
  header('Location: index.php'); exit;
} catch (Throwable $e) {
  http_response_code(400);
  echo 'Error: '.htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
}
