<?php
// UTF-8 (NO BOM)
require __DIR__ . '/helpers.php';
require_login();
$c = cfg();

try {
  $data = read_db();
  if (!empty($data['background']['filename'])) {
    $p = rtrim($c['upload_dir'], '/\\') . '/' . $data['background']['filename'];
    if (is_file($p)) @unlink($p);
  }
  $data['background'] = null;
  write_db($data);
  log_line("DELETE BG OK");
  header('Location: index.php');
  exit;
} catch (Throwable $e) {
  log_line('DELETE BG ERROR: '.$e->getMessage());
  http_response_code(400);
  echo 'Error: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
}
