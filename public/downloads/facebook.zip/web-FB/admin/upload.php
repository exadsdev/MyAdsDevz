<?php
// UTF-8 (NO BOM)
require __DIR__ . '/helpers.php';
require_login();
$c = cfg();

try {
  if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK)
    throw new Exception('ไม่พบไฟล์ภาพ');

  $f = $_FILES['image'];
  if ($f['size'] <= 0) throw new Exception('ไฟล์ว่างเปล่า');
  if ($f['size'] > $c['max_upload_bytes']) throw new Exception('ไฟล์ใหญ่เกินกำหนด');

  $mime = detect_mime($f['tmp_name']);
  if (!$mime || !is_image_mime_allowed($mime)) throw new Exception('ชนิดไฟล์ไม่รองรับ: '.$mime);

  $ext = ext_for_mime($mime) ?: (pathinfo($f['name'], PATHINFO_EXTENSION) ?: 'jpg');
  $id  = uuidv4();
  $filename = $id.'.'.strtolower((string)$ext);

  @mkdir($c['upload_dir'], 0775, true);
  $target = rtrim($c['upload_dir'], '/\\').'/'.$filename;
  if (!safe_move_uploaded_file($f['tmp_name'], $target)) throw new Exception('บันทึกไฟล์ไม่สำเร็จ');

  $data = read_db();
  $data['items'][] = [
    'id'=>$id,'filename'=>$filename,'visible'=>true,'created_at'=>gmdate('c')
  ];
  write_db($data);
  header('Location: index.php'); exit;
} catch (Throwable $e) {
  http_response_code(400);
  echo 'Error: '.htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
}
