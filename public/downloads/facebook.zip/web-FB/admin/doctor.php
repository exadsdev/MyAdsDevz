<?php
// UTF-8 (NO BOM) — ตรวจสภาพแวดล้อมแบบรวดเร็ว
declare(strict_types=1);
ini_set('display_errors','1'); ini_set('display_startup_errors','1'); error_reporting(E_ALL);
header('Content-Type: text/plain; charset=UTF-8');

require __DIR__ . '/helpers.php';
$c = cfg();

function line($k,$v=''){ echo str_pad($k,28).": ".$v.PHP_EOL; }

echo "=== SELL PAGE UPLOAD DOCTOR ===\n\n";
line('PHP Version', PHP_VERSION);
line('SAPI', PHP_SAPI);
line('Loaded php.ini', php_ini_loaded_file() ?: '-');

echo "\n--- Limits ---\n";
line('upload_max_filesize', ini_get('upload_max_filesize'));
line('post_max_size', ini_get('post_max_size'));
line('memory_limit', ini_get('memory_limit'));
line('max_file_uploads', ini_get('max_file_uploads'));
line('app max_upload_bytes', (string)$c['max_upload_bytes']);

echo "\n--- Extensions / Functions ---\n";
line('extension fileinfo', extension_loaded('fileinfo') ? 'YES' : 'NO');
line('finfo_open()', function_exists('finfo_open') ? 'YES' : 'NO');
line('mime_content_type()', function_exists('mime_content_type') ? 'YES' : 'NO');
line('getimagesize()', function_exists('getimagesize') ? 'YES' : 'NO');

echo "\n--- Paths ---\n";
$uploadDir = rtrim($c['upload_dir'], '/\\');
$dataJson  = $c['json_path'];
$logPath   = $c['log_path'];
$tmpDir    = ini_get('upload_tmp_dir');

line('upload_dir', $uploadDir);
line('upload_dir exists', is_dir($uploadDir) ? 'YES' : 'NO');
line('upload_dir writable', is_writable($uploadDir) ? 'YES' : 'NO');

line('data json', $dataJson);
line('data dir exists', is_dir(dirname($dataJson)) ? 'YES' : 'NO');
line('data dir writable', is_writable(dirname($dataJson)) ? 'YES' : 'NO');

line('log_path', $logPath);
line('log dir writable', is_writable(dirname($logPath)) ? 'YES' : 'NO');

line('upload_tmp_dir', $tmpDir ?: '(system default)');

echo "\n--- Write test ---\n";
@mkdir($uploadDir, 0775, true);
$testFile = $uploadDir.'/.doctor_test.txt';
$ok = @file_put_contents($testFile, "ok @ ".date('c')) !== false;
line('write uploads/', $ok ? 'OK' : 'FAIL');
if ($ok) @unlink($testFile);

echo "\nOK.\n";
