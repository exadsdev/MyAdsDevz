<?php
// UTF-8 (NO BOM)
// CONFIG แบบออโต้เดเทค — ใช้ได้ทั้งรากโดเมน และซับโฟลเดอร์ (เช่น https://domain.com/landing)

$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['SERVER_PORT'] ?? '') == '443');
$scheme = $https ? 'https' : 'http';
$host   = $_SERVER['HTTP_HOST'] ?? 'localhost';

// base path ของโปรเจ็กต์ (ไดเรกทอรีที่มี index.php ตัวหน้าเว็บอยู่)
$scriptDir = rtrim(str_replace('\\','/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/'); // เช่น "/" หรือ "/landing"
$base_path = $scriptDir === '/' ? '' : $scriptDir;   // คงรูปแบบเป็น "" หากรากโดเมน
$full_base = $scheme . '://' . $host . $base_path;

// ---------- ปรับได้ตามต้องการ ----------
$PASSWORD = '1122';
// -----------------------------------------

return [
  'password' => $PASSWORD,

  // ===== URL (เวอร์ชัน deploy ใช้ full_base ที่ออโต้) =====
  'full_base'  => $full_base,                       // เช่น https://domain.com หรือ https://domain.com/landing
  'upload_url' => $full_base . '/uploads',          // รูปจะเสิร์ฟจาก /uploads (โฟลเดอร์นี้ต้องอยู่ข้าง index.php)
  'data_url'   => $full_base . '/data/images.json',
  'api_visit'  => $full_base . '/api/visit.php',
  'api_click'  => $full_base . '/api/click.php',

  // ===== PATH ฝั่งไฟล์จริง (ยึดตำแหน่งโปรเจ็กต์) =====
  // โครง: (root)
  //   ├─ index.php
  //   ├─ uploads/         <-- รูปต้องอยู่ที่นี่ (เขียน/อ่าน)
  //   ├─ data/images.json <-- คอนเทนต์/สถิติ JSON
  //   └─ api/, admin/
  'upload_dir' => __DIR__ . '/../uploads',
  'json_path'  => __DIR__ . '/../data/images.json',
  'log_path'   => __DIR__ . '/../data/upload.log',

  // อัปโหลด
  'max_upload_bytes' => 10 * 1024 * 1024,
  'allowed_mimes' => [
    'image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp','image/svg+xml'=>'svg',
  ],

  // โซนเวลา
  'display_timezone' => 'Asia/Bangkok',
];
