<?php
// UTF-8 (NO BOM)
declare(strict_types=1);
ini_set('display_errors','1'); ini_set('display_startup_errors','1'); error_reporting(E_ALL);
header('Content-Type: text/html; charset=UTF-8');
echo "<pre>PHP EXEC MARKER: OK (".date('c').")</pre>";
phpinfo();
