<?php
// UTF-8 (NO BOM)
require __DIR__ . '/helpers.php';
require_login();

try {
  $data = read_db();
  $current = ($data['active_index'] ?? '1') === '2' ? '2' : '1';
  $next = $current === '2' ? '1' : '2';

  $data['active_index'] = $next;

  // กัน null คีย์สำคัญ
  if (!isset($data['metrics'])) $data['metrics'] = ['totals'=>['visits'=>0,'clicks'=>0]];
  if (!isset($data['items']))   $data['items']   = [];
  if (!isset($data['buttons'])) $data['buttons'] = [];

  write_db($data);

  header('Location: ./index.php?ok=1&active=' . urlencode($next));
  exit;
} catch (Throwable $e) {
  header('Location: ./index.php?err=' . urlencode($e->getMessage()));
  exit;
}
