<?php
// UTF-8 (NO BOM) — ล้างข้อมูลสถิติ IP (visits + clicks) ทั้งหมด
require __DIR__ . '/helpers.php';
require_login();

try {
  $data = read_db();

  // รีเซ็ต metrics ทั้งก้อน
  $data['metrics'] = [
    'totals' => ['visits' => 0, 'clicks' => 0],
    'visits' => [],
    'clicks' => [],
  ];

  write_db($data);
  header('Location: index.php');
  exit;
} catch (Throwable $e) {
  http_response_code(400);
  echo 'Error: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
}
