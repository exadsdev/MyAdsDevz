<?php
// UTF-8 (NO BOM)
session_start();
require __DIR__ . '/helpers.php';
$c = cfg();
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $pass = $_POST['password'] ?? '';
  if (hash_equals($c['password'], $pass)) {
    $_SESSION['logged_in'] = true;
    header('Location: index.php');
    exit;
  } else {
    $error = 'รหัสผ่านไม่ถูกต้อง';
  }
}
?>
<!doctype html>
<html lang="th">
<head>
  <meta charset="utf-8">
  <title>Login | Sell Page Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container py-5">
    <div class="row justify-content-center">
      <div class="col-md-4">
        <div class="card shadow-sm">
          <div class="card-body">
            <h1 class="h4 mb-3">เข้าสู่ระบบ</h1>
            <?php if ($error): ?>
              <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            <form method="post">
              <div class="mb-3">
                <label class="form-label">รหัสผ่าน</label>
                <input type="password" class="form-control" name="password" required>
              </div>
              <button class="btn btn-primary w-100">เข้าสู่ระบบ</button>
            </form>
          </div>
        </div>
        <p class="text-center mt-3 text-muted small">Sell Page Admin</p>
      </div>
    </div>
  </div>
</body>
</html>
