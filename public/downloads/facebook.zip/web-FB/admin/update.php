<?php
// UTF-8 (NO BOM)
require __DIR__ . '/helpers.php';
require_login();
$c = cfg();

try {
  $id = $_POST['id'] ?? '';
  if ($id === '') throw new Exception('ไม่พบไอดีรายการ');

  $data = read_db();
  $foundIdx = null;
  foreach ($data['items'] as $i=>$it) {
    if (($it['id'] ?? '') === $id) { $foundIdx = $i; break; }
  }
  if ($foundIdx === null) throw new Exception('ไม่พบรายการ');

  if (isset($_FILES['replace']) && $_FILES['replace']['error'] === UPLOAD_ERR_OK) {
    $rf = $_FILES['replace'];
    if ($rf['size'] <= 0) throw new Exception('ไฟล์แทนที่ว่างเปล่า');
    if ($rf['size'] > $c['max_upload_bytes']) throw new Exception('ไฟล์แทนที่ใหญ่เกินกำหนด');

    $mime = detect_mime($rf['tmp_name']);
    if (!$mime || !is_image_mime_allowed($mime)) throw new Exception('ชนิดไฟล์แทนที่ไม่รองรับ: ' . $mime);

    $ext = ext_for_mime($mime) ?: (pathinfo($rf['name'], PATHINFO_EXTENSION) ?: 'jpg');
    $newName = $id.'.'.strtolower((string)$ext);

    $dir = rtrim($c['upload_dir'], '/\\');
    @mkdir($dir, 0775, true);
    $target = $dir.'/'.$newName;
    if (!safe_move_uploaded_file($rf['tmp_name'], $target)) throw new Exception('อัปโหลดแทนที่ไม่สำเร็จ');

    $old = $dir.'/'.($data['items'][$foundIdx]['filename'] ?? '');
    if (is_file($old) && basename($old) !== $newName) @unlink($old);

    $data['items'][$foundIdx]['filename'] = $newName;
    $data['items'][$foundIdx]['updated_at'] = gmdate('c');
  }

  write_db($data);
  header('Location: index.php'); exit;
} catch (Throwable $e) {
  http_response_code(400);
  echo 'Error: '.htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
}
