<?php
// UTF-8 (NO BOM)
session_start();
$_SESSION = [];
session_destroy();
header('Location: login.php');
