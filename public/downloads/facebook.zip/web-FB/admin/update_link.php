<?php
// UTF-8 (NO BOM)
require __DIR__ . '/helpers.php';
require_login();

try {
  $data = read_db();

  // ลิงก์รวมของรูป
  $data['global_link'] = sanitize_text($_POST['global_link'] ?? '', 1000);

  // ===== ปุ่ม (สูงสุด 2 ปุ่ม) — ตั้งชื่อได้ =====
  $buttons = [];

  // ปุ่มที่ 1
  $btn1_url   = sanitize_text($_POST['btn1_url']   ?? '', 1000);
  $btn1_label = sanitize_text($_POST['btn1_label'] ?? '', 50);
  $btn1_type  = 'website';
  if ($btn1_url !== '') {
    if ($btn1_label === '') $btn1_label = 'ไปหน้าเว็บ';
    $buttons[] = ['label' => $btn1_label, 'url' => $btn1_url, 'type' => $btn1_type];
  }

  // ปุ่มที่ 2
  $btn2_url   = sanitize_text($_POST['btn2_url']   ?? '', 1000);
  $btn2_label = sanitize_text($_POST['btn2_label'] ?? '', 50);
  $btn2_type  = 'line';
  if ($btn2_url !== '') {
    if ($btn2_label === '') $btn2_label = 'Add LINE ติดต่อ Admin';
    $buttons[] = ['label' => $btn2_label, 'url' => $btn2_url, 'type' => $btn2_type];
  }

  // เก็บแค่ 2 ปุ่ม
  $data['buttons'] = array_slice($buttons, 0, 2);

  // Facebook Pixel ID
  $data['facebook_pixel_id'] = sanitize_text($_POST['facebook_pixel_id'] ?? '', 64);

  write_db($data);
  header('Location: index.php'); exit;
} catch (Throwable $e) {
  http_response_code(400);
  echo 'Error: '.htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
}
