<?php
$jsonData = file_get_contents('products.json');
$products = json_decode($jsonData, true);
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="PG Phone Shop ผ่อนมือถือ เดอะมอลล์โคราช ชั้น 3 รับซื้อ ซ่อม เทิร์น มือถือ">
    <meta name="keywords" content="มือถือ, สมาร์ทโฟน, ร้านขายมือถือ, ราคามือถือ, สั่งซื้อมือถือออนไลน์, ผ่อนมือถือ">
    <meta property="og:title" content="PG Phone Shop ผ่อนมือถือ เดอะมอลล์โคราช ชั้น 3">
    <meta property="og:description" content="ร้านขายมือถือที่มีสินค้าคุณภาพสูง ทุกรุ่นทุกยี่ห้อ ผ่อนมือถือได้ที่ เดอะมอลล์โคราช ชั้น 3">
    <meta property="og:image" content="img/logo.png">
    <meta property="og:url" content="https://myadsdevs.shop/">
    <meta name="robots" content="index, follow">
    <meta property="og:type" content="website">
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    
    <title>PG Phone Shop ผ่อนมือถือ เดอะมอลล์โคราช ชั้น 3 รับซื้อ ซ่อม เทิร์น มือถือ</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

    <style>
        .topimg {
            max-width: 300px;
            margin: auto;
        }
    </style>
</head>
<body>


    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="#"> <img src="img/logo.png" width="60" alt="PG Phone Shop Logo"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link active" href="/">หน้าแรก</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/#products">สินค้า</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="https://www.facebook.com/PGPhoneShop/">ติดต่อเรา</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <div class="container my-4">


    <div class="text-center">


       <div class="topimg">
         <img src="img/review.jpg" width="100%" alt="review">
       </div>


    </div>





        <h1 class="text-center mb-4">PG Phone Shop ผ่อนมือถือ เดอะมอลล์โคราช ชั้น 3</h1>
        <div class="row" id="products">
            <?php foreach ($products as $product): ?>
                <div class="col-md-4">
                    <div class="card mb-4">
                        <img src="img/<?php echo $product['image']; ?>" class="card-img-top" alt="<?php echo htmlspecialchars($product['name']); ?>" />
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($product['name']); ?></h5>
                            <p class="card-text"><?php echo htmlspecialchars($product['description']); ?></p>
                            <p class="card-text"><strong><?php echo number_format($product['price'], 2); ?> บาท</strong></p>
                            <a href="cart.php?id=<?php echo $product['id']; ?>" class="btn btn-primary">สั่งซื้อ</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <footer class="bg-light text-center text-lg-start mt-5">
        <div class="container p-4">
            <div class="row">
                <div class="col-lg-6 col-md-12 mb-4 mb-md-0">
                    <h5 class="text-uppercase">ที่อยู่</h5>
                    <p>PG Phone Shop ผ่อนมือถือ <br> เดอะมอลล์โคราช ชั้น 3 รับซื้อ ซ่อม เทิร์น มือถือ</p>
                </div>
                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">ข้อมูลติดต่อ</h5>
                    <p>อีเมล: Pgphoneshop@gmail.com<br>โทรศัพท์: +6698 158 8303</p>
                </div>
                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">ลิงก์สำคัญ</h5>
                    <ul class="list-unstyled mb-0">
                        <li><a href="#!" class="text-dark">เกี่ยวกับเรา</a></li>
                        <li><a href="#!" class="text-dark">นโยบายความเป็นส่วนตัว</a></li>
                        <li><a href="#!" class="text-dark">เงื่อนไขการใช้บริการ</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
            &copy; <?php echo date('Y'); ?> ร้านขายมือถือ. สงวนลิขสิทธิ์
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
