<?php

$urls = "";

// $ref = $_GET['ref'] ?? null; if ($ref === 'mobile') { header("Location: $urls"); exit; }



$id = $_GET['id'] ?? null;
if (!$id) {
    header("Location: index.php");
    exit;
}



// อ่าน products.json
$jsonData = file_get_contents('products.json');
$products = json_decode($jsonData, true);

// ตรวจสอบว่า parameter id ถูกส่งมาหรือไม่
$id = $_GET['id'] ?? null;

// ถ้าไม่มี id → redirect ไปหน้า index
if (!$id) {
    header("Location: index.php");
    exit;
}

// ค้นหาสินค้าจาก id
$product = null;
foreach ($products as $p) {
    if ((string)$p['id'] === (string)$id) {
        $product = $p;
        break;
    }
}

// ถ้าไม่เจอสินค้าที่ตรงกับ id → redirect ไปหน้า index
if (!$product) {
    header("Location: index.php");
    exit;
}
?>


<?php
// อ่านข้อมูลจาก JSON
$jsonData = file_get_contents('products.json');
$products = json_decode($jsonData, true);

$id = $_GET['id'];
$product = null;

// ค้นหาสินค้าที่ตรงกับ ID
foreach ($products as $p) {
    if ($p['id'] == $id) {
        $product = $p;
        break;
    }
}

if (!$product) {
    die("ไม่พบสินค้าที่ต้องการ");
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="ซื้อสินค้ามือถือออนไลน์จาก PG Phone Shop ผ่อนมือถือ, รับซื้อ, ซ่อมมือถือที่เดอะมอลล์โคราช">
    <meta name="keywords" content="มือถือ, สมาร์ทโฟน, สั่งซื้อมือถือออนไลน์, ผ่อนมือถือ, เดอะมอลล์โคราช">
    <meta property="og:title" content="<?php echo $product['name']; ?>">
    <meta property="og:description" content="สั่งซื้อ <?php echo $product['name']; ?> จาก PG Phone Shop">
    <meta property="og:image" content="assets/images/<?php echo $product['image']; ?>">
    <meta property="og:url" content="https://yourwebsite.com/product.php?id=<?php echo $product['id']; ?>">
    <meta name="robots" content="index, follow">
    <title>สั่งซื้อสินค้า - <?php echo $product['name']; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#"><img src="img/logo.png" width="60" alt="PG Phone Shop Logo"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link active" href="/">หน้าแรก</a></li>
                    <li class="nav-item"><a class="nav-link" href="/#products">สินค้า</a></li>
                    <li class="nav-item"><a class="nav-link" href="https://www.facebook.com/PGPhoneShop/">ติดต่อเรา</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container my-4">
        <h1 class="text-center mb-4">สั่งซื้อสินค้า</h1>
        <div class="row">
            <!-- รูปภาพสินค้า -->
            <div class="col-md-6">
                <img src="img/<?php echo $product['image']; ?>" class="img-fluid" alt="<?php echo $product['name']; ?>">
            </div>

            <!-- รายละเอียดสินค้า -->
            <div class="col-md-6">
                <h2><?php echo $product['name']; ?></h2>
                <p><?php echo $product['description']; ?></p>
                <p><strong><?php echo number_format($product['price'], 2); ?> บาท</strong></p>
                
                <!-- ฟอร์มการสั่งซื้อ -->
                <form action="process_order.php" method="POST">
                    <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                    <div class="mb-3">
                        <label for="quantity">จำนวน:</label>
                        <input type="number" name="quantity" id="quantity" class="form-control" value="1" min="1" required>
                    </div>
                    <div class="mb-3">
                        <label for="customer_name">ชื่อ:</label>
                        <input type="text" name="customer_name" id="customer_name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="customer_email">อีเมล:</label>
                        <input type="email" name="customer_email" id="customer_email" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="customer_address">ที่อยู่:</label>
                        <textarea name="customer_address" id="customer_address" class="form-control" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-success">ยืนยันการสั่งซื้อ</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-light text-center text-lg-start mt-5">
        <div class="container p-4">
            <div class="row">
                <div class="col-lg-6 col-md-12 mb-4 mb-md-0">
                    <h5 class="text-uppercase">ที่อยู่</h5>
                    <p>PG Phone Shop ผ่อนมือถือ <br> เดอะมอลล์โคราช ชั้น 3 รับซื้อ ซ่อม เทิร์น มือถือ</p>
                </div>
                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">ข้อมูลติดต่อ</h5>
                    <p>อีเมล: Pgphoneshop@gmail.com<br>โทรศัพท์: +6698 158 8303</p>
                </div>
                <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">ลิงก์สำคัญ</h5>
                    <ul class="list-unstyled mb-0">
                        <li><a href="#!" class="text-dark">เกี่ยวกับเรา</a></li>
                        <li><a href="#!" class="text-dark">นโยบายความเป็นส่วนตัว</a></li>
                        <li><a href="#!" class="text-dark">เงื่อนไขการใช้บริการ</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
            &copy; <?php echo date('Y'); ?> ร้านขายมือถือ. สงวนลิขสิทธิ์
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
